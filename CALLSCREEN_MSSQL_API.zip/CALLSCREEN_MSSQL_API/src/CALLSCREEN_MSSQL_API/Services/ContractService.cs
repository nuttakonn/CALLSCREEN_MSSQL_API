﻿using CALLSCREEN_MSSQL_API.DataAccess.Interfaces;
using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Models.Contract;
using Newtonsoft.Json.Linq;
using System.Data;

namespace CALLSCREEN_MSSQL_API.Services
{
    public class ContractService
    {
        protected readonly IDataCenter _dc;
        public ContractService(IDataCenter dc) => _dc = dc;

        public async Task<ResponseModel> GetDataCallRemindRM(string idNo)
        {
            var response = new ResponseModel();
            try
            {
                var strCommand = @$"SELECT G34IDN, G34DUE, G34CNT
                                    FROM {_dc.SchemaDB()?.GN}.GNMS342
                                    WHERE G34IDN = '{idNo.Trim()}'";
                var result = await _dc.Get<List<ResultDataCallRemindRM>>(strCommand, CommandType.Text);
                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = result.data;
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.message = ex.Message;
            }
            return response;
        }

        public async Task<ResponseModel> GetListCallFree()
        {
            var response = new ResponseModel();
            try
            {
                var strCommand = @$"SELECT T8TELN, T8DESC, T8UDAT, T8UTIM, T8UUSR, T8UPGM, T8UJOB, T8DEL
                                  FROM {_dc.SchemaDB()?.CS}.CSMCB08 WITH (NOLOCK)
                                  WHERE T8DEL = ''";
                var result = await _dc.Get<List<ResultCallFreeModel>>(strCommand, CommandType.Text);
                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = result.data;
                }
                //else if (!result.success && result.message.Contains("Data not found")) { response.success = true; response.status = 200; }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.message = ex.Message;
            }
            return response;
        }

        public async Task<ResponseModel> GetLoanTypeIL(GetLoanTypeILModel input)
        {
            var response = new ResponseModel();
            try
            {
                var strCommand = @$"SELECT CASE WHEN P2LNTY = 2 THEN ' EIR' ELSE '' END AS loanType 
                                    FROM {_dc.SchemaDB()?.IL}.ILMS02 
                                    WHERE P2BRN = '{input.branchNo?.Trim()}' AND P2CONT = '{input.contractNo?.Trim()}'";
                var result = await _dc.Get<List<ResultLoanTypeILModel>>(strCommand, CommandType.Text);
                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = result.data[0];
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.message = ex.Message;
            }
            return response;
        }

        public async Task<ResponseModel> GetContractLeader(string collector)
        {
            var response = new ResponseModel();
            try
            {
                var strCommand = @$"SELECT TOP(1) [LeaderCode]
                                    From {_dc.SchemaDB()?.GenPortInfo}.[ListPortAsOf]
                                    WHERE [CampaignCode] = '{collector}'";
                var result = await _dc.Get<GetContractLeaderCodeModel>(strCommand, CommandType.Text);
                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = result.data;
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.message = ex.Message;
            }
            return response;
        }

        public async Task<ResponseModel> GetPrincipleBalanceWO(string idno)
        {
            var response = new ResponseModel();
            try
            {
                var strCommand = $@"EXEC {_dc.SchemaDB()?.ContractInfo}.[spGetPrincipleBalanceWO] '{idno}'";
                var result = await _dc.Get<List<PrincipleModel>>(strCommand, CommandType.Text);
                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = new ContractPrincipleBalanceWOModel { principleList = result.data };
                }
                else
                {
                    response.status = 400;
                    response.data = new ContractPrincipleBalanceWOModel();
                }
                response.message = result.message;

            }
            catch (Exception ex)
            {
                response.message = ex.Message;
            }
            return response;
        }
        public async Task<ResponseModel> GetSpecialNote(string idNo)
        {
            var response = new ResponseModel();
            try
            {
                var strCommand = @$"
Declare @CSNNO numeric(8,0);

Declare @SpecialNote nvarchar(200) = ''

SELECT Top 1 @CSNNO = CISNumber FROM {_dc.SchemaDB()?.CustomerInfo}.CustomerGeneral WITH (NOLOCK) WHERE IDCard = '" + idNo + $@"'


--@CSWS CASLL CSSRWS
Declare @WOWSDT nvarchar(200) = ''
Declare @WOOANM nvarchar(200) = ''
Declare @WOOATL nvarchar(200) = ''

SELECT top 1 @WOWSDT = WTSLDT ,@WOOANM = ISNULL(TB60.T60NAM,'') , @WOOATL= ISNULL(TB60.T60TEL,'')
FROM {_dc.SchemaDB()?.CS}.CSMSWS MSWSL1 WITH (NOLOCK)
JOIN {_dc.SchemaDB()?.CS}.CSMSWT MSWT WITH (NOLOCK) ON (MSWT.WTLOTN = MSWSL1.WSLOTN)
LEFT JOIN {_dc.SchemaDB()?.CS}.CSTB60 TB60 WITH (NOLOCK) ON (MSWT.WTOAGC = TB60.T60AGC)
WHERE MSWSL1.WSCSNO = @CSNNO
AND MSWSL1.WSSTAT = 'WS'
AND MSWSL1.WSDEL = ''


IF (@WOWSDT <> '' AND @WOOANM <> '')
Begin

	Set @SpecialNote = 'SELL: ' + FORMAT(convert(date,@WOWSDT),'dd/MM/yy') + ' OA:' + TRIM(@WOOANM) + ' TEL: ' + ISNULL(@WOOATL,'');
	
End


SELECT TRIM(@SpecialNote) AS SpecialNote;";
                var result = await _dc.Get<SpecialNoteModel>(strCommand, CommandType.Text);
                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = result.data;
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.message = ex.Message;
            }
            return response;
        }


        public async Task<ResponseModel> CheckstatusWriteoffSell(string contractNo)
        {
            var response = new ResponseModel();
            try
            {
                var strCommand = @$" 
Declare @WOStatus nvarchar(500) = ''

IF EXISTS (SELECT 1
FROM {_dc.SchemaDB()?.CS}.CSMSWS MSWSL1 WITH (NOLOCK)
JOIN {_dc.SchemaDB()?.CS}.CSMSWT MSWT WITH (NOLOCK) ON (MSWT.WTLOTN = MSWSL1.WSLOTN)
WHERE MSWSL1.WSCONT = " + contractNo + @$"
AND MSWSL1.WSSTAT = 'WS'
AND MSWSL1.WSDEL = '')
Begin
	
	Set @WOStatus = 'W/O SELL'

End
ELSE IF EXISTS(
SELECT 1
FROM {_dc.SchemaDB()?.CS}.CSMSWSBF MSWSL1 WITH (NOLOCK)
WHERE MSWSL1.WSCONT = " + contractNo + @$"
AND MSWSL1.WSSTAT = 'WP'
AND MSWSL1.WSDEL = ''
)
Begin
	
	Set @WOStatus = 'WP'
End
SELECT @WOStatus AS WOStatus;";
                var result = await _dc.Get<WriteOffSellModel>(strCommand, CommandType.Text);
                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = result.data;
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.message = ex.Message;
            }
            return response;
        }

        public async Task<ResponseModel> GetTotalWOAmtByBusiness(GetTotalWOAmtModel input)
        {
            var response = new ResponseModel();

            try
            {
                string strCommand = string.Empty;

                switch (input.business)
                {
                    case "IL":
                        strCommand = $@"
                            SELECT COALESCE(SUM(P83NWO), 0) AS TotalWOAmt
                            FROM {_dc.SchemaDB()?.IL}.ILMS83
                            WHERE P83CNT = '{input.contractNo?.Trim()}'";
                        break;

                    case "RL":
                        strCommand = $@"
                            SELECT COALESCE(SUM(P73NWO), 0) AS TotalWOAmt
                            FROM {_dc.SchemaDB()?.RL}.RLMS73
                            WHERE P73CNT = '{input.contractNo?.Trim()}'";
                        break;

                    case "PW":
                        strCommand = $@"
                            SELECT COALESCE(SUM(P73NWO), 0) AS TotalWOAmt
                            FROM {_dc.SchemaDB()?.PW}.PWMS73
                            WHERE P73CNT = '{input.contractNo?.Trim()}'";
                        break;

                    default:
                        response.status = 400;
                        response.message = "Invalid business type";
                        return response;
                }

                var result = await _dc.Get<TotalWOAmtModel>(strCommand, CommandType.Text);

                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = result.data ?? new TotalWOAmtModel { TotalWOAmt = 0m };
                }
                else
                {
                    response.status = 400;
                    response.message = result.message;
                }
            }
            catch (Exception ex)
            {
                response.status = 500;
                response.message = ex.Message;
            }

            return response;
        }
    }
}
