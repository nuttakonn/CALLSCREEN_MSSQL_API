﻿using CALLSCREEN_MSSQL_API.DataAccess.Interfaces;
using CALLSCREEN_MSSQL_API.Models;
using System.Data;

namespace CALLSCREEN_MSSQL_API.Services
{
    public class LegalService
    {
        protected readonly IDataCenter _dc;
        public LegalService(IDataCenter dc) => _dc = dc;

        public async Task<ResponseModel> GetLGCustomer(InputLGCustomerModel input)  //Old Name: Call_CSGC040
        {
            var response = new ResponseModel();
            try
            {
                var strCommand = @$"EXEC {_dc.SchemaDB()?.ContractInfo}.spGetLGCustomer '{input.contractNo?.Trim()}', '{input.curDate?.Trim()}'";
                var result = await _dc.Gets<LGCustomerHeaderModel, List<LGCustomerDetailModel>>(strCommand, CommandType.Text);
                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = new ResultLGCustomerModel { header = result.data, detail = result.datas };
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return response;
        }

        public async Task<ResponseModel> GetLGReceiveDetail(InputLGReceiveModel input)  //Old Name: Call_CSGC041
        {
            var response = new ResponseModel();
            try
            {
                var strCommand = @$"EXEC {_dc.SchemaDB()?.ContractInfo}.spGetLGReceiveDetail '{input.contractNo?.Trim()}', '{input.receiptNo?.Trim()}'";
                var result = await _dc.Gets<LGReceiveHeaderModel, List<LGReceiveDetailModel>>(strCommand, CommandType.Text);
                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = new ResultLGReceiveModel { header = result.data, detail = result.datas };
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return response;
        }

        public async Task<ResponseModel> GetLGTemplateDetail(string templateID)  //Old Name: Call_CSGC042
        {
            var response = new ResponseModel();
            try
            {
                var strCommand = @$"EXEC {_dc.SchemaDB()?.ContractInfo}.spGetLGTemplateDetail '{templateID?.Trim()}'";
                var result = await _dc.Gets<LGTemplateHeaderModel, List<LGTemplateDetailModel>>(strCommand, CommandType.Text);
                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = new ResultLGTemplateModel { header = result.data, detail = result.datas };
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return response;
        }

        public async Task<ResponseModel> GetLGRateDetail(string contractNo)  //Old Name: Call_CSGC043
        {
            var response = new ResponseModel();
            try
            {
                var strCommand = @$"EXEC {_dc.SchemaDB()?.ContractInfo}.spGetLGRateDetail '{contractNo?.Trim()}'";
                var result = await _dc.Gets<LGRateHeaderModel, List<LGRateDetailModel>>(strCommand, CommandType.Text);
                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = new ResultLGRateModel { header = result.data, detail = result.datas };
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return response;
        }

        public async Task<ResponseModel> GetLGExpenseDetail(string contractNo)  //Old Name: Call_CSGC044
        {
            var response = new ResponseModel();
            try
            {
                var strCommand = @$"EXEC {_dc.SchemaDB()?.ContractInfo}.spGetLGExpenseDetail '{contractNo?.Trim()}'";
                var result = await _dc.Get<List<LGExpenseDetailModel>>(strCommand, CommandType.Text);
                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = new ResultLGExpenseModel { detail = result.data };
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return response;
        }

        public async Task<ResponseModel> GetLGInstallment(string contractNo)  //Old Name: Call_CSGC045
        {
            var response = new ResponseModel();
            try
            {
                var strCommand = @$"EXEC {_dc.SchemaDB()?.ContractInfo}.spGetLGInstallment '{contractNo?.Trim()}'";
                var result = await _dc.Get<List<LGInstallmentDetailModel>>(strCommand, CommandType.Text);
                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = new ResultLGInstallmentModel { detail = result.data };
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return response;
        }

        public async Task<ResponseModel> GetLGReceiveDeduct(string contractNo)  //Old Name: Call_CSGC046
        {
            var response = new ResponseModel();
            try
            {
                var strCommand = @$"EXEC {_dc.SchemaDB()?.ContractInfo}.spGetLGReceiveDeduct '{contractNo?.Trim()}'";
                var result = await _dc.Get<List<LGReceiveDeductDetailModel>>(strCommand, CommandType.Text);
                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = new ResultLGReceiveDeductModel { detail = result.data };
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return response;
        }

        public async Task<ResponseModel> GetLGClosing(InputLGClosingModel input)  //Old Name: Call_CSGC047
        {
            var response = new ResponseModel();
            try
            {
                var strCommand = @$"EXEC {_dc.SchemaDB()?.ContractInfo}.spGetLGClosing '{input.contractNo?.Trim()}', '{input.curDate?.Trim()}'";
                var result = await _dc.Gets<LGClosingHeaderModel, List<LGClosingDetailModel>>(strCommand, CommandType.Text);
                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = new ResultLGClosingModel { header = result.data, detail = result.datas };
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return response;
        }

        public async Task<ResponseModel> GetLGSkipDue(string contractNo)  //Old Name: Call_CSGC048
        {
            var response = new ResponseModel();
            try
            {
                var strCommand = @$"EXEC {_dc.SchemaDB()?.ContractInfo}.spGetLGSkipDue '{contractNo?.Trim()}'";
                var result = await _dc.Get<List<LGSkipDueDetailModel>>(strCommand, CommandType.Text);
                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = new ResultLGSkipDueModel { detail = result.data };
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return response;
        }
    }
}
