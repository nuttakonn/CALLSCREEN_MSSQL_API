﻿using CALLSCREEN_MSSQL_API.DataAccess.Interfaces;
using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Models.Calculate;
using System.Data;
using System.Globalization;

namespace CALLSCREEN_MSSQL_API.Services
{
    public class CalculateService
    {
        protected readonly IDataCenter _dc;
        public CalculateService(IDataCenter dc) => _dc = dc;

        private decimal RoundDown2(decimal value) => Math.Floor(value * 100m) / 100m;

        private decimal CalculateInterest(decimal principal, decimal ratePerYear, int days)
        {
            var interest = (principal * (ratePerYear / 100m) * days / 365m);
            return RoundDown2(interest);
        }

        private string ConvertToThaiDateString(DateTime date)
        {
            return date.AddYears(543).ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
        }

        public async Task<ResponseModel> CalculateClosingIL(CalculateModel input)
        {
            var response = new ResponseModel();
            try
            {
                var contractQuery = $@"
                    SELECT ISNULL(CAST(P23TTM AS INT), 0) AS P23TTM,
                            ROUND(ISNULL(P23INY, 0), 2) AS P23INY,
                            ROUND(ISNULL(P23CRY, 0), 2) AS P23CRY,
                            ROUND(ISNULL(P23IN1, 0), 2) AS P23IN1,
                            ROUND(ISNULL(P23IN2, 0), 2) AS P23IN2,
                            ROUND(ISNULL(P23IN3, 0), 2) AS P23IN3
                    FROM {_dc.SchemaDB()?.IL}.ILMS23
                    WHERE P23CNT = '{input.contractNo}'";

                var rateQuery = $@"
                    SELECT ROUND(ISNULL(D012IR, 0), 2) AS D012IR, ROUND(ISNULL(D012CR, 0), 2) AS D012CR
                    FROM {_dc.SchemaDB()?.IL}.ILMD012
                    WHERE D012CT = '{input.contractNo}'";

                var dueQuery = $@"
                    SELECT P21DUE 
                    FROM {_dc.SchemaDB()?.IL}.ILMS02 
                    WHERE P2CONT = '{input.contractNo}'";

                var dueResult = await _dc.Get<List<DueDateModel>>(dueQuery, CommandType.Text);
                if (dueResult.data == null || dueResult.data.Count == 0)
                {
                    return new ResponseModel { status = 404, message = "ไม่พบข้อมูล Due Date" };
                }

                var contractResult = await _dc.Get<List<LoanILContractModel>>(contractQuery, CommandType.Text);
                var rateResult = await _dc.Get<List<InterestRateModel>>(rateQuery, CommandType.Text);

                if (contractResult.data == null || contractResult.data.Count == 0 ||
                    rateResult.data == null || rateResult.data.Count == 0)
                {
                    return new ResponseModel { status = 404, message = "ไม่พบข้อมูลสัญญาหรืออัตราดอกเบี้ย" };
                }

                var contract = contractResult.data.First();
                var rate = rateResult.data.First();

                decimal principal = (decimal)input.principal;
                int term = (int)Math.Floor(Convert.ToDouble(contract.P23TTM));
                decimal intRate = (decimal)rate.D012IR;
                decimal crRate = (decimal)rate.D012CR;

                decimal totalInterest = 0, sumIntCr = 0, totalCR = 0;
                var installmentList = new List<InstallmentDetail>();

                decimal remainingPrincipal = principal, previousPrincipal = principal;

                var contractDate = DateTime.ParseExact(input.contDate, "yyyyMMdd", CultureInfo.InvariantCulture);
                if (contractDate.Year > DateTime.Now.Year + 100)
                    contractDate = contractDate.AddYears(-543);

                //int startMonthOffset = (contractDate.Day >= 11) ? 2 : 1;
                //DateTime firstInstallmentDate = new DateTime(contractDate.Year, contractDate.Month, 2).AddMonths(startMonthOffset);
                var dueRaw = dueResult.data?.FirstOrDefault()?.P21DUE.ToString().Split('.')[0];

                string? sanitizedDue = dueRaw?.Split('.')[0];

                DateTime? firstInstallmentDate = null;

                if (!string.IsNullOrWhiteSpace(sanitizedDue) && sanitizedDue.Length == 8)
                {
                    var buddhistYear = int.Parse(sanitizedDue.Substring(0, 4));
                    var christianYear = buddhistYear - 543;
                    var monthDay = sanitizedDue.Substring(4, 4);
                    var gregorianDue = $"{christianYear}{monthDay}";

                    firstInstallmentDate = DateTime.TryParseExact(
                        gregorianDue,
                        "yyyyMMdd",
                        CultureInfo.InvariantCulture,
                        DateTimeStyles.None,
                        out var parsedDate
                    ) ? parsedDate : null;
                }

                DateTime previousBeginDate = contractDate;

                for (int i = 1; i <= term; i++)
                {
                    DateTime beginDate = firstInstallmentDate.Value.AddMonths(i - 1);
                    int days = (beginDate - previousBeginDate).Days;
                    previousBeginDate = beginDate;
                    //if (i == 1)
                    //{
                    //    beginDate = contractDate;
                    //    nextDate = new DateTime(contractDate.Year, contractDate.Month, 2).AddMonths(startMonthOffset);
                    //    days = (nextDate - beginDate).Days;
                    //    beginDate = nextDate;
                    //}
                    //else
                    //{
                    //    beginDate = new DateTime(contractDate.Year, contractDate.Month, 2).AddMonths(startMonthOffset + (i - 1));
                    //    nextDate = beginDate.AddMonths(1);
                    //    days = (nextDate - beginDate).Days;
                    //    beginDate = nextDate;
                    //}

                    decimal interest = CalculateInterest(remainingPrincipal, contract.P23INY, days);
                    decimal crUsage = CalculateInterest(remainingPrincipal, contract.P23CRY, days);

                    totalInterest += interest;
                    totalInterest = Math.Round(totalInterest, 2);
                    totalCR += crUsage;
                    totalCR = Math.Round(totalCR, 2);

                    decimal income;
                    if(i == 1)
                    {
                        income = interest + crUsage + (decimal)input.duty;
                        income = Math.Round(income, 2);
                    }
                    else
                    {
                        income = interest + crUsage;
                        income = Math.Round(income, 2);
                    }

                    decimal installment = i == 1 ? contract.P23IN1 : (i == term ? contract.P23IN3 : contract.P23IN2);

                    decimal payPrincipal = installment - income;
                    payPrincipal = Math.Round(payPrincipal, 2);
                    remainingPrincipal -= payPrincipal;
                    remainingPrincipal = Math.Round(remainingPrincipal, 2);

                    sumIntCr = Math.Round(totalInterest + totalCR);

                    installmentList.Add(new InstallmentDetail
                    {
                        Term = i,
                        BeginDate = ConvertToThaiDateString(beginDate),
                        Days = days,
                        Interest = interest,
                        CRUsage = crUsage,
                        Income = income,
                        Installment = installment,
                        PayPrincipal = payPrincipal,
                        Amount = remainingPrincipal,
                        Rebate = 0,
                        PrinCipal = i == 1 ? principal : previousPrincipal
                    });

                    previousPrincipal = remainingPrincipal;
                }

                decimal previousRebate = 0;

                foreach (var itemWithIndex in installmentList.Select((item, idx) => new { item, idx }))
                {
                    if (itemWithIndex.idx == 0)
                    {
                        itemWithIndex.item.Rebate = Math.Floor((sumIntCr + (decimal)input.duty - itemWithIndex.item.Income) * 100m) / 100m;
                    }
                    else
                    {
                        itemWithIndex.item.Rebate = Math.Floor((previousRebate - itemWithIndex.item.Income) * 100m) / 100m;
                    }

                    previousRebate = itemWithIndex.item.Rebate;
                }

                decimal totalAmt = totalInterest + totalCR;
                decimal rebate = Math.Round(totalAmt, 2);
                decimal totalClosing = principal + rebate + (decimal)input.duty;

                response.status = 200;
                response.success = true;
                response.data = new
                {
                    ContractDate = input.contDate,
                    ContractNo = input.contractNo,
                    Principal = principal,
                    TotalTerm = term,
                    InterestPerYear = contract.P23INY,
                    CRPerYear = contract.P23CRY,
                    DutyStamp = input.duty,
                    Term1Install = contract.P23IN1,
                    Term2ToNInstall = contract.P23IN2,
                    TermLastInstall = contract.P23IN3,
                    InterestRate = rate.D012IR,
                    CRRate = rate.D012CR,
                    SumInterest = Math.Round(totalInterest, 2),
                    SumCRUsage = Math.Round(totalCR, 2),
                    TotalAmount = Math.Round(totalAmt, 2),
                    TotalClosing = Math.Round(totalClosing, 2),
                    Installments = installmentList
                };
            }
            catch (Exception ex)
            {
                response.status = 500;
                response.message = ex.Message;
            }

            return response;
        }
    }
}
