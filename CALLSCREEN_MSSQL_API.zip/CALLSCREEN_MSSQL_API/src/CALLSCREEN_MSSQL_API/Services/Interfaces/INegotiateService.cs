﻿using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Models.Negotiate;

namespace CALLSCREEN_MSSQL_API.Services.Interfaces
{
    public interface INegotiateService
    {
        Task<ResponseModel> GetReceiveNegotiate(RequestNegotiateModel request);
    }
}
