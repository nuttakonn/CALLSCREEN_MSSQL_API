﻿using CALLSCREEN_MSSQL_API.Models;

namespace CALLSCREEN_MSSQL_API.Services.Interfaces
{
    public interface ISharedService
    {
        Task<ResponseModel> ExecuteQuery(string query);
        Task<ResponseModel> GetCustomerIDBizByContractNo(string contractNo);
        Task<ResponseModel> Call_GNCHKNOR(InputGNCHKNORModel input);
        Task<ResponseModel> Call_CSGC020(string idNumber);
        Task<ResponseModel> GetTelephoneInfoList(InputTelephoneInfoModel input);  //Old Name: Call_CSGC013
        Task<ResponseModel> GetBusinessList(InputBusinessModel input);  //Old Name: Call_CSGC013
        Task<ResponseModel> GetMapPortToUsername(string port, string user); //sub function in: GNSR346 
        Task<ResponseModel> GetOfficerTeamMemberForLG(string port, string user); //sub function in: GNSR346 
        Task<ResponseModel> InsertLogDataTracking(CSMSLGModel input);
    }
}
