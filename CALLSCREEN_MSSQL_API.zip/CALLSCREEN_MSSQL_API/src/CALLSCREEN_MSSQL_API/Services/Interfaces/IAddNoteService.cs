﻿using CALLSCREEN_MSSQL_API.Models;

namespace CALLSCREEN_MSSQL_API.Services.Interfaces
{
    public interface IAddNoteService
    {
        Task<ResponseModel> GetSMSMain(); 
    }
}
