﻿using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Models.SystemCode;

namespace CALLSCREEN_MSSQL_API.Services.Interfaces
{
    public interface ISystemCodeService
    {
        Task<ResponseModel> GetAppointPeriod(RequestAppointPeriodModel reqData);
        Task<ResponseModel> AddAppointPeriod(InputAppointPeriodForCRUD reqData);
        Task<ResponseModel> UpdateAppointPeriod(InputAppointPeriodForCRUD reqData);
        Task<ResponseModel> DeleteAppointPeriod(InputAppointPeriodForCRUD reqData);
        Task<ResponseModel> GetDataCampaign(RequestGetListCampaignModel input);
        Task<ResponseModel> AddCampaignNewStaff(InputCampaignNewStaffForCRUD input);
        Task<ResponseModel> EditCampaignNewStaff(InputCampaignNewStaffForCRUD input);
        Task<ResponseModel> DeleteCampaignNewStaff(InputCampaignNewStaffForCRUD input);
        Task<ResponseModel> GetListCustomerGroup(RequestGetDataCustomerGroupModel input);
        Task<ResponseModel> GetCustomerGroup(RequestGetDataCustomerGroupModel input);
        Task<ResponseModel> CreateCustomerGroupData(RequestSaveCustomerGroupModel input);
        Task<ResponseModel> UpdateCustomerGroupData(RequestSaveCustomerGroupModel input);
        Task<ResponseModel> DeleteCustomerGroupData(RequestSaveCustomerGroupModel input);
        Task<ResponseModel> GetDataRankingCode(RequestDataRankingModel input);
        Task<ResponseModel> GetNewRankingCode();
        Task<ResponseModel> CreateRankingCode(RequestSaveRankingModel input);
        Task<ResponseModel> UpdateRankingCode(ResultGetListRankingDetailModel input);
        Task<ResponseModel> DeleteRankingCode(RequestSaveRankingModel input);
        Task<ResponseModel> GetSectionUser(RequestSectionUserModel input);
        Task<ResponseModel> GetListSectionUser(RequestSectionUserModel input);
        Task<ResponseModel> CreateSectionUserData(RequestSaveSectionUserModel input);
        Task<ResponseModel> UpdateSectionUserData(RequestSaveSectionUserModel input);
        Task<ResponseModel> DeleteSectionUserData(RequestSaveSectionUserModel input);
        Task<ResponseModel> Find_RankHead(RequestSaveRankingModel input);
        Task<ResponseModel> Find_RankDetail(RequestSaveRankingModel input);
        Task<ResponseModel> GetWorkingDate(RequestWorkingDateModel input);
        Task<ResponseModel> AddWorkingDate(RequestWorkingDateModel input);
        Task<ResponseModel> UpdateWorkingDate(RequestWorkingDateModel input);
        Task<ResponseModel> DeleteWorkingDate(RequestWorkingDateModel input);
        Task<ResponseModel> GetListTypeAndResultByTypeCodeResultCode(RequestGetDataTypeAndResultModel input);
        Task<ResponseModel> GetListTypeCodeByTypeCode(RequestGetDataTypeAndResultModel input);
        Task<ResponseModel> GetListResultCodeByTypeCode(RequestGetDataTypeAndResultModel input);
        Task<ResponseModel> GetTypeAndResultByTypeCodeResultCode(RequestGetDataTypeAndResultModel input);
        Task<ResponseModel> CreateTypeAndResultData(RequestSaveTypeAndResultModel input);
        Task<ResponseModel> UpdateTypeAndResultData(RequestSaveTypeAndResultModel input);
        Task<ResponseModel> DeleteTypeAndResultData(RequestSaveTypeAndResultModel input);



        #region SMS Default Group
        Task<ResponseModel> GetDataSMSDefault(InputSMSDefaultModel reqData);
        Task<ResponseModel> AddSMSDefault(RequestSaveSMSDefaultModel reqData);
        Task<ResponseModel> UpdateSMSDefault(RequestSaveSMSDefaultModel reqData);
        Task<ResponseModel> DeleteSMSDefault(RequestSaveSMSDefaultModel reqData);
        #endregion SMS Default Group


        #region SMS Group
        Task<ResponseModel> GetDataSMSGroup(InputSMSGroupCodeModel reqData);
        Task<ResponseModel> AddSMSGroup(InputSMSGroupModel reqData);
        Task<ResponseModel> UpdateSMSGroup(InputSMSGroupModel reqData);
        Task<ResponseModel> DeleteSMSGroup(InputSMSGroupModel reqData);
        #endregion SMS Group


        #region SMS Keyword
        Task<ResponseModel> GetDataSMSKeyword(InputSMSKeywordCodeModel reqData);
        Task<ResponseModel> AddSMSKeyword(InputSMSKeywordForInsert reqData);
        Task<ResponseModel> UpdateSMSKeyword(InputSMSKeywordForUpdate reqData);
        Task<ResponseModel> DeleteSMSKeyword(InputSMSKeywordForDelete reqData);
        #endregion SMS Keyword


        #region SMS Subject
        Task<ResponseModel> GetDataSMSSubject(InputSMSSubjectModel reqData);
        Task<ResponseModel> AddSMSSubject(InputSMSSubjectCodeModel reqData);
        Task<ResponseModel> UpdateSMSSubject(InputSMSSubjectCodeModel reqData);
        Task<ResponseModel> DeleteSMSSubject(InputSMSSubjectCodeModel reqData);
        #endregion SMS Subject


        #region SMS Template
        Task<ResponseModel> GetDataSMSTemplate(InputSMSTemplateModel reqData);
        Task<ResponseModel> AddSMSTemplate(RequestSaveSMSTemplate reqData);
        Task<ResponseModel> UpdateSMSTemplate(RequestSaveSMSTemplate reqData);
        Task<ResponseModel> DeleteSMSTemplate(RequestSaveSMSTemplate reqData);
        Task<ResponseModel> GetDDLSMSTemplatebyType(string type);
        Task<ResponseModel> GetDDlSMSGroupbyStatus(string type);
        Task<ResponseModel> GetDDlSMSSubjectbyStatus(string type);
        Task<ResponseModel> GetSMSTemplateBindDDL(InputSMSTemplateDDLModel reqData);
        #endregion SMS Template
    }
}
