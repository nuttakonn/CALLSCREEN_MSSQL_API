﻿using CALLSCREEN_MSSQL_API.DataAccess.Interfaces;
using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Models.Negotiate;
using CALLSCREEN_MSSQL_API.Services.Interfaces;
using System.Data;

namespace CALLSCREEN_MSSQL_API.Services
{
    public class NegotiateService : INegotiateService
    {
        protected readonly IDataCenter _dc;

        public NegotiateService(IDataCenter dc)
        {
            _dc = dc;
        }

        public async Task<ResponseModel> GetReceiveNegotiate(RequestNegotiateModel request) //CSGC37
        {
            ResponseModel response = new ResponseModel();
            NegotiateModel res = new NegotiateModel();
            try
            {
                var strCommand = $@"EXEC {_dc.SchemaDB()?.ContractInfo}.[spGetReceiveNegotiate] '{request.contractNo}'";
                var result = await _dc.Gets<PaymentDetailModel, List<PaymentListModel>>(strCommand, CommandType.Text);
                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    res.paymentDetail.penaltyNo = result.data.penaltyNo;
                    res.paymentDetail.StartDate = result.data.StartDate;
                    res.paymentDetail.EndDate = result.data.EndDate;
                    res.paymentData = result.datas;

                    if (res.paymentData[0] != null)
                    {
                        res.paymentDetail.bookingDate = res.paymentData[0].bookingDate;
                        res.paymentDetail.receiveDate = res.paymentData[0].receiveDate;
                        res.paymentDetail.receiveAmount = res.paymentData[0].receiveAmount;
                        res.paymentDetail.pdChannel = res.paymentData[0].channel;
                    }
                    
                }
                else
                    response.status = 400;
                response.message = result.message;

            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }

            response.data = res;
            return response;
        }
    }
}
