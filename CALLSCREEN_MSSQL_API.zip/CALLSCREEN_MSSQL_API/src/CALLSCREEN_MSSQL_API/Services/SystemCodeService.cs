﻿using CALLSCREEN_MSSQL_API.Common.Extensions;
using CALLSCREEN_MSSQL_API.DataAccess.Interfaces;
using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Models.SystemCode;
using CALLSCREEN_MSSQL_API.Services.Interfaces;
using System.Data;
using System.Globalization;

namespace CALLSCREEN_MSSQL_API.Services
{
    public class SystemCodeService : ISystemCodeService
    {
        protected readonly IDataCenter _dc;
        public SystemCodeService(IDataCenter dc) => _dc = dc;

        private readonly DateTime dateTime = DateTime.Now;
        private readonly DateTimeFormatInfo m_DThai = new CultureInfo("th-TH", false).DateTimeFormat;
        private readonly string systemName = "CALLSCREEN";
        private string m_LastError = "";

        public async Task<string> GetCurrentDate()
        {
            try
            {
                var strCommand = @$"SELECT CAST(M97DTE + 25000000 AS INTEGER) AS CurrentDate FROM {_dc.SchemaDB()?.CS}.CSMS97 WITH (NOLOCK) WHERE M97CDE = '01'";
                var result = await _dc.Get<HomeModel>(strCommand, CommandType.Text);
                return await Task.FromResult(result.data?.CurrentDate ?? DateTime.Now.ToString("yyyyMMdd"));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #region Appoint Period
        public async Task<ResponseModel> GetAppointPeriod(RequestAppointPeriodModel reqData)
        {
            var response = new ResponseModel();
            try
            {
                string condition = (!string.IsNullOrEmpty(reqData.type)) ? $" AND T5TYPE = '{reqData.type.Trim().ToUpper()}' " : "";

                var cmd = $@"SELECT
                                T5TYPE,
                                T5STIM,
                                T5ETIM
                             FROM
                                {_dc.SchemaDB()?.CS}.CSMCB05
                             WHERE 
                                T5DEL = '' 
                                {condition}
                             ORDER BY
                                T5TYPE";
                var result = await _dc.Get<List<ResultAppointPeriodModel>>(cmd, CommandType.Text);
                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    if (!result.data.IsEmpty())
                    {
                        result.data.ForEach(item =>
                        {
                            if (item.T5STIM.ToString().Length < 5)
                            {
                                item.T5STIM += 240000;
                            }
                            if (item.T5ETIM.ToString().Length < 5)
                            {
                                item.T5ETIM += 240000;
                            }
                        });
                        response.data = result.data;
                    }
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return response;
        }
        public bool CheckAppointPeriod(InputAppointPeriodForCRUD input, string checkType, ref string msgError)
        {
            bool popSuccess;
            var data = new ResultAppointPeriodModel();
            try
            {
                var cmdText = "";
                if (checkType == "FindExist")
                {
                    cmdText = $@"SELECT * FROM {_dc.SchemaDB()?.CS}.CSMCB05 WHERE T5TYPE = '{input.type?.Trim().ToUpper()}' AND T5DEL  = ''";

                }
                else if (checkType == "FindObject")
                {
                    cmdText = $@"SELECT * FROM {_dc.SchemaDB()?.CS}.CSMCB05 WHERE T5TYPE = '{input.type?.Trim().ToUpper()}' AND T5DEL  = 'X'";
                }
                var result = _dc.Get<ResultAppointPeriodModel>(cmdText, CommandType.Text).Result;
                if (result.data.T5TYPE == null && result.data.T5STIM == 0 && result.data.T5ETIM == 0)
                {
                    popSuccess = false;
                }
                else popSuccess = true;
                data = result.data;
            }
            catch (Exception ex)
            {
                popSuccess = false;
                msgError = ex.Message.ToString();
            }
            return ((data != null) && popSuccess);
        }
        public async Task<ResponseModel> AddAppointPeriod(InputAppointPeriodForCRUD reqData)
        {
            var response = new ResponseModel();
            var modelResult = new ResultSaveAppointPeriod();
            try
            {
                string msgError = "";
                string cmdText = "";
                int updateDate = int.TryParse(dateTime.ToString("yyMMdd", m_DThai), out updateDate) ? updateDate : 0;
                int updateTime = int.TryParse(dateTime.ToString("HHmmss", m_DThai), out updateTime) ? updateTime : 0;
                if (this.CheckAppointPeriod(reqData, "FindExist", ref msgError))
                {
                    msgError = ", this Code already exists.";
                    modelResult.lastError = msgError;
                    response.message = msgError;
                    response.data = modelResult;
                    response.success = true;
                    return await Task.FromResult(response);
                }
                else if (this.CheckAppointPeriod(reqData, "FindObject", ref msgError))
                {
                    cmdText = $@"UPDATE {_dc.SchemaDB()?.CS}.CSMCB05
                                            SET T5STIM = {reqData.startTime},
                                                T5ETIM = {reqData.endTime},
                                                T5UDAT = {updateDate},
                                                T5UTIM = {updateTime},
                                                T5UUSR = '{reqData.username}',
                                                T5UPGM = '{systemName}',
                                                T5UJOB = '',
                                                T5DEL  = ''
                                          WHERE T5TYPE = '{reqData.type?.Trim().ToUpper()}'";
                }
                else
                {
                    cmdText = $@"INSERT INTO {_dc.SchemaDB()?.CS}.CSMCB05 (T5TYPE,T5STIM,T5ETIM,T5UDAT,T5UTIM,T5UUSR,T5UPGM,T5UJOB,T5DEL)
                                            VALUES ('{reqData.type?.Trim().ToUpper()}',
                                                    {reqData.startTime},
                                                    {reqData.endTime},
                                                    {updateDate},
                                                    {updateTime},
                                                    '{reqData.username}',
                                                    '{systemName}',
                                                    '',
                                                    '')";
                }
                var result = await _dc.Execute(cmdText, CommandType.Text);
                if (result.success)
                {
                    modelResult.success = result.success;
                    response.success = result.success;
                    response.message = "Insert Data Success";
                }

                response.data = modelResult;
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + result.message : result.message;
            }
            catch (Exception ex)
            {
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + ex.Message : ex.Message;
            }

            return await Task.FromResult(response);
        }

        public async Task<ResponseModel> UpdateAppointPeriod(InputAppointPeriodForCRUD reqData)
        {
            var response = new ResponseModel();
            var modelResult = new ResultSaveAppointPeriod();
            try
            {
                var date = Convert.ToUInt32(dateTime.ToString("yyMMdd", m_DThai));
                var time = Convert.ToUInt32(dateTime.ToString("HHmmss", m_DThai));
                var cmdText = $@"UPDATE {_dc.SchemaDB()?.CS}.CSMCB05
                                    SET T5STIM = {reqData.startTime},
                                        T5ETIM = {reqData.endTime},
                                        T5UDAT = {date},
                                        T5UTIM = {time},
                                        T5UUSR = '{reqData.username}',
                                        T5UPGM = '{systemName}',
                                        T5UJOB = '',
                                        T5DEL  = ''
                                  WHERE T5TYPE = '{reqData.type?.Trim().ToUpper()}'";
                var result = await _dc.Execute(cmdText, CommandType.Text);
                if (result.success)
                {
                    modelResult.success = result.success;
                    response.success = result.success;
                    response.message = "Insert Data Success";
                }

                response.data = modelResult;
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + result.message : result.message;
            }
            catch (Exception ex)
            {
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + ex.Message : ex.Message;
            }

            return await Task.FromResult(response);
        }

        public async Task<ResponseModel> DeleteAppointPeriod(InputAppointPeriodForCRUD reqData)
        {
            var response = new ResponseModel();
            var modelResult = new ResultSaveAppointPeriod();
            try
            {
                var status = "X";
                int updateDate = int.TryParse(DateTime.Now.ToString("yyMMdd", m_DThai), out updateDate) ? updateDate : 0;
                int updateTime = int.TryParse(DateTime.Now.ToString("HHmmss", m_DThai), out updateTime) ? updateTime : 0;
                var cmdText = $@"UPDATE {_dc.SchemaDB()?.CS}.CSMCB05 SET T5DEL='{status}',
                              T5UUSR='{reqData.username}',
                              T5UPGM='{systemName}',
                              T5UDAT={updateDate},
                              T5UTIM={updateTime} 
                              WHERE T5TYPE='{reqData.type?.Trim().ToUpper()}'";
                //var cmdText = $@"UPDATE {_dc.SchemaDB()?.CS}.CSMCB05 SET T5DEL = 'X' WHERE T5TYPE = '{reqData.type?.Trim().ToUpper()}'";

                var result = await _dc.Execute(cmdText, CommandType.Text);
                if (result.success)
                {
                    modelResult.success = result.success;
                    response.success = result.success;
                    response.message = "Delete Data Success";
                }
                else
                {
                    response.message = result.message;
                    response.status = 400;
                }

                response.data = modelResult;
                //response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + result.message : result.message;
            }
            catch (Exception ex)
            {
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + ex.Message : ex.Message;
            }

            return await Task.FromResult(response);
        }
        #endregion Appoint Period

        #region Campaign NewStaff
        public async Task<ResponseModel> GetDataCampaign(RequestGetListCampaignModel input)
        {
            var response = new ResponseModel();
            try
            {
                var cmdText = $@"SELECT T2NUSR,T2CAMP FROM {_dc.SchemaDB()?.CS}.CSMCB12";
                var strWhere = " where T2DEL ='' ";
                if (!string.IsNullOrEmpty(input.callUser.Trim().ToUpper()))
                {
                    strWhere += " and T2NUSR = '" + input.callUser.ToString().Trim() + "' ";
                }
                cmdText += " " + strWhere + " order by T2NUSR";

                var result = await _dc.Get<List<ResultGetListCampaignModel>>(cmdText, CommandType.Text);
                if (result.success)
                {
                    response.status = 200;
                    response.success = result.success;
                    response.data = result.data.ToList();
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return await Task.FromResult(response);
        }

        public async Task<ResponseModel> AddCampaignNewStaff(InputCampaignNewStaffForCRUD input)
        {
            var response = new ResponseModel();
            try
            {
                string msgError = "";
                string cmdText = "";

                if (this.CheckCampaignNewStaff(input, "FindExist", ref msgError))
                {
                    msgError = ", this Code already exists.";
                    response.message = msgError;
                    response.success = false;

                    return response;
                }
                else if (this.CheckCampaignNewStaff(input, "FindObject", ref msgError))
                {
                    cmdText = $@"UPDATE {_dc.SchemaDB()?.CS}.CSMCB12 SET T2UDAT={Convert.ToUInt32(dateTime.ToString("yyMMdd", m_DThai))},
                                    T2UTIM={Convert.ToUInt32(dateTime.ToString("HHmmss", m_DThai))},
                                    T2UUSR='{input.updateby.ToUpper().Trim()}',
                                    T2CAMP='{input.campaign.ToUpper().Trim()}',
                                    T2UPGM='{systemName}',
                                    T2UJOB='{""}',
                                    T2DEL='{""}' 
                                    WHERE T2NUSR='{input.callUser.ToUpper().Trim()}'";
                }
                else
                {
                    cmdText = $@"INSERT INTO {_dc.SchemaDB()?.CS}.CSMCB12 (T2NUSR,T2CAMP,T2UDAT,T2UTIM,T2UUSR,T2UPGM,T2UJOB,T2DEL)  VALUES
                            ('{input.callUser.ToUpper().Trim()}',
                            '{input.campaign.ToUpper().Trim()}',
                            {Convert.ToUInt32(dateTime.ToString("yyMMdd", m_DThai))},
                            {Convert.ToUInt32(dateTime.ToString("HHmmss", m_DThai))},
                            '{input.updateby.ToUpper().Trim()}',
                            '{systemName}',
                            '{""}',
                            '{""}')";
                }
                var dr = await _dc.Execute(cmdText, CommandType.Text);
                if (dr.success)
                {
                    response.success = dr.success;
                    response.message = dr.message;
                    response.status = 200;
                }
                else
                {
                    response.message = dr.message;
                    response.status = 400;
                }
            }
            catch (Exception ex)
            {
                response.success = false;
                response.message = ex.Message;
            }
            return await Task.FromResult(response);
        }

        public async Task<ResponseModel> EditCampaignNewStaff(InputCampaignNewStaffForCRUD input)
        {
            var response = new ResponseModel();
            try
            {
                var date = Convert.ToUInt32(dateTime.ToString("yyMMdd", m_DThai));
                var time = Convert.ToUInt32(dateTime.ToString("HHmmss", m_DThai));
                var cmd = $@"UPDATE {_dc.SchemaDB()?.CS}.CSMCB12 SET T2UDAT={Convert.ToUInt32(dateTime.ToString("yyMMdd", m_DThai))},
                                    T2UTIM={Convert.ToUInt32(dateTime.ToString("HHmmss", m_DThai))},
                                    T2UUSR='{input.updateby.ToUpper().Trim()}',
                                    T2CAMP='{input.campaign.ToUpper().Trim()}',
                                    T2UPGM='{systemName}',
                                    T2UJOB='{""}',
                                    T2DEL='{""}' 
                                    WHERE T2NUSR='{input.callUser.ToUpper().Trim()}'";
                var result = await _dc.Execute(cmd, CommandType.Text);
                if (result.success)
                {
                    response.success = result.success;
                    response.message = result.message;
                }
                else
                {
                    response.message = $"Data Not Update ({result.message})";
                    response.status = 400;
                }
            }
            catch (Exception ex)
            {
                response.message = ex.Message;
            }
            return await Task.FromResult(response);
        }

        public async Task<ResponseModel> DeleteCampaignNewStaff(InputCampaignNewStaffForCRUD input)
        {
            var response = new ResponseModel();
            try
            {
                var cmd = $@"UPDATE {_dc.SchemaDB()?.CS}.CSMCB12 SET T2UDAT={Convert.ToUInt32(dateTime.ToString("yyMMdd", m_DThai))},
                                    T2UTIM={Convert.ToUInt32(dateTime.ToString("HHmmss", m_DThai))},
                                    T2UUSR='{input.updateby.ToUpper().Trim()}',
                                    T2UPGM='{systemName}',
                                    T2UJOB='{""}',
                                    T2DEL='{"X"}' 
                                    WHERE T2NUSR='{input.callUser.ToUpper().Trim()}'";
                var result = await _dc.Execute(cmd, CommandType.Text);
                if (result.success)
                {
                    response.status = 200;
                    response.success = result.success;
                    response.message = "Delete Data Success";
                }
                else
                {
                    response.message = result.message;
                    response.status = 400;
                }
            }
            catch (Exception ex)
            {
                response.message = ex.Message;
            }
            return await Task.FromResult(response);
        }

        private bool CheckCampaignNewStaff(InputCampaignNewStaffForCRUD input, string checkType, ref string msgError)
        {
            bool popSuccess;
            var data = new ResultGetListCampaignModel();
            try
            {
                var cmdText = "";
                if (checkType == "FindExist")
                {
                    cmdText = $@"SELECT * FROM {_dc.SchemaDB()?.CS}.CSMCB12 WHERE T2NUSR = '{input.callUser}' and T2DEL = ''";
                }
                else if (checkType == "FindObject")
                {
                    cmdText = $@"SELECT * FROM {_dc.SchemaDB()?.CS}.CSMCB12 WHERE T2NUSR = '{input.callUser}' and T2DEL = 'X'";
                }
                var res = _dc.Get<ResultGetListCampaignModel>(cmdText, CommandType.Text);
                if (res.Result.data.T2NUSR == null && res.Result.data.T2CAMP == null)
                {
                    popSuccess = false;
                }
                else
                {
                    popSuccess = true;
                }
                data = res.Result.data;
            }
            catch (Exception ex)
            {
                popSuccess = false;
                msgError = ex.Message.ToString();
            }
            return (data != null) && popSuccess;
        }
        #endregion Campaign NewStaff

        #region Customer Group
        public async Task<ResponseModel> GetListCustomerGroup(RequestGetDataCustomerGroupModel input)
        {
            var response = new ResponseModel();
            try
            {
                string strWhere = "";
                int intmonth = 0;
                int fromLastMonth, toLastMonth;

                var cmdText = $@"SELECT A.T7STAS, A.T7TYSQ, A.T7TYCD, A.T7TYDS, A.T7MONF, A.T7MONT, A.T7ARRY, A.T7UDAT, A.T7UTIM, A.T7UUSR, A.T7UPGM, A.T7UJOB, A.T7DEL
                            FROM {_dc.SchemaDB()?.CS}.CSMCB17 A";

                strWhere = $"WHERE A.T7DEL = ''";

                if (!string.IsNullOrWhiteSpace(input.custGrpStatus))
                {
                    strWhere += $" and A.T7STAS = '{input.custGrpStatus?.Trim().ToUpper()}'";
                }

                if (!string.IsNullOrWhiteSpace(input.typeSequence))
                {
                    strWhere += $" and A.T7TYSQ = '{input.typeSequence?.Trim().ToUpper()}'";
                }

                if (!string.IsNullOrWhiteSpace(input.typeCode))
                {
                    strWhere += $" and A.T7TYCD = '{input.typeCode?.Trim()}'";
                }

                if (!string.IsNullOrWhiteSpace(input.typeDescription))
                {
                    strWhere += $" and A.T7TYDS LIKE '%{input.typeDescription?.Trim()}%'";
                }

                if (!string.IsNullOrWhiteSpace(input.fromLastMonth))
                {
                    fromLastMonth = (int.TryParse(input.fromLastMonth, out intmonth) ? intmonth : 0);

                    strWhere += $" and A.T7MONF = '{fromLastMonth}'";
                }

                if (!string.IsNullOrWhiteSpace(input.toLastMonth))
                {
                    toLastMonth = (int.TryParse(input.toLastMonth, out intmonth) ? intmonth : 0);
                    strWhere += $" and A.T7MONT = '{toLastMonth}'";
                }

                cmdText += $" {strWhere} ORDER BY A.T7STAS, A.T7TYSQ ";

                var result = await _dc.Get<List<GetDataCustomerGroupModel>>(cmdText, CommandType.Text);
                if (result.success)
                {
                    response.status = 200;
                    response.success = result.success;
                    response.data = result.data.ToList();
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return await Task.FromResult(response);
        }

        public async Task<ResponseModel> GetCustomerGroup(RequestGetDataCustomerGroupModel input)
        {
            var response = new ResponseModel();
            try
            {
                var cmdText = $@"SELECT A.T7STAS, A.T7TYSQ, A.T7TYCD, A.T7TYDS, A.T7MONF, A.T7MONT, A.T7ARRY, A.T7UDAT, A.T7UTIM, A.T7UUSR, A.T7UPGM, A.T7UJOB, A.T7DEL
                                FROM {_dc.SchemaDB()?.CS}.CSMCB17 A 
                                WHERE A.T7TYSQ = '{input.typeSequence?.Trim().ToUpper()}' 
                                    AND A.T7STAS = '{input.custGrpStatus?.Trim().ToUpper()}'";

                var result = await _dc.Get<GetDataCustomerGroupModel>(cmdText, CommandType.Text);
                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = result.data;
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return await Task.FromResult(response);
        }

        public async Task<ResponseModel> CreateCustomerGroupData(RequestSaveCustomerGroupModel input)
        {
            var response = new ResponseModel();
            var modelResult = new ResultSaveCustomerGroupModel();
            try
            {
                string msgError = "";
                string cmdText = "";
                int updateDate = int.TryParse(dateTime.ToString("yyMMdd", m_DThai), out updateDate) ? updateDate : 0;
                int updateTime = int.TryParse(dateTime.ToString("HHmmss", m_DThai), out updateTime) ? updateTime : 0;

                int intmonth = 0;
                int fromLastMonth = (int.TryParse(input.fromLastMonth, out intmonth) ? intmonth : 0);
                int toLastMonth = (int.TryParse(input.toLastMonth, out intmonth) ? intmonth : 0);

                if (await this.CheckCustomerGroup(input, "FindExist"))
                {
                    msgError = ", this Code already exists.Please , check 'type sequence or 'type code' that repeat. ";
                    modelResult.lastError = msgError;
                    response.message = msgError;
                    response.data = modelResult;
                    response.success = true;
                    return await Task.FromResult(response);
                }
                else if (await this.CheckCustomerGroup(input, "FindObject"))
                {
                    cmdText = $@"UPDATE {_dc.SchemaDB()?.CS}.CSMCB17  
                                 SET T7TYCD = '{input.typeCode?.Trim()}' 
                                    , T7TYDS = '{input.typeDescription?.Trim()}' 
                                    , T7MONF = '{fromLastMonth}' 
                                    , T7MONT = '{toLastMonth}' 
                                    , T7ARRY = '{input.array6?.Trim().ToUpper()}' 
                                    , T7UDAT = '{updateDate}' 
                                    , T7UTIM = '{updateTime}' 
                                    , T7UUSR = '{input.userName?.Trim()}' 
                                    , T7UPGM = '{input.updByProgram?.Trim()}' 
                                    , T7UJOB = '{input.updWorkStation?.Trim()}' 
                                    , T7DEL = '{input.recordStatus?.Trim()}' 
                                WHERE T7TYSQ = '{input.typeSequence?.Trim().ToUpper()}' 
                                    AND T7STAS = '{input.custGrpStatus?.Trim().ToUpper()}'";
                }
                else
                {
                    cmdText = $@"INSERT INTO {_dc.SchemaDB()?.CS}.CSMCB17 (T7STAS,T7TYSQ,T7TYCD,T7TYDS,T7MONF,T7MONT,T7ARRY,T7UDAT,T7UTIM,T7UUSR,T7UPGM,T7UJOB,T7DEL) 
                                 VALUES ('{input.custGrpStatus?.Trim().ToUpper()}'
                                        , '{input.typeSequence?.Trim().ToUpper()}'
                                        , '{input.typeCode?.Trim()}'
                                        , '{input.typeDescription?.Trim()}'
                                        , '{fromLastMonth}' 
                                        , '{toLastMonth}'
                                        , '{input.array6?.Trim().ToUpper()}'
                                        , '{updateDate}'
                                        , '{updateTime}'
                                        , '{input.userName?.Trim()}'
                                        , '{input.updByProgram?.Trim()}'
                                        , '{input.updWorkStation?.Trim()}'
                                        , '{input.recordStatus?.Trim()}')";
                }
                response.message = msgError;
                var result = await _dc.Execute(cmdText, CommandType.Text);
                if (result.success)
                {
                    modelResult.success = result.success;
                    response.success = result.success;
                    response.message = "Insert Data Success";
                }

                #region Create HS
                string actionCode = "I";
                cmdText = $@"INSERT INTO {_dc.SchemaDB()?.CS}.CSMCB17HS (T7ACTN,T7STAS,T7TYSQ,T7TYCD,T7TYDS,T7MONF,T7MONT,T7ARRY,T7UDAT,T7UTIM,T7UUSR,T7UPGM,T7UJOB,T7DEL) 
                                 VALUES ('{actionCode}'
                                        , '{input.custGrpStatus?.Trim().ToUpper()}'
                                        , '{input.typeSequence?.Trim().ToUpper()}'
                                        , '{input.typeCode?.Trim()}'
                                        , '{input.typeDescription?.Trim()}'
                                        , '{fromLastMonth}' 
                                        , '{toLastMonth}'
                                        , '{input.array6?.Trim().ToUpper()}'
                                        , '{updateDate}'
                                        , '{updateTime}'
                                        , '{input.userName?.Trim()}'
                                        , '{input.updByProgram?.Trim()}'
                                        , '{input.updWorkStation?.Trim()}'
                                        , '{input.recordStatus?.Trim()}')";

                result = await _dc.Execute(cmdText, CommandType.Text);
                #endregion Create HS

                if (result.success)
                {
                    response.status = 200;
                    modelResult.success = result.success;
                    response.success = result.success;
                    response.message = "Insert Data Success";
                }
                else response.status = 400;

                response.data = modelResult;
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + result.message : result.message;
            }
            catch (Exception ex)
            {
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + ex.Message : ex.Message;
            }

            return await Task.FromResult(response);
        }

        private async Task<bool> CheckCustomerGroup(RequestSaveCustomerGroupModel input, string checkType)
        {
            bool popSuccess = true;
            bool checkData = true;
            try
            {
                var cmdText = "";
                if (checkType == "FindExist")
                {
                    cmdText = $@"SELECT A.T7STAS, A.T7TYSQ, A.T7TYCD, A.T7TYDS, A.T7MONF, A.T7MONT, A.T7ARRY, A.T7UDAT, A.T7UTIM, A.T7UUSR, A.T7UPGM, A.T7UJOB, A.T7DEL 
                            FROM {_dc.SchemaDB()?.CS}.CSMCB17 A 
                            WHERE (A.T7TYSQ = '{input.typeSequence?.Trim().ToUpper()}' OR A.T7TYCD = '{input.typeCode?.Trim().ToUpper()}') 
                            AND A.T7STAS = '{input.custGrpStatus?.Trim().ToUpper()}' 
                            AND A.T7DEL = ''";
                }
                else if (checkType == "FindObject")
                {
                    cmdText = $@"SELECT A.T7STAS, A.T7TYSQ, A.T7TYCD, A.T7TYDS, A.T7MONF, A.T7MONT, A.T7ARRY, A.T7UDAT, A.T7UTIM, A.T7UUSR, A.T7UPGM, A.T7UJOB, A.T7DEL 
                            FROM {_dc.SchemaDB()?.CS}.CSMCB17 A 
                            WHERE A.T7TYSQ = '{input.typeSequence?.Trim().ToUpper()}' 
                            AND A.T7STAS = '{input.custGrpStatus?.Trim().ToUpper()}' 
                            AND A.T7DEL = 'X'";
                }
                var dr = await _dc.Get<GetDataCustomerGroupModel>(cmdText, CommandType.Text);
                if (!dr.success)
                {
                    checkData = false;
                }
            }
            catch (Exception ex)
            {
                popSuccess = false;
                m_LastError = ex.Message.ToString();
            }
            return (checkData && popSuccess);
        }

        public async Task<ResponseModel> UpdateCustomerGroupData(RequestSaveCustomerGroupModel input)
        {
            var response = new ResponseModel();
            var modelResult = new ResponseModel();
            try
            {
                int updateDate = int.TryParse(dateTime.ToString("yyMMdd", m_DThai), out updateDate) ? updateDate : 0;
                int updateTime = int.TryParse(dateTime.ToString("HHmmss", m_DThai), out updateTime) ? updateTime : 0;

                int intmonth = 0;
                int fromLastMonth = int.TryParse(input.fromLastMonth, out intmonth) ? intmonth : 0;
                int toLastMonth = int.TryParse(input.toLastMonth, out intmonth) ? intmonth : 0;

                var cmdText = $@"UPDATE {_dc.SchemaDB()?.CS}.CSMCB17  
                                 SET T7TYCD = '{input.typeCode?.Trim()}' 
                                    , T7TYDS = '{input.typeDescription?.Trim()}' 
                                    , T7MONF = '{fromLastMonth}' 
                                    , T7MONT = '{toLastMonth}' 
                                    , T7ARRY = '{input.array6?.Trim().ToUpper()}' 
                                    , T7UDAT = '{updateDate}' 
                                    , T7UTIM = '{updateTime}' 
                                    , T7UUSR = '{input.userName?.Trim()}' 
                                    , T7UPGM = '{input.updByProgram?.Trim()}' 
                                    , T7UJOB = '{input.updWorkStation?.Trim()}' 
                                    , T7DEL = '{input.recordStatus?.Trim()}' 
                                WHERE T7TYSQ = '{input.typeSequence?.Trim().ToUpper()}' 
                                    AND T7STAS = '{input.custGrpStatus?.Trim().ToUpper()}'";

                var result = await _dc.Execute(cmdText, CommandType.Text);
                if (result.success)
                {
                    modelResult.success = result.success;
                    response.success = result.success;
                    response.message = "Update Data Success";
                }

                #region Update HS
                string actionCode = "U";
                cmdText = $@"INSERT INTO {_dc.SchemaDB()?.CS}.CSMCB17HS (T7ACTN,T7STAS,T7TYSQ,T7TYCD,T7TYDS,T7MONF,T7MONT,T7ARRY,T7UDAT,T7UTIM,T7UUSR,T7UPGM,T7UJOB,T7DEL) 
                                 VALUES ('{actionCode}'
                                        , '{input.custGrpStatus?.Trim().ToUpper()}'
                                        , '{input.typeSequence?.Trim().ToUpper()}'
                                        , '{input.typeCode?.Trim()}'
                                        , '{input.typeDescription?.Trim()}'
                                        , '{fromLastMonth}' 
                                        , '{toLastMonth}'
                                        , '{input.array6?.Trim().ToUpper()}'
                                        , '{updateDate}'
                                        , '{updateTime}'
                                        , '{input.userName?.Trim()}'
                                        , '{input.updByProgram?.Trim()}'
                                        , '{input.updWorkStation?.Trim()}'
                                        , '{input.recordStatus?.Trim()}')";

                result = await _dc.Execute(cmdText, CommandType.Text);
                #endregion

                if (result.success)
                {
                    response.status = 200;
                    response.success = true;
                    response.message = "Insert Data Success";
                    modelResult.success = result.success;
                }
                else response.status = 400;

                response.data = modelResult;
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + result.message : result.message;
            }
            catch (Exception ex)
            {
                response.message = ex.Message;
            }
            return await Task.FromResult(response);
        }

        public async Task<ResponseModel> DeleteCustomerGroupData(RequestSaveCustomerGroupModel input)
        {
            var response = new ResponseModel();
            var modelResult = new ResultSaveCustomerGroupModel();
            try
            {
                int updateDate = int.TryParse(dateTime.ToString("yyMMdd", m_DThai), out updateDate) ? updateDate : 0;
                int updateTime = int.TryParse(dateTime.ToString("HHmmss", m_DThai), out updateTime) ? updateTime : 0;

                int intmonth = 0;
                int fromLastMonth = int.TryParse(input.fromLastMonth, out intmonth) ? intmonth : 0;
                int toLastMonth = int.TryParse(input.toLastMonth, out intmonth) ? intmonth : 0;

                var cmdText = $@"UPDATE {_dc.SchemaDB()?.CS}.CSMCB17  
                                 SET  T7UDAT = '{updateDate}' 
                                    , T7UTIM = '{updateTime}' 
                                    , T7UUSR = '{input.userName?.Trim()}' 
                                    , T7UPGM = '{input.updByProgram?.Trim()}' 
                                    , T7UJOB = '{input.updWorkStation?.Trim()}' 
                                    , T7DEL = '{input.recordStatus?.Trim()}' 
                                WHERE T7TYSQ = '{input.typeSequence?.Trim().ToUpper()}' 
                                    AND T7STAS = '{input.custGrpStatus?.Trim().ToUpper()}'";
                var result = await _dc.Execute(cmdText, CommandType.Text);
                if (result.success)
                {
                    modelResult.success = result.success;
                    response.success = result.success;
                    response.message = "Insert Data Success";
                }

                #region Delete HS
                string actionCode = "D";
                cmdText = $@"INSERT INTO {_dc.SchemaDB()?.CS}.CSMCB17HS (T7ACTN,T7STAS,T7TYSQ,T7TYCD,T7TYDS,T7MONF,T7MONT,T7ARRY,T7UDAT,T7UTIM,T7UUSR,T7UPGM,T7UJOB,T7DEL) 
                                 VALUES ('{actionCode}'
                                        , '{input.custGrpStatus?.Trim().ToUpper()}'
                                        , '{input.typeSequence?.Trim().ToUpper()}'
                                        , '{input.typeCode?.Trim()}'
                                        , '{input.typeDescription?.Trim()}'
                                        , '{fromLastMonth}' 
                                        , '{toLastMonth}'
                                        , '{input.array6?.Trim().ToUpper()}'
                                        , '{updateDate}'
                                        , '{updateTime}'
                                        , '{input.userName?.Trim()}'
                                        , '{input.updByProgram?.Trim()}'
                                        , '{input.updWorkStation?.Trim()}'
                                        , '{input.recordStatus?.Trim()}')";

                result = await _dc.Execute(cmdText, CommandType.Text);
                #endregion Delete HS

                if (result.success)
                {
                    modelResult.success = result.success;
                    response.success = result.success;
                }

                response.data = modelResult;
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + result.message : result.message;
            }
            catch (Exception ex)
            {
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + ex.Message : ex.Message;
            }

            return await Task.FromResult(response);
        }
        #endregion

        #region Ranking Code
        public async Task<ResponseModel> GetDataRankingCode(RequestDataRankingModel input)
        {
            var response = new ResponseModel();
            try
            {
                string strWhere = "";
                string strSQLDetail = "";
                var cmdText = "";
                if (input.isShowAll)
                {
                    cmdText = $@"SELECT T9CODE, T9DESC, T9PERC,T9BALA,T9CASH,T9CASE FROM {_dc.SchemaDB()?.CS}.CSMCB09";
                }
                else
                {
                    //Search in Detail
                    if (input.biz.ToString() != "Select Biz")
                    {
                        strSQLDetail = " WHERE T1BIZ = '" + input.biz.Trim().ToUpper() + "' ";
                    }

                    if (input.due.ToString() != "Select Due")
                    {
                        if (strSQLDetail == "")
                        {
                            strSQLDetail += " WHERE ";
                        }
                        else
                        {
                            strSQLDetail += " AND ";
                        }

                        strSQLDetail += "  T1DUE = " + Convert.ToInt32(input.due.Trim()).ToString() + " ";
                    }

                    if (input.odStatus.ToString() != "Select OD Status")
                    {

                        if (strSQLDetail == "")
                        {
                            strSQLDetail += " WHERE ";
                        }
                        else
                        {
                            strSQLDetail += " AND ";
                        }
                        strSQLDetail += "  T1ODST = '" + input.odStatus.Trim().ToString() + "' ";
                    }

                    if (input.odTerm.ToString() != "Select OD Term")
                    {

                        if (strSQLDetail == "")
                        {
                            strSQLDetail += " WHERE ";
                        }
                        else
                        {
                            strSQLDetail += " AND ";
                        }
                        strSQLDetail += "  T1ODT = " + Convert.ToInt32(input.odTerm.Trim()).ToString() + " ";
                    }


                    if (strSQLDetail != "")
                    {
                        strSQLDetail = $@"SELECT T1CODE FROM {_dc.SchemaDB()?.CS}.CSMCB10";
                    }

                    cmdText = $@"SELECT ROW_NUMBER() OVER(ORDER BY T9CODE ASC) AS id,T9CODE, T9DESC, T9PERC,T9BALA,T9CASH,T9CASE FROM {_dc.SchemaDB()?.CS}.CSMCB09 ";

                    if (string.IsNullOrEmpty(input.rankCode))
                    {
                        strWhere += " WHERE T9CODE = '" + input.rankCode.Trim().ToUpper() + "' AND T9DEL = '' ";

                        if (strSQLDetail != "")
                        {
                            strWhere += "AND T9CODE IN (" + strSQLDetail + ")";
                        }
                    }
                    else
                    {
                        if (strSQLDetail == "")
                        {
                            response.message = "Plese input some find value";
                            return response;
                        }
                        else
                        {
                            strWhere += " WHERE T9CODE IN (" + strSQLDetail + ")";
                        }
                    }
                }
                cmdText += strWhere + " ORDER BY T9CODE ";

                var result = await _dc.Get<List<ResultGetListRankingModel>>(cmdText, CommandType.Text);
                if (result.success)
                {
                    response.status = 200;
                    response.success = result.success;
                    response.data = result.data.ToList();
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return await Task.FromResult(response);
        }

        public async Task<ResponseModel> GetNewRankingCode()
        {
            var response = new ResponseModel();
            try
            {
                var cmdText = $@"SELECT TOP(1) T9CODE FROM {_dc.SchemaDB()?.CS}.CSMCB09 WHERE T9DEL = '' ORDER BY T9CODE DESC";
                var result = await _dc.Get<List<ResultGetListRankingModel>>(cmdText, CommandType.Text);
                if (result.success)
                {
                    response.status = 200;
                    response.success = result.success;
                    response.data = result.data.ToList();
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return await Task.FromResult(response);
        }

        public async Task<ResponseModel> CreateRankingCode(RequestSaveRankingModel input)
        {
            var response = new ResponseModel();
            try
            {
                string cmdText = "";
                string msgError = "";
                int updateDate = int.TryParse(dateTime.ToString("yyMMdd", m_DThai), out updateDate) ? updateDate : 0;
                int updateTime = int.TryParse(dateTime.ToString("HHmmss", m_DThai), out updateTime) ? updateTime : 0;

                if (this.CheckRanking(input, "FindObject", ref msgError))
                {
                    cmdText = $@"UPDATE {_dc.SchemaDB()?.CS}.CSMCB09
                                        SET T9DESC = '{input.description.Trim()}',
                                            T9PERC = '{input.rankUsePercentage.Trim()}',
                                            T9BALA = '{input.rankBalance}',
                                            T9CASH = '{input.rankCash}',
                                            T9CASE = '{input.rankCase}',
                                            T9UDAT = '{updateDate}',
                                            T9UTIM = '{updateTime}',
                                            T9UUSR = '{input.username?.Trim()}',
                                            T9UPGM = '',
                                            T9UJOB = '',
                                            T9DEL = ''
                                        WHERE T9CODE = '{input.rankCode.Trim().ToString().ToUpper()}'";
                }
                else
                {
                    cmdText = $@"INSERT INTO {_dc.SchemaDB()?.CS}.CSMCB09 (T9CODE,T9DESC,T9PERC,T9BALA,T9CASH,T9CASE,T9UDAT,T9UTIM,T9UUSR,T9UPGM,T9UJOB,T9DEL)
                                            VALUES ('{input.rankCode.Trim().ToString().ToUpper()}',
                                                    '{input.description.Trim()}',
                                                    '{input.rankUsePercentage.Trim()}',
                                                    '{input.rankBalance}',
                                                    '{input.rankCash}',
                                                    '{input.rankCase}',
                                                    '{updateDate}',
                                                    '{updateTime}',
                                                    '{input.username?.Trim()}',
                                                    '',
                                                    '',
                                                    '')";
                }

                var result = await _dc.Execute(cmdText, CommandType.Text);

                if (result.success)
                {
                    response.success = result.success;
                    response.message = result.message;
                    response.status = 200;
                }
                else
                {
                    response.message = result.message;
                    response.status = 400;
                }
            }
            catch (Exception ex)
            {
                response.message = ex.Message;
            }
            return await Task.FromResult(response);
        }

        public bool CheckRanking(RequestSaveRankingModel input, string checkType, ref string msgError) // FindExist = '', FindObject = 'X
        {
            bool popSuccess;
            var data = new ResultGetListRankingModel();
            try
            {
                var cmdText = "";
                if (checkType == "FindExist")
                {
                    //cmdText = $@"SELECT * FROM {_dc.SchemaDB()?.CS}.CSMCB11 WHERE T1PCNO = '{input.pcName?.Trim().ToUpper()}' AND T1SDAT  = '{input.startDate?.ToString().Trim()}' AND T1STIM  = '{input.startTime?.ToString().Trim()}' AND T1DEL  = ''";

                }
                else if (checkType == "FindObject")
                {
                    cmdText = $@"SELECT * FROM {_dc.SchemaDB()?.CS}.CSMCB09 WHERE T9CODE = '{input.rankCode?.Trim().ToUpper()}'  AND T9DEL  = ''";
                }
                var res = _dc.Get<ResultGetListRankingModel>(cmdText, CommandType.Text);
                if (res.Result.data.T9BALA == 0 && res.Result.data.T9CASE == 0 && res.Result.data.T9CASH == 0 && res.Result.data.T9CODE == null && res.Result.data.T9DESC == null && res.Result.data.T9PERC == null)
                {
                    popSuccess = false;
                }
                else
                {
                    popSuccess = true;
                }
                data = res.Result.data;
            }
            catch (Exception ex)
            {
                popSuccess = false;
                msgError = ex.Message.ToString();
            }
            return (data != null) && popSuccess;
        }

        public async Task<ResponseModel> UpdateRankingCode(ResultGetListRankingDetailModel input)
        {
            var response = new ResponseModel();
            try
            {
                int updateDate;
                int updateTime;
                updateDate = int.TryParse(dateTime.ToString("yyMMdd", m_DThai), out updateDate) ? updateDate : 0;
                updateTime = int.TryParse(dateTime.ToString("HHmmss", m_DThai), out updateTime) ? updateTime : 0;
                var cmdText = $@"INSERT INTO {_dc.SchemaDB()?.CS}.CSMCB10 (T1CODE,T1BIZ,T1DUE,T1ODST,T1ODT,T1UDAT,T1UTIM,T1UUSR,T1UPGM,T1UJOB,T1DEL)
                                            VALUES ('{input.T1CODE.Trim()}',
                                                    '{input.T1BIZ.Trim()}',
                                                    '{input.T1DUE}',
                                                    '{input.T1ODST.Trim()}',
                                                    '{input.T1ODT}',
                                                    '{updateDate}',
                                                    '{updateTime}',
                                                    '{input.T1UUSR.Trim()}',
                                                    '',
                                                    '',
                                                    '')";
                var result = await _dc.Execute(cmdText, CommandType.Text);

                if (result.success)
                {
                    response.success = result.success;
                    response.message = result.message;
                    response.status = 200;
                }
                else
                {
                    response.message = result.message;
                    response.status = 400;
                }
            }
            catch (Exception ex)
            {
                response.message = ex.Message;
            }
            return await Task.FromResult(response);
        }

        public async Task<ResponseModel> DeleteRankingCode(RequestSaveRankingModel input)
        {
            var response = new ResponseModel();
            try
            {
                bool success = false;
                success = await DeleteDetail(input);
                if (success)
                {
                    success = await DeleteHeader(input);
                }
                if (success)
                {
                    response.status = 200;
                    response.success = success;
                    response.message = "Delete Data Success";
                }
                else
                {
                    response.message = "";
                    response.status = 400;
                }
            }
            catch (Exception ex)
            {
                response.message = ex.Message;
            }
            return await Task.FromResult(response);
        }

        public async Task<ResponseModel> Find_RankHead(RequestSaveRankingModel input)
        {
            var response = new ResponseModel();
            try
            {
                var cmdText = $@"SELECT T9CODE,T9DESC,T9PERC,T9BALA,T9CASH,T9CASE FROM {_dc.SchemaDB()?.CS}.CSMCB09 LEFT JOIN {_dc.SchemaDB()?.CS}.CSMCB10 ON (T9CODE=T1CODE AND T1DEL='') WHERE T9CODE='" + input.rankCode.Trim().ToUpper() + "' AND T9DEL='' ";
                var result = await _dc.Get<List<ResultGetListRankingModel>>(cmdText, CommandType.Text);
                if (result.success)
                {
                    response.data = result.data.ToList();
                    response.status = 200;
                    response.success = result.success;
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return response;
        }

        public async Task<ResponseModel> Find_RankDetail(RequestSaveRankingModel input)
        {
            var response = new ResponseModel();
            try
            {
                var cmdText = $@"SELECT T1CODE,T1BIZ,T1DUE,T1ODST,T1ODT,'' AS T1DEL FROM {_dc.SchemaDB()?.CS}.CSMCB10 WHERE T1CODE='" + input.rankCode.Trim().ToUpper() + "' AND T1DEL='' ";
                var result = await _dc.Get<List<ResultGetListRankingDetailModel>>(cmdText, CommandType.Text);
                if (result.success)
                {
                    response.data = result.data.ToList();
                    response.status = 200;
                    response.success = result.success;
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return await Task.FromResult(response);
        }

        public async Task<bool> DeleteDetail(RequestSaveRankingModel request)
        {
            bool result = false;
            try
            {
                var cmdText = $@"DELETE FROM {_dc.SchemaDB()?.CS}.CSMCB10  WHERE T1CODE = '{request.rankCode.Trim().ToString().ToUpper()}' ";
                var res = await _dc.Execute(cmdText, CommandType.Text);
                if (res.success) { result = true; }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }

        public async Task<bool> DeleteHeader(RequestSaveRankingModel request)
        {
            bool result = false;
            try
            {
                var cmdText = $@"DELETE FROM {_dc.SchemaDB()?.CS}.CSMCB09  WHERE T9CODE = '{request.rankCode.Trim().ToString().ToUpper()}' ";
                var res = await _dc.Execute(cmdText, CommandType.Text);
                if (res.success) { result = true; }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }
        #endregion

        #region Section User
        public async Task<ResponseModel> GetListSectionUser(RequestSectionUserModel input)
        {
            var response = new ResponseModel();
            try
            {
                string strWhere = "";

                var cmdText = $@"SELECT A.T9SECT, A.T9DPCD, A.T9DPUS, A.T9UDAT, A.T9UTIM, A.T9UUSR, A.T9UPGM, A.T9UJOB, A.T9DEL 
                            FROM {_dc.SchemaDB()?.CS}.CSMCB19 A";

                strWhere = $"WHERE A.T9DEL = ''";

                if (!string.IsNullOrWhiteSpace(input.calType))
                {
                    strWhere += $" AND A.T9DPCD = '{input.calType?.Trim().ToUpper()}'";
                }

                if (!string.IsNullOrWhiteSpace(input.sectionUser))
                {
                    strWhere += $" AND A.T9SECT = '{input.sectionUser?.Trim().ToUpper()}'";
                }

                if (!string.IsNullOrWhiteSpace(input.departmentUser))
                {
                    strWhere += $" AND A.T9DPUS = '{input.departmentUser?.Trim().ToUpper()}'";
                }

                cmdText += $" {strWhere} ORDER BY A.T9DPUS,A.T9SECT,A.T9UDAT,A.T9UTIM ";

                var result = await _dc.Get<List<GetSectionUserModel>>(cmdText, CommandType.Text);
                if (result.success)
                {
                    response.status = 200;
                    response.success = result.success;
                    response.data = result.data.ToList();
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return await Task.FromResult(response);
        }

        public async Task<ResponseModel> GetSectionUser(RequestSectionUserModel input)
        {
            var response = new ResponseModel();
            try
            {
                var cmdText = $@"SELECT A.T9SECT, A.T9DPCD, A.T9DPUS, A.T9UDAT, A.T9UTIM, A.T9UUSR, A.T9UPGM, A.T9UJOB, A.T9DEL 
                            FROM {_dc.SchemaDB()?.CS}.CSMCB19 A 
                            WHERE A.T9DPUS = '{input.departmentUser?.Trim().ToUpper()}' 
                            AND A.T9SECT = '{input.sectionUser?.Trim().ToUpper()}' 
                            AND A.T9DPCD = '{input.calType?.Trim().ToUpper()}'";


                var result = await _dc.Get<GetSectionUserModel>(cmdText, CommandType.Text);
                if (result.success)
                {
                    response.status = 200;
                    response.success = result.success;
                    response.data = result.data;
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return await Task.FromResult(response);
        }

        public async Task<ResponseModel> CreateSectionUserData(RequestSaveSectionUserModel input)
        {
            var response = new ResponseModel();
            try
            {
                string cmdText = "";
                int updateDate = int.TryParse(dateTime.ToString("yyMMdd", m_DThai), out updateDate) ? updateDate : 0;
                int updateTime = int.TryParse(dateTime.ToString("HHmmss", m_DThai), out updateTime) ? updateTime : 0;

                if (await this.CheckSectionUser(input, "FindExist"))
                {
                    m_LastError = ", this Code already exists.";
                    response.message = m_LastError;
                    response.status = 400;
                    response.success = false;

                    return response;
                }
                else if (await this.CheckSectionUser(input, "FindObject"))
                {
                    cmdText = $@"UPDATE {_dc.SchemaDB()?.CS}.CSMCB19 SET  
                                    T9DPUS = '{input.departmentUser?.Trim().ToUpper()}'
                                    , T9DPCD = '{input.calType?.Trim().ToUpper()}'
                                    , T9UDAT = '{updateDate}'
                                    , T9UTIM = '{updateTime}'
                                    , T9UUSR = '{input.userName?.Trim()}'
                                    , T9UPGM = '{input.updByProgram?.Trim()}'
                                    , T9UJOB = '{input.updWorkStation?.Trim()}'
                                    , T9DEL = '{input.recordStatus?.Trim()}' 
                                WHERE T9SECT = '{input.sectionUser?.Trim().ToUpper()}'";
                }
                else
                {
                    cmdText = $@"INSERT INTO {_dc.SchemaDB()?.CS}.CSMCB19 (T9DPUS,T9SECT,T9DPCD,T9UDAT,T9UTIM,T9UUSR,T9UPGM,T9UJOB,T9DEL)
                                 VALUES ('{input.departmentUser?.Trim().ToUpper()}'
                                        , '{input.sectionUser?.Trim().ToUpper()}'
                                        , '{input.calType?.Trim().ToUpper()}'
                                        , '{updateDate}'
                                        , '{updateTime}'
                                        , '{input.userName?.Trim()}'
                                        , '{input.updByProgram?.Trim()}'
                                        , '{input.updWorkStation?.Trim()}'
                                        , '{input.recordStatus?.Trim()}')";
                }

                var dr = await _dc.Execute(cmdText, CommandType.Text);

                if (dr.success)
                {
                    response.success = dr.success;
                    response.message = dr.message;
                    response.status = 200;
                }
                else
                {
                    response.message = dr.message;
                    response.status = 400;
                }
            }
            catch (Exception ex)
            {
                response.success = false;
                response.message = ex.Message;
            }
            return await Task.FromResult(response);
        }

        private async Task<bool> CheckSectionUser(RequestSaveSectionUserModel input, string checkType)
        {
            bool popSuccess = true;
            bool checkData = true;
            try
            {
                var cmdText = "";
                if (checkType == "FindExist")
                {
                    cmdText = $@"SELECT A.T9SECT, A.T9DPCD, A.T9DPUS, A.T9UDAT, A.T9UTIM, A.T9UUSR, A.T9UPGM, A.T9UJOB, A.T9DEL 
                            FROM {_dc.SchemaDB()?.CS}.CSMCB19 A 
                            WHERE A.T9DPUS = '{input.departmentUser?.Trim().ToUpper()}' 
                            AND A.T9SECT = '{input.sectionUser?.Trim().ToUpper()}' 
                            AND A.T9DPCD = '{input.calType?.Trim().ToUpper()}'
                            AND A.T9DEL = ''";
                }
                else if (checkType == "FindObject")
                {
                    cmdText = $@"SELECT A.T9SECT, A.T9DPCD, A.T9DPUS, A.T9UDAT, A.T9UTIM, A.T9UUSR, A.T9UPGM, A.T9UJOB, A.T9DEL 
                            FROM {_dc.SchemaDB()?.CS}.CSMCB19 A 
                            WHERE A.T9SECT = '{input.sectionUser?.Trim().ToUpper()}'
                            AND A.T9DEL = 'X'";
                }

                var dr = await _dc.Get<GetSectionUserModel>(cmdText, CommandType.Text);
                if (!dr.success)
                {
                    checkData = false;
                }
            }
            catch (Exception ex)
            {
                popSuccess = false;
                m_LastError = ex.Message.ToString();
            }
            return checkData && popSuccess;
        }

        public async Task<ResponseModel> UpdateSectionUserData(RequestSaveSectionUserModel input)
        {
            var response = new ResponseModel();
            try
            {
                int updateDate = int.TryParse(dateTime.ToString("yyMMdd", m_DThai), out updateDate) ? updateDate : 0;
                int updateTime = int.TryParse(dateTime.ToString("HHmmss", m_DThai), out updateTime) ? updateTime : 0;
                var cmdText = $@"UPDATE {_dc.SchemaDB()?.CS}.CSMCB19 SET  
                                    T9DPUS = '{input.departmentUser?.Trim().ToUpper()}'
                                    , T9DPCD = '{input.calType?.Trim().ToUpper()}'
                                    , T9UDAT = '{updateDate}'
                                    , T9UTIM = '{updateTime}'
                                    , T9UUSR = '{input.userName?.Trim()}'
                                    , T9UPGM = '{input.updByProgram?.Trim()}'
                                    , T9UJOB = '{input.updWorkStation?.Trim()}'
                                    , T9DEL = '{input.recordStatus?.Trim()}' 
                                WHERE T9SECT = '{input.sectionUser?.Trim().ToUpper()}'";
                var result = await _dc.Execute(cmdText, CommandType.Text);
                if (result.success)
                {
                    response.success = result.success;
                    response.message = result.message;
                }
                else
                {
                    response.message = $"Data Not Update ({result.message})";
                    response.status = 400;
                }
            }
            catch (Exception ex)
            {
                response.message = ex.Message;
            }
            return await Task.FromResult(response);
        }

        public async Task<ResponseModel> DeleteSectionUserData(RequestSaveSectionUserModel input)
        {
            var response = new ResponseModel();
            try
            {
                int updateDate = int.TryParse(dateTime.ToString("yyMMdd", m_DThai), out updateDate) ? updateDate : 0;
                int updateTime = int.TryParse(dateTime.ToString("HHmmss", m_DThai), out updateTime) ? updateTime : 0;

                input.recordStatus = "X";

                var cmdText = $@"UPDATE {_dc.SchemaDB()?.CS}.CSMCB19 SET T9DEL = '{input.recordStatus?.Trim()}' 
                                WHERE T9DPUS = '{input.departmentUser?.Trim().ToUpper()}' 
                                AND T9SECT = '{input.sectionUser?.Trim().ToUpper()}' 
                                AND T9DPCD = '{input.calType?.Trim().ToUpper()}'";
                var result = await _dc.Execute(cmdText, CommandType.Text);
                if (result.success)
                {
                    response.status = 200;
                    response.success = result.success;
                    response.message = "Delete Data Success";
                }
                else
                {
                    response.message = result.message;
                    response.status = 400;
                }
            }
            catch (Exception ex)
            {
                response.message = ex.Message;
            }
            return await Task.FromResult(response);
        }
        #endregion

        #region Type And Result
        public async Task<ResponseModel> GetListTypeCodeByTypeCode(RequestGetDataTypeAndResultModel input)
        {
            var response = new ResponseModel();
            try
            {
                string strWhere = "";

                var cmdText = $@"SELECT DISTINCT(A.T8TYCD) FROM {_dc.SchemaDB()?.CS}.CSMCB18 A";

                strWhere = $"WHERE A.T8DEL = ''";

                if (!string.IsNullOrWhiteSpace(input.typeCode))
                {
                    strWhere += $" and A.T8TYCD = '{input.typeCode?.Trim().ToUpper()}'";
                }

                cmdText += $" {strWhere} order by A.T8TYCD ";

                var result = await _dc.Get<List<GetDataTypeCodeModel>>(cmdText, CommandType.Text);
                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = result.data.ToList();
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return await Task.FromResult(response);
        }

        public async Task<ResponseModel> GetListResultCodeByTypeCode(RequestGetDataTypeAndResultModel input)
        {
            var response = new ResponseModel();
            try
            {
                string strWhere = "";

                var cmdText = $@"SELECT DISTINCT(A.T8RSCD) FROM {_dc.SchemaDB()?.CS}.CSMCB18 A";

                strWhere = $"WHERE A.T8DEL = ''";

                if (!string.IsNullOrWhiteSpace(input.typeCode))
                {
                    strWhere += $" and A.T8TYCD = '{input.typeCode?.Trim().ToUpper()}'";
                }

                cmdText += $" {strWhere} order by A.T8RSCD ";

                var result = await _dc.Get<List<GetDataResultCodeModel>>(cmdText, CommandType.Text);
                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = result.success;
                    response.data = result.data.ToList();
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return await Task.FromResult(response);
        }

        public async Task<ResponseModel> GetListTypeAndResultByTypeCodeResultCode(RequestGetDataTypeAndResultModel input)
        {
            var response = new ResponseModel();
            try
            {
                string strWhere = "";

                var cmdText = $@"SELECT A.T8TYCD,A.T8RSCD,CAST(A.T8UDAT AS VARCHAR) AS T8UDAT ,CAST(A.T8UTIM AS VARCHAR) AS T8UTIM,A.T8UUSR,A.T8UPGM,A.T8UJOB,A.T8DEL FROM {_dc.SchemaDB()?.CS}.CSMCB18 A";

                strWhere = $"WHERE A.T8DEL = ''";

                if (!string.IsNullOrWhiteSpace(input.typeCode))
                {
                    strWhere += $" AND A.T8TYCD = '{input.typeCode?.Trim().ToUpper()}'";
                }

                if (!string.IsNullOrWhiteSpace(input.resultCode))
                {
                    strWhere += $" AND A.T8RSCD = '{input.resultCode?.Trim().ToUpper()}'";
                }

                cmdText += $" {strWhere} ORDER BY A.T8TYCD, A.T8RSCD ";

                var result = await _dc.Get<List<GetDataTypeCodeAndResultCodeModel>>(cmdText, CommandType.Text);
                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = result.data.ToList();
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return await Task.FromResult(response);
        }

        public async Task<ResponseModel> GetTypeAndResultByTypeCodeResultCode(RequestGetDataTypeAndResultModel input)
        {
            var response = new ResponseModel();
            try
            {
                var cmdText = $@"SELECT A.T8TYCD,A.T8RSCD,A.T8UDAT,A.T8UTIM,A.T8UUSR,A.T8UPGM,A.T8UJOB,A.T8DEL
                                FROM {_dc.SchemaDB()?.CS}.CSMCB18 A 
                                WHERE A.T8TYCD = '{input.typeCode?.Trim().ToUpper()}' 
                                    AND A.T8RSCD = '{input.resultCode?.Trim().ToUpper()}'";


                var result = await _dc.Get<GetDataTypeCodeAndResultCodeModel>(cmdText, CommandType.Text);
                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = result.success;
                    response.data = result.data;
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return await Task.FromResult(response);
        }

        public async Task<ResponseModel> CreateTypeAndResultData(RequestSaveTypeAndResultModel input)
        {
            var response = new ResponseModel();
            var modelResult = new ResultSaveTypeAndResultModel();
            try
            {
                string msgError = "";
                string cmdText = "";
                int updateDate = int.TryParse(dateTime.ToString("yyMMdd", m_DThai), out updateDate) ? updateDate : 0;
                int updateTime = int.TryParse(dateTime.ToString("HHmmss", m_DThai), out updateTime) ? updateTime : 0;

                if (await this.CheckTypeAndResult(input, "FindExist"))
                {
                    msgError = ", this Code already exists.";
                    modelResult.lastError = msgError;
                    response.message = msgError;
                    response.data = modelResult;
                    response.success = true;
                    return await Task.FromResult(response);
                }
                else if (await this.CheckTypeAndResult(input, "FindObject"))
                {
                    cmdText = $@"UPDATE {_dc.SchemaDB()?.CS}.CSMCB18 SET  
                                      T8UDAT = '{updateDate}' 
                                    , T8UTIM = '{updateTime}' 
                                    , T8UUSR = '{input.userName?.Trim()}' 
                                    , T8UPGM = '{input.updByProgram?.Trim()}' 
                                    , T8UJOB = '{input.updWorkStation?.Trim()}' 
                                    , T8DEL = '{input.recordStatus?.Trim()}' 
                                WHERE T8TYCD = '{input.typeCode?.Trim().ToUpper()}' 
                                    AND T8RSCD = '{input.resultCode?.Trim().ToUpper()}'";
                }
                else
                {
                    cmdText = $@"INSERT INTO {_dc.SchemaDB()?.CS}.CSMCB18 (T8TYCD,T8RSCD,T8UDAT,T8UTIM,T8UUSR,T8UPGM,T8UJOB,T8DEL)
                                 VALUES ('{input.typeCode?.Trim().ToUpper()}'
                                        , '{input.resultCode?.Trim().ToUpper()}'
                                        , '{updateDate}'
                                        , '{updateTime}'
                                        , '{input.userName?.Trim()}'
                                        , '{input.updByProgram?.Trim()}'
                                        , '{input.updWorkStation?.Trim()}'
                                        , '{input.recordStatus?.Trim()}')";
                }

                var result = await _dc.Execute(cmdText, CommandType.Text);
                if (result.success)
                {
                    modelResult.success = result.success;
                    response.success = result.success;
                    response.message = "Insert Data Success";
                }

                response.data = modelResult;
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + result.message : result.message;
            }
            catch (Exception ex)
            {
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + ex.Message : ex.Message;
            }

            return await Task.FromResult(response);
        }

        private async Task<bool> CheckTypeAndResult(RequestSaveTypeAndResultModel input, string checkType)
        {
            bool popSuccess = false;
            bool checkData = false;
            try
            {
                var cmdText = "";
                if (checkType == "FindExist")
                {
                    cmdText = $@"SELECT A.T8TYCD,A.T8RSCD,A.T8UDAT,A.T8UTIM,A.T8UUSR,A.T8UPGM,A.T8UJOB,A.T8DEL 
                            FROM {_dc.SchemaDB()?.CS}.CSMCB18 A 
                            WHERE A.T8TYCD = '{input.typeCode?.Trim().ToUpper()}' 
                            AND A.T8DEL = ''";
                }
                else if (checkType == "FindObject")
                {
                    cmdText = $@"SELECT A.T8TYCD,A.T8RSCD,A.T8UDAT,A.T8UTIM,A.T8UUSR,A.T8UPGM,A.T8UJOB,A.T8DEL 
                            FROM {_dc.SchemaDB()?.CS}.CSMCB18 A 
                            WHERE A.T8TYCD = '{input.typeCode?.Trim().ToUpper()}' 
                            AND A.T8RSCD = '{input.resultCode?.Trim().ToUpper()}' 
                            AND A.T8DEL = 'X'";
                }

                var dr = await _dc.Get<GetDataTypeCodeAndResultCodeModel>(cmdText, CommandType.Text);
                if (dr.success)
                {
                    checkData = true;
                    popSuccess = true;
                }
            }
            catch (Exception ex)
            {
                popSuccess = false;
                m_LastError = ex.Message.ToString();
            }
            return checkData && popSuccess;
        }

        public async Task<ResponseModel> UpdateTypeAndResultData(RequestSaveTypeAndResultModel input)
        {
            var response = new ResponseModel();
            var modelResult = new ResultSaveTypeAndResultModel();
            try
            {
                int updateDate = int.TryParse(dateTime.ToString("yyMMdd", m_DThai), out updateDate) ? updateDate : 0;
                int updateTime = int.TryParse(dateTime.ToString("HHmmss", m_DThai), out updateTime) ? updateTime : 0;
                var cmdText = $@"UPDATE {_dc.SchemaDB()?.CS}.CSMCB18  
                                 SET T8RSCD = '{input.resultCode?.Trim().ToUpper()}' 
                                    , T8UDAT = '{updateDate}' 
                                    , T8UTIM = '{updateTime}' 
                                    , T8UUSR = '{input.userName?.Trim()}' 
                                    , T8UPGM = '{input.updByProgram?.Trim()}' 
                                    , T8UJOB = '{input.updWorkStation?.Trim()}' 
                                    , T8DEL = '{input.recordStatus?.Trim()}' 
                                 WHERE T8TYCD = '{input.typeCode?.Trim().ToUpper()}'";

                var result = await _dc.Execute(cmdText, CommandType.Text);
                if (result.success)
                {
                    modelResult.success = result.success;
                    response.success = result.success;
                }

                response.data = modelResult;
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + result.message : result.message;
            }
            catch (Exception ex)
            {
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + ex.Message : ex.Message;
            }

            return await Task.FromResult(response);
        }

        public async Task<ResponseModel> DeleteTypeAndResultData(RequestSaveTypeAndResultModel input)
        {
            var response = new ResponseModel();
            var modelResult = new ResultSaveTypeAndResultModel();
            try
            {
                int updateDate = int.TryParse(dateTime.ToString("yyMMdd", m_DThai), out updateDate) ? updateDate : 0;
                int updateTime = int.TryParse(dateTime.ToString("HHmmss", m_DThai), out updateTime) ? updateTime : 0;

                input.recordStatus = "X";

                var cmdText = $@"UPDATE {_dc.SchemaDB()?.CS}.CSMCB18 
                                SET T8DEL = '{input.recordStatus?.Trim()}' 
                                WHERE T8TYCD = '{input.typeCode?.Trim().ToUpper()}' 
                                    AND T8RSCD = '{input.resultCode?.Trim().ToUpper()}'";

                var result = await _dc.Execute(cmdText, CommandType.Text);
                if (result.success)
                {
                    modelResult.success = result.success;
                    response.success = result.success;
                }

                response.data = modelResult;
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + result.message : result.message;
            }
            catch (Exception ex)
            {
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + ex.Message : ex.Message;
            }

            return await Task.FromResult(response);
        }
        #endregion Type And Result

        #region Working Date
        public async Task<ResponseModel> GetWorkingDate(RequestWorkingDateModel input)
        {
            var response = new ResponseModel();
            try
            {
                string condition;
                string CurrentDate = dateTime.ToString("yyyyMMdd", m_DThai);
                //string CurrentDate = await GetCurrentDate();  //New
                if (input.workingDate == "00/00/0000")
                {
                    condition = "";
                }
                else if (!string.IsNullOrEmpty(input.workingDate))
                {
                    string date = (input.workingDate.Length == 10) ?
                        $"{input.workingDate.Substring(6, 4)}{input.workingDate.Substring(3, 2)}{input.workingDate.Substring(0, 2)}" : "";

                    condition = $" AND T4HDAT = '{date}' ";
                }
                else
                {
                    condition = $" AND T4HDAT >= '{CurrentDate}' ";
                }

                var cmdText = $@"SELECT
                                T4HDAT,
                                T4STIM,
                                T4ETIM
                             FROM
                                {_dc.SchemaDB()?.CS}.CSMCB04
                             WHERE 
                                T4DEL = '' 
                                {condition}
                             ORDER BY
                                T4HDAT";
                var result = await _dc.Get<List<ResultWorkingDateModel>>(cmdText, CommandType.Text);

                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    if (!result.data.IsEmpty())
                    {
                        result.data.ForEach(item =>
                        {
                            if (item.T4STIM.ToString().Length < 5)
                            {
                                item.T4STIM += 240000;
                            }
                            if (item.T4ETIM.ToString().Length < 5)
                            {
                                item.T4ETIM += 240000;
                            }
                        });
                        response.data = result.data;
                    }
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return response;

        }

        public async Task<ResponseModel> AddWorkingDate(RequestWorkingDateModel input)
        {
            var response = new ResponseModel();
            var modelResult = new ResultSaveWorkingDate();
            try
            {
                string msgError = "";
                string cmdText = "";
                int updateDate = int.TryParse(dateTime.ToString("yyMMdd", m_DThai), out updateDate) ? updateDate : 0;
                int updateTime = int.TryParse(dateTime.ToString("HHmmss", m_DThai), out updateTime) ? updateTime : 0;

                if (this.CheckWorkingDate(input, "FindExist", ref msgError))
                {
                    msgError = ", this Code already exists.";
                    modelResult.lastError = msgError;
                    response.message = msgError;
                    response.data = modelResult;
                    response.success = true;
                    return await Task.FromResult(response);
                }
                else if (this.CheckWorkingDate(input, "FindObject", ref msgError))
                {
                    cmdText = $@"UPDATE {_dc.SchemaDB()?.CS}.CSMCB04
                                    SET T4STIM = '{input.startTime}',
                                        T4ETIM = '{input.endTime}',
                                        T4UDAT = {updateDate},
                                        T4UTIM = {updateTime},
                                        T4UUSR = '{input.username}',
                                        T4UPGM = '{systemName}',
                                        T4UJOB = '',
                                        T4DEL  = ''
                                  WHERE T4HDAT = '{input.workingDate?.Trim().ToUpper()}'";
                }
                else
                {
                    cmdText = $@"INSERT INTO {_dc.SchemaDB()?.CS}.CSMCB04 (T4HDAT,T4STIM,T4ETIM,T4UDAT,T4UTIM,T4UUSR,T4UPGM,T4UJOB,T4DEL)
                                    VALUES ('{input.workingDate?.Trim().ToUpper()}',
                                            '{input.startTime}',
                                            '{input.endTime}',
                                            {updateDate},
                                            {updateTime},
                                            '{input.username}',
                                            '{systemName}',
                                            '',
                                            '')";
                }
                var result = await _dc.Execute(cmdText, CommandType.Text);
                if (result.success)
                {
                    modelResult.success = result.success;
                    response.success = result.success;
                    response.message = "Insert Data Success";
                }

                response.data = modelResult;
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + result.message : result.message;
            }
            catch (Exception ex)
            {
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + ex.Message : ex.Message;
            }

            return await Task.FromResult(response);
        }

        public async Task<ResponseModel> UpdateWorkingDate(RequestWorkingDateModel input)
        {
            var response = new ResponseModel();
            var modelResult = new ResultSaveWorkingDate();
            try
            {
                int updateDate = int.TryParse(dateTime.ToString("yyMMdd", m_DThai), out updateDate) ? updateDate : 0;
                int updateTime = int.TryParse(dateTime.ToString("HHmmss", m_DThai), out updateTime) ? updateTime : 0;

                var cmdText = $@"UPDATE {_dc.SchemaDB()?.CS}.CSMCB04 
                                SET T4STIM = '{input.startTime}',
                                    T4ETIM = '{input.endTime}',
                                    T4UDAT = {updateDate},
                                    T4UTIM = {updateTime},
                                    T4UUSR = '{input.username}',
                                    T4UPGM = '{systemName}',
                                    T4UJOB = '',
                                    T4DEL  = ''
                              WHERE T4HDAT = '{input.workingDate?.Trim().ToUpper()}'";
                var result = await _dc.Execute(cmdText, CommandType.Text);
                if (result.success)
                {
                    modelResult.success = result.success;
                    response.success = result.success;
                }

                response.data = modelResult;
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + result.message : result.message;
            }
            catch (Exception ex)
            {
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + ex.Message : ex.Message;
            }

            return await Task.FromResult(response);
        }

        public async Task<ResponseModel> DeleteWorkingDate(RequestWorkingDateModel input)
        {
            var response = new ResponseModel();
            var modelResult = new ResultSaveWorkingDate();
            try
            {
                int updateDate = int.TryParse(dateTime.ToString("yyMMdd", m_DThai), out updateDate) ? updateDate : 0;
                int updateTime = int.TryParse(dateTime.ToString("HHmmss", m_DThai), out updateTime) ? updateTime : 0;

                var cmdText = $@"UPDATE {_dc.SchemaDB()?.CS}.CSMCB04
                                SET T4UDAT = {updateDate},
                                    T4UTIM = {updateTime},
                                    T4UUSR = '{input.username}',
                                    T4UPGM = '{systemName}',
                                    T4UJOB = '',
                                    T4DEL  = 'X'
                              WHERE T4HDAT = '{input.workingDate?.Trim().ToUpper()}'";

                var result = await _dc.Execute(cmdText, CommandType.Text);
                if (result.success)
                {
                    modelResult.success = result.success;
                    response.success = result.success;
                }

                response.data = modelResult;
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + result.message : result.message;
            }
            catch (Exception ex)
            {
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + ex.Message : ex.Message;
            }

            return await Task.FromResult(response);
        }

        public bool CheckWorkingDate(RequestWorkingDateModel request, string checkType, ref string msgError) // FindExist = '', FindObject = 'X'
        {
            bool popSuccess;
            var data = new ResultWorkingDateModel();
            try
            {
                var cmdText = "";
                if (checkType == "FindExist")
                {
                    cmdText = $@"SELECT * FROM {_dc.SchemaDB()?.CS}.CSMCB04 WHERE T4HDAT = '{request.workingDate?.Trim().ToUpper()}' AND T4DEL  = ''";
                }
                else if (checkType == "FindObject")
                {
                    cmdText = $@"SELECT * FROM {_dc.SchemaDB()?.CS}.CSMCB04 WHERE T4HDAT = '{request.workingDate?.Trim().ToUpper()}' AND T4DEL  = 'X'";
                }
                var res = _dc.Get<ResultWorkingDateModel>(cmdText, CommandType.Text);
                if (res.Result.data.T4HDAT == 0 && res.Result.data.T4STIM == 0 && res.Result.data.T4ETIM == 0)
                {
                    popSuccess = false;
                }
                else
                {
                    popSuccess = true;
                }
                data = res.Result.data;
            }
            catch (Exception ex)
            {
                popSuccess = false;
                msgError = ex.Message.ToString();
            }
            return ((data != null) && popSuccess);
        }
        #endregion Working Date



        #region SMS Default Group
        private bool CheckSMSDefault(RequestSaveSMSDefaultModel input, string checkType)
        {
            bool popSuccess = false;
            bool checkData = false;
            try
            {
                var cmdText = "";
                if (checkType == "FindExist")
                {
                    cmdText = $@"SELECT * FROM {_dc.SchemaDB()?.GN}.GNSMS34 WHERE G34COL='{input.collectorCode}'";
                }
                else if (checkType == "FindObject")
                {
                    cmdText = $@"SELECT * FROM {_dc.SchemaDB()?.GN}.GNSMS34 WHERE G34COL=''{input.collectorCode}' and G34DEL='X'";
                }

                var result = _dc.Get<List<ResultSMSDefaultModel>>(cmdText, CommandType.Text).Result;
                if (result.success)
                {
                    popSuccess = true;
                    checkData = true;
                }
            }
            catch (Exception ex)
            {
                popSuccess = false;
                //msgError = ex.Message.ToString();
            }
            return (checkData && popSuccess);
        }
        public async Task<ResponseModel> GetDataSMSDefault(InputSMSDefaultModel reqData)
        {
            var response = new ResponseModel();
            try
            {
                string cmdText = "";
                string strWhere = "";
                if (!string.IsNullOrEmpty(reqData.keyword))
                {
                    if (reqData.keyword.Trim().ToUpper() != "ALL")
                    {
                        strWhere += " WHERE G34GRP = '" + reqData.keyword.Trim().ToUpper() + "' ";
                    }
                    cmdText = $@"SELECT * FROM {_dc.SchemaDB()?.GN}.GNSMS34 {strWhere} ORDER BY G34GRP";
                }
                else
                {
                    cmdText = $@"SELECT DISTINCT G34GRP FROM {_dc.SchemaDB()?.GN}.GNSMS34 ORDER BY G34GRP";
                }

                var result = await _dc.Get<List<ResultSMSDefaultModel>>(cmdText, CommandType.Text);

                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = result.data;
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }

            return await Task.FromResult(response);
        }
        public async Task<ResponseModel> AddSMSDefault(RequestSaveSMSDefaultModel reqData)
        {
            var response = new ResponseModel();
            var modelResult = new ResultSaveSMSDefault();
            try
            {
                string msgError = "";
                string cmdText = "";
                int updateDate = int.TryParse(DateTime.Now.ToString("yyMMdd", m_DThai), out updateDate) ? updateDate : 0;
                int updateTime = int.TryParse(DateTime.Now.ToString("HHmmss", m_DThai), out updateTime) ? updateTime : 0;

                if (this.CheckSMSDefault(reqData, "FindExist"))
                {
                    msgError = ", this Code already exists.";
                    modelResult.lastError = msgError;
                    response.message = msgError;
                }
                else
                {
                    cmdText = $@"INSERT INTO {_dc.SchemaDB()?.GN}.GNSMS34 (G34GRP,G34COL,G34UDT,G34UTM,G34USR,G34PGM,G34DEL) VALUES
                        ('{reqData.groupCode?.ToUpper().Trim()}',
                         '{reqData.collectorCode?.ToUpper().Trim()}',
                         {updateDate},
                         {updateTime},
                        '{reqData.updateBy}',
                        '{"SMSDEFAULT"}',
                        '{reqData.status?.ToUpper().Trim()}')";
                }

                var result = await _dc.Execute(cmdText, CommandType.Text);
                if (result.success)
                {
                    modelResult.success = result.success;
                    response.success = result.success;
                }

                response.data = modelResult;
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + result.message : result.message;
            }
            catch (Exception ex)
            {
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + ex.Message : ex.Message;
            }

            return await Task.FromResult(response);
        }
        public async Task<ResponseModel> UpdateSMSDefault(RequestSaveSMSDefaultModel reqData)
        {
            var response = new ResponseModel();
            var modelResult = new ResultSaveSMSDefault();
            try
            {
                int updateDate = int.TryParse(DateTime.Now.ToString("yyMMdd", m_DThai), out updateDate) ? updateDate : 0;
                int updateTime = int.TryParse(DateTime.Now.ToString("HHmmss", m_DThai), out updateTime) ? updateTime : 0;
                var cmdText = $@"UPDATE {_dc.SchemaDB()?.GN}.GNSMS34 SET G34PGM='{"SMSDEFAULT"}',
                                    G34GRP='{reqData.groupCode?.ToUpper().Trim()}',
                                    G34UDT={updateDate},
                                    G34UTM={updateTime},
                                    G34USR='{reqData.updateBy}',
                                    G34DEL='{reqData.status?.ToUpper().Trim()}'
                                    WHERE G34COL='{reqData.collectorCode?.ToUpper().Trim()}'";

                var result = await _dc.Execute(cmdText, CommandType.Text);
                if (result.success)
                {
                    modelResult.success = result.success;
                    response.success = result.success;
                }

                response.data = modelResult;
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + result.message : result.message;
            }
            catch (Exception ex)
            {
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + ex.Message : ex.Message;
            }

            return await Task.FromResult(response);
        }
        public async Task<ResponseModel> DeleteSMSDefault(RequestSaveSMSDefaultModel reqData)
        {
            var response = new ResponseModel();
            var modelResult = new ResultSaveSMSDefault();
            try
            {
                var status = "X";
                int updateDate;
                int updateTime;
                updateDate = int.TryParse(DateTime.Now.ToString("yyMMdd", m_DThai), out updateDate) ? updateDate : 0;
                updateTime = int.TryParse(DateTime.Now.ToString("HHmmss", m_DThai), out updateTime) ? updateTime : 0;
                var cmdText = $@"UPDATE {_dc.SchemaDB()?.GN}.GNSMS34 SET G34DEL='{status}',
                              G34USR='{reqData.updateBy}',
                              G34UDT={updateDate},
                              G34UTM={updateTime} 
                              WHERE G34COL='{reqData.collectorCode?.Trim().ToUpper()}'";

                var result = await _dc.Execute(cmdText, CommandType.Text);
                if (result.success)
                {
                    modelResult.success = result.success;
                    response.success = result.success;
                }

                response.data = modelResult;
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + result.message : result.message;
            }
            catch (Exception ex)
            {
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + ex.Message : ex.Message;
            }

            return await Task.FromResult(response);
        }
        #endregion SMS Default Group

        #region SMS Group
        private bool CheckSMSGroup(InputSMSGroupModel input, string checkType)
        {
            bool popSuccess = false;
            bool checkData = false;

            try
            {
                var cmdText = "";
                if (checkType == "FindExist")
                {
                    cmdText = $@"SELECT * FROM {_dc.SchemaDB()?.GN}.GNSMS30 WHERE G30GRP='{input.groupCode}'";
                }
                else if (checkType == "FindObject")
                {
                    cmdText = $@"SELECT * FROM {_dc.SchemaDB()?.GN}.GNSMS30 WHERE G30GRP='{input.groupCode}' AND G30DEL='X'";
                }

                var result = _dc.Get<List<ResultSMSGroupCodeModel>>(cmdText, CommandType.Text).Result;

                if (result.success)
                {
                    checkData = true;
                    popSuccess = true;
                }
            }
            catch (Exception ex)
            {
                popSuccess = false;
                //msgError = ex.Message.ToString();
            }
            return (checkData && popSuccess);
        }
        public async Task<ResponseModel> GetDataSMSGroup(InputSMSGroupCodeModel reqData)
        {
            var response = new ResponseModel();
            try
            {
                string cmdText = "";
                string strWhere = "";
                if (!string.IsNullOrEmpty(reqData?.keyword?.Trim()) && reqData.keyword.Trim().ToUpper() != "ORDERBYRRN")
                {
                    if (reqData.keyword.Trim().ToUpper() != "ALL")
                    {
                        strWhere += " WHERE G30GRP = '" + reqData.keyword.Trim().ToUpper() + "' ";
                    }
                    cmdText = $@"SELECT * FROM {_dc.SchemaDB()?.GN}.GNSMS30 {strWhere} ORDER BY G30GRP";
                }
                else if (!string.IsNullOrEmpty(reqData?.keyword?.Trim()) && reqData.keyword.Trim().ToUpper() == "ORDERBYRRN")
                {
                    cmdText = $@"SELECT G30GRP FROM {_dc.SchemaDB()?.GN}.GNSMS30 ORDER BY ROW_NUMBER() OVER (ORDER BY (SELECT NULL))";
                }
                else
                {
                    cmdText = $@"SELECT G30GRP FROM {_dc.SchemaDB()?.GN}.GNSMS30 ORDER BY G30GRP";
                }

                var result = await _dc.Get<List<ResultSMSGroupCodeModel>>(cmdText, CommandType.Text);

                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = result.data;
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }

            return await Task.FromResult(response);
        }
        public async Task<ResponseModel> AddSMSGroup(InputSMSGroupModel reqData)
        {
            var response = new ResponseModel();
            var modelResult = new ResultSaveSMSGroup();
            try
            {
                string msgError = "";
                string cmdText = "";
                decimal lngCCLen = 2;
                int updateDate;
                int updateTime;
                updateDate = int.TryParse(DateTime.Now.ToString("yyMMdd", m_DThai), out updateDate) ? updateDate : 0;
                updateTime = int.TryParse(DateTime.Now.ToString("HHmmss", m_DThai), out updateTime) ? updateTime : 0;

                if (this.CheckSMSGroup(reqData, "FindExist"))
                {
                    msgError = ", this Code already exists.";
                    modelResult.lastError = msgError;
                    response.message = msgError;
                    response.data = modelResult;
                    response.success = true;
                    return await Task.FromResult(response);
                }
                //else if (FindObject(false))
                //{
                //    cmd.CommandText = String.Format("update {0}.{1} set "
                //        + " "
                //        + " G30DSE=@G30DSE,G30DST=@G30DST,G30CFL=@G30CFL,G30UDT=@G30UDT,G30UTM=@G30UTM,G30USR=@G30USR,G30PGM=@G30PGM,G30DEL=@G30DEL "
                //        + " where G30GRP=@G30GRP ", m_Lib_GNTEST, m_TableName);
                //}
                else
                {
                    cmdText = $@"INSERT INTO {_dc.SchemaDB()?.GN}.GNSMS30 (G30GRP,G30DSE,G30DST,G30CFL,G30UDT,G30UTM,G30USR,G30PGM,G30DEL) VALUES
                        ('{reqData?.groupCode?.ToUpper().Trim()}',
                         '{reqData?.descriptionEN}',
                         '{reqData?.descriptionTH}',
                         {lngCCLen},
                         {updateDate},
                         {updateTime},
                        '{reqData?.updateBy?.ToUpper().Trim()}',
                        '{"SMSGROUP"}',
                        '{reqData?.status?.ToUpper().Trim()}')";
                }

                var result = await _dc.Execute(cmdText, CommandType.Text);
                if (result.success)
                {
                    modelResult.success = result.success;
                    response.success = result.success;
                }

                response.data = modelResult;
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + result.message : result.message;
            }
            catch (Exception ex)
            {
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + ex.Message : ex.Message;
            }

            return await Task.FromResult(response);
        }
        public async Task<ResponseModel> UpdateSMSGroup(InputSMSGroupModel reqData)
        {
            var response = new ResponseModel();
            var modelResult = new ResultSaveSMSGroup();
            try
            {
                int updateDate = int.TryParse(DateTime.Now.ToString("yyMMdd", m_DThai), out updateDate) ? updateDate : 0;
                int updateTime = int.TryParse(DateTime.Now.ToString("HHmmss", m_DThai), out updateTime) ? updateTime : 0;
                var cmdText = $@"UPDATE {_dc.SchemaDB()?.GN}.GNSMS30 SET G30PGM='{"SMSGROUP"}',
                                    G30DSE='{reqData?.descriptionEN}',
                                    G30DST='{reqData?.descriptionTH}',
                                    G30USR='{reqData?.updateBy?.ToUpper().Trim()}',
                                    G30DEL='{reqData?.status?.ToUpper().Trim()}',
                                    G30UDT={updateDate},
                                    G30UTM={updateTime} 
                                    WHERE G30GRP='{reqData?.groupCode?.ToUpper().Trim()}'";

                var result = await _dc.Execute(cmdText, CommandType.Text);
                if (result.success)
                {
                    modelResult.success = result.success;
                    response.success = result.success;
                }

                response.data = modelResult;
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + result.message : result.message;
            }
            catch (Exception ex)
            {
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + ex.Message : ex.Message;
            }

            return await Task.FromResult(response);
        }
        public async Task<ResponseModel> DeleteSMSGroup(InputSMSGroupModel reqData)
        {
            var response = new ResponseModel();
            var modelResult = new ResultSaveSMSGroup();
            try
            {
                var status = "X";
                int updateDate = int.TryParse(DateTime.Now.ToString("yyMMdd", m_DThai), out updateDate) ? updateDate : 0;
                int updateTime = int.TryParse(DateTime.Now.ToString("HHmmss", m_DThai), out updateTime) ? updateTime : 0;
                var cmdText = $@"UPDATE {_dc.SchemaDB()?.GN}.GNSMS30 SET G30DEL='{status}',
                              G30USR='{reqData.updateBy}',
                              G30UDT={updateDate},
                              G30UTM={updateTime} 
                              WHERE G30GRP='{reqData.groupCode}'";

                var result = await _dc.Execute(cmdText, CommandType.Text);
                if (result.success)
                {
                    modelResult.success = result.success;
                    response.success = result.success;
                }

                response.data = modelResult;
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + result.message : result.message;
            }
            catch (Exception ex)
            {
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + ex.Message : ex.Message;
            }

            return await Task.FromResult(response);
        }
        #endregion SMS Group

        #region SMS Keyword
        private bool CheckSMSKeyword(InputSMSKeywordForInsert input, string checkType, ref string msgError)
        {
            bool popSuccess;
            var data = new ResultSMSKeywordCodeModel();
            try
            {
                var cmdText = "";
                if (checkType == "FindExist")
                {
                    cmdText = $@"SELECT * FROM {_dc.SchemaDB()?.GN}.GNSMS33 WHERE G33KWD='{input.groupKeyword}'";
                }
                //else if (checkType == "FindObject")
                //{
                //    cmdText = $@"SELECT * FROM GNSMS33 WHERE G33KWD='{input.groupKeyword}' and G33DEL = 'X'";
                //}
                var res = _dc.Get<ResultSMSKeywordCodeModel>(cmdText, CommandType.Text).Result;
                if (res.data.G33DEL == null && res.data.G33DSE == null && res.data.G33DST == null && res.data.G33KWD == null && res.data.G33LEN == 0)
                {
                    popSuccess = false;
                }
                else
                {
                    popSuccess = true;
                }
                data = res.data;
            }
            catch (Exception ex)
            {
                popSuccess = false;
                msgError = ex.Message.ToString();
            }
            return (data != null) && popSuccess;
        }
        public async Task<ResponseModel> GetDataSMSKeyword(InputSMSKeywordCodeModel reqData)
        {
            var response = new ResponseModel();
            try
            {
                string cmdText = "";
                string strWhere = "";
                if (!string.IsNullOrEmpty(reqData?.keyword))
                {
                    if (reqData.keyword.Trim().ToUpper() != "ALL")
                    {
                        strWhere += " WHERE G33KWD = '" + reqData.keyword.Trim().ToUpper() + "' ";
                    }
                    cmdText = $@"SELECT * FROM {_dc.SchemaDB()?.GN}.GNSMS33 {strWhere} ORDER BY G33KWD";
                }
                else
                {
                    cmdText = $@"SELECT G33KWD FROM {_dc.SchemaDB()?.GN}.GNSMS33 ORDER BY G33KWD";
                }

                var result = await _dc.Get<List<ResultSMSKeywordCodeModel>>(cmdText, CommandType.Text);

                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = result.data;
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }

            return await Task.FromResult(response);
        }
        public async Task<ResponseModel> AddSMSKeyword(InputSMSKeywordForInsert reqData)
        {
            var response = new ResponseModel();
            var modelResult = new ResultSaveSMSKeyword();
            try
            {
                string msgError = "";
                string cmdText = "";
                if (this.CheckSMSKeyword(reqData, "FindExist", ref msgError))
                {
                    msgError = ", this Code already exists.";
                    modelResult.lastError = msgError;
                    response.message = msgError;
                }
                else
                {
                    cmdText = $@"INSERT INTO {_dc.SchemaDB()?.GN}.GNSMS33 (G33KWD,G33LEN,G33DSE,G33DST,G33UDT,G33UTM,G33USR,G33PGM,G33DEL) VALUES
                        ('{reqData.groupKeyword?.ToUpper().Trim()}',
                        {reqData.length},
                        '{reqData.descriptionEN}',
                        '{reqData.descriptionTH}',
                        {Convert.ToUInt32(DateTime.Now.ToString("yyMMdd", new CultureInfo("th-TH", false).DateTimeFormat))},
                        {Convert.ToUInt32(DateTime.Now.ToString("HHmmss", new CultureInfo("th-TH", false).DateTimeFormat))},
                        '{reqData.updateBy?.ToUpper().Trim()}',
                        '{"SMSKEYWORD"}',
                        '{reqData.status?.ToUpper().Trim()}')";
                }

                var result = await _dc.Execute(cmdText, CommandType.Text);
                if (result.success)
                {
                    modelResult.success = result.success;
                    response.success = result.success;
                }

                response.data = modelResult;
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + result.message : result.message;
            }
            catch (Exception ex)
            {
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + ex.Message : ex.Message;
            }

            return await Task.FromResult(response);
        }
        public async Task<ResponseModel> UpdateSMSKeyword(InputSMSKeywordForUpdate reqData)
        {
            var response = new ResponseModel();
            var modelResult = new ResultSaveSMSKeyword();
            try
            {
                var cmdText = $@"UPDATE {_dc.SchemaDB()?.GN}.GNSMS33 SET G33PGM='{"SMSKEYWORD"}',
                                    G33LEN={reqData.length},
                                    G33DSE='{reqData.descriptionEN}',
                                    G33DST='{reqData.descriptionTH}',
                                    G33USR='{reqData.updateBy?.ToUpper().Trim()}',
                                    G33DEL='{reqData.status?.ToUpper().Trim()}',
                                    G33UDT={Convert.ToUInt32(DateTime.Now.ToString("yyMMdd", new CultureInfo("th-TH", false).DateTimeFormat))},
                                    G33UTM={Convert.ToUInt32(DateTime.Now.ToString("HHmmss", new CultureInfo("th-TH", false).DateTimeFormat))} 
                                    WHERE G33KWD='{reqData.groupKeyword?.ToUpper().Trim()}'";

                var result = await _dc.Execute(cmdText, CommandType.Text);
                if (result.success)
                {
                    modelResult.success = result.success;
                    response.success = result.success;
                }

                response.data = modelResult;
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + result.message : result.message;
            }
            catch (Exception ex)
            {
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + ex.Message : ex.Message;
            }

            return await Task.FromResult(response);
        }
        public async Task<ResponseModel> DeleteSMSKeyword(InputSMSKeywordForDelete reqData)
        {
            var response = new ResponseModel();
            var modelResult = new ResultSaveSMSKeyword();
            try
            {
                var cmdText = $@"UPDATE {_dc.SchemaDB()?.GN}.GNSMS33 SET 
                                    G33USR='{reqData.updateBy?.ToUpper().Trim()}',
                                    G33DEL='{"X"}',
                                    G33UDT={Convert.ToUInt32(DateTime.Now.ToString("yyMMdd", new CultureInfo("th-TH", false).DateTimeFormat))},
                                    G33UTM={Convert.ToUInt32(DateTime.Now.ToString("HHmmss", new CultureInfo("th-TH", false).DateTimeFormat))}
                                    WHERE G33KWD='{reqData.groupKeyword?.ToUpper().Trim()}'";

                var result = await _dc.Execute(cmdText, CommandType.Text);
                if (result.success)
                {
                    modelResult.success = result.success;
                    response.success = result.success;
                }

                response.data = modelResult;
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + result.message : result.message;
            }
            catch (Exception ex)
            {
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + ex.Message : ex.Message;
            }

            return await Task.FromResult(response);
        }
        #endregion SMS Keyword

        #region SMS Subject
        private bool CheckSMSSubject(InputSMSSubjectCodeModel input, string checkType)
        {
            bool popSuccess = false;
            bool checkData = false;
            try
            {
                var cmdText = "";
                if (checkType == "FindExist")
                {
                    cmdText = $@"SELECT * FROM {_dc.SchemaDB()?.GN}.GNSMS31 WHERE G31SUB='{input.subjectCode}'";
                }
                else if (checkType == "FindObject")
                {
                    cmdText = $@"SELECT * FROM {_dc.SchemaDB()?.GN}.GNSMS31 WHERE G31SUB='{input.subjectCode}' AND G31DEL='X'";
                }

                var result = _dc.Get<List<ResultSMSSubjectModel>>(cmdText, CommandType.Text).Result;
                if (result.success)
                {
                    popSuccess = true;
                    checkData = true;
                }
            }
            catch (Exception ex)
            {
                popSuccess = false;
                //msgError = ex.Message.ToString();
            }
            return (checkData && popSuccess);
        }
        public async Task<ResponseModel> GetDataSMSSubject(InputSMSSubjectModel reqData)
        {
            var response = new ResponseModel();
            try
            {
                string cmdText = "";
                string strWhere = "";
                if (!string.IsNullOrEmpty(reqData.keyword))
                {
                    if (reqData.keyword.Trim().ToUpper() != "ALL")
                    {
                        strWhere += " WHERE G31SUB = '" + reqData.keyword.Trim().ToUpper() + "' ";
                    }
                    cmdText = $@"SELECT * FROM {_dc.SchemaDB()?.GN}.GNSMS31 {strWhere} ORDER BY G31SUB";
                }
                else
                {
                    cmdText = $@"SELECT G31SUB FROM {_dc.SchemaDB()?.GN}.GNSMS31 ORDER BY G31SUB";
                }

                var result = await _dc.Get<List<ResultSMSSubjectModel>>(cmdText, CommandType.Text);

                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = result.data;
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }

            return await Task.FromResult(response);
        }
        public async Task<ResponseModel> AddSMSSubject(InputSMSSubjectCodeModel reqData)
        {
            var response = new ResponseModel();
            var modelResult = new ResultSaveSMSSubject();
            try
            {
                string msgError = "";
                string cmdText = "";
                int updateDate = int.TryParse(dateTime.ToString("yyMMdd", m_DThai), out updateDate) ? updateDate : 0;
                int updateTime = int.TryParse(dateTime.ToString("HHmmss", m_DThai), out updateTime) ? updateTime : 0;

                if (this.CheckSMSSubject(reqData, "FindExist"))
                {
                    msgError = ", this Code already exists.";
                    modelResult.lastError = msgError;
                    response.message = msgError;
                    response.data = modelResult;
                    response.success = true;
                    return await Task.FromResult(response);
                }
                //else if (FindObject(false))
                //{
                //    cmd.CommandText = String.Format("update {0}.{1} set "
                //        + " "
                //        + " G31DSE=@G31DSE,G31DST=@G31DST,G31UDT=@G31UDT,G31UTM=@G31UTM,G31USR=@G31USR,G31PGM=@G31PGM,G31DEL=@G31DEL "
                //        + " where G31SUB=@G31SUB ", m_Lib_GNTEST, m_TableName);
                //}
                else
                {
                    cmdText = $@"INSERT INTO {_dc.SchemaDB()?.GN}.GNSMS31 (G31SUB,G31DSE,G31DST,G31UDT,G31UTM,G31USR,G31PGM,G31DEL) VALUES
                        ('{reqData.subjectCode?.ToUpper().Trim()}',
                         '{reqData.descriptionEN}',
                         '{reqData.descriptionTH}',
                         {updateDate},
                         {updateTime},
                        '{reqData.updateBy?.ToUpper().Trim()}',
                        '{"SMSSUBJECT"}',
                        '{reqData.status?.ToUpper().Trim()}')";
                }

                var result = await _dc.Execute(cmdText, CommandType.Text);
                if (result.success)
                {
                    modelResult.success = result.success;
                    response.success = result.success;
                }

                response.data = modelResult;
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + result.message : result.message;
            }
            catch (Exception ex)
            {
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + ex.Message : ex.Message;
            }

            return await Task.FromResult(response);
        }
        public async Task<ResponseModel> UpdateSMSSubject(InputSMSSubjectCodeModel reqData)
        {
            var response = new ResponseModel();
            var modelResult = new ResultSaveSMSSubject();
            try
            {
                int updateDate = int.TryParse(dateTime.ToString("yyMMdd", m_DThai), out updateDate) ? updateDate : 0;
                int updateTime = int.TryParse(dateTime.ToString("HHmmss", m_DThai), out updateTime) ? updateTime : 0;

                var cmdText = $@"UPDATE {_dc.SchemaDB()?.GN}.GNSMS31 SET G31PGM='{"SMSSUBJECT"}',
                                    G31DSE='{reqData.descriptionEN}',
                                    G31DST='{reqData.descriptionTH}',
                                    G31USR='{reqData.updateBy?.ToUpper().Trim()}',
                                    G31DEL='{reqData.status?.ToUpper().Trim()}',
                                    G31UDT={updateDate},
                                    G31UTM={updateTime} 
                                    WHERE G31SUB='{reqData.subjectCode?.ToUpper().Trim()}'";

                var result = await _dc.Execute(cmdText, CommandType.Text);
                if (result.success)
                {
                    modelResult.success = result.success;
                    response.success = result.success;
                }

                response.data = modelResult;
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + result.message : result.message;
            }
            catch (Exception ex)
            {
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + ex.Message : ex.Message;
            }

            return await Task.FromResult(response);
        }
        public async Task<ResponseModel> DeleteSMSSubject(InputSMSSubjectCodeModel reqData)
        {
            var response = new ResponseModel();
            var modelResult = new ResultSaveSMSSubject();
            try
            {
                var status = "X";
                int updateDate = int.TryParse(DateTime.Now.ToString("yyMMdd", m_DThai), out updateDate) ? updateDate : 0;
                int updateTime = int.TryParse(DateTime.Now.ToString("HHmmss", m_DThai), out updateTime) ? updateTime : 0;
                var cmdText = $@"UPDATE {_dc.SchemaDB()?.GN}.GNSMS31 SET G31DEL='{status}',
                              G31USR='{reqData.updateBy}',
                              G31UDT={updateDate},
                              G31UTM={updateTime} 
                              WHERE G31SUB='{reqData.subjectCode}'";

                var result = await _dc.Execute(cmdText, CommandType.Text);
                if (result.success)
                {
                    modelResult.success = result.success;
                    response.success = result.success;
                }

                response.data = modelResult;
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + result.message : result.message;
            }
            catch (Exception ex)
            {
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + ex.Message : ex.Message;
            }

            return await Task.FromResult(response);
        }
        #endregion SMS Subject

        #region SMS Template
        private bool CheckSMSTemplate(RequestSaveSMSTemplate input, string checkType)
        {
            bool popSuccess = false;
            bool checkData = false;
            try
            {
                var cmdText = "";
                if (checkType == "FindExist")
                {
                    cmdText = $@"SELECT * FROM {_dc.SchemaDB()?.GN}.GNSMS32 WHERE G32SCD='{input.smsCode}'";
                }
                else if (checkType == "FindObject")
                {
                    cmdText = $@"SELECT * FROM {_dc.SchemaDB()?.GN}.GNSMS32 WHERE G32GRP='{input.groupCode}' and G32SUB='{input.subjectCode}'and G32SCD='{input.smsCode}' and G32DEL='X'";
                }

                var result = _dc.Get<List<ResultSMSTemplateModel>>(cmdText, CommandType.Text).Result;
                if (result.success)
                {
                    popSuccess = true;
                    checkData = true;
                }
            }
            catch (Exception ex)
            {
                popSuccess = false;
                //msgError = ex.Message.ToString();
            }
            return (checkData && popSuccess);
        }
        public async Task<ResponseModel> GetDataSMSTemplate(InputSMSTemplateModel reqData)
        {
            var response = new ResponseModel();
            try
            {
                string cmdText = $@"SELECT * FROM {_dc.SchemaDB()?.GN}.GNSMS32";
                string strWhere = "";
                if (reqData.groupCode != "ALL" || reqData.subjectCode != "ALL" || reqData.templateCode != "ALL")
                {
                    strWhere = "WHERE";
                }
                else
                {
                    strWhere = "";
                }


                //select * FROM GNTEST.GNSMS32  ORDER BY G32GRP, G32SUB, G32SCD


                if (!string.IsNullOrEmpty(reqData.groupCode))
                {
                    if (reqData.groupCode.Trim().ToUpper() != "ALL")
                    {
                        strWhere += " G32GRP = '" + reqData.groupCode.Trim().ToUpper() + "' ";
                    }
                }
                if (!string.IsNullOrEmpty(reqData.subjectCode))
                {
                    if (reqData.subjectCode.Trim().ToUpper() != "ALL" && reqData.groupCode?.Trim().ToUpper() != "ALL")
                    {
                        strWhere += " AND G32SUB = '" + reqData.subjectCode.Trim().ToUpper() + "' ";
                    }
                    else if (reqData.subjectCode.Trim().ToUpper() != "ALL" && reqData.groupCode?.Trim().ToUpper() == "ALL")
                    {
                        strWhere += " G32SUB = '" + reqData.subjectCode.Trim().ToUpper() + "' ";
                    }
                }
                if (!string.IsNullOrEmpty(reqData.templateCode))
                {
                    if (reqData.templateCode.Trim().ToUpper() != "ALL" && reqData.subjectCode?.Trim().ToUpper() != "ALL" && reqData.groupCode?.Trim().ToUpper() != "ALL")
                    {
                        strWhere += " AND G32SCD = '" + reqData.templateCode.Trim().ToUpper() + "' ";
                    }
                    else if (reqData.templateCode.Trim().ToUpper() != "ALL" && reqData.subjectCode?.Trim().ToUpper() == "ALL" && reqData.groupCode?.Trim().ToUpper() == "ALL")
                    {
                        strWhere += " G32SCD = '" + reqData.templateCode.Trim().ToUpper() + "' ";
                    }
                }

                cmdText += " " + strWhere + " ORDER BY G32GRP, G32SUB, G32SCD";

                var result = await _dc.Get<List<ResultSMSTemplateModel>>(cmdText, CommandType.Text);

                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = result.data;
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }

            return await Task.FromResult(response);
        }
        public async Task<ResponseModel> AddSMSTemplate(RequestSaveSMSTemplate reqData)
        {
            var response = new ResponseModel();
            var modelResult = new ResultSaveSMSTemplate();
            try
            {
                string msgError = "";
                string cmdText = "";
                int updateDate = int.TryParse(dateTime.ToString("yyMMdd", m_DThai), out updateDate) ? updateDate : 0;
                int updateTime = int.TryParse(dateTime.ToString("HHmmss", m_DThai), out updateTime) ? updateTime : 0;

                if (this.CheckSMSTemplate(reqData, "FindExist"))
                {
                    msgError = ", this Code already exists.";
                    response.message = msgError;
                    modelResult.lastError = msgError;
                }
                //else if (FindObject(false))
                //{
                //    cmd.CommandText = String.Format("update {0}.{1} set "
                //        + " "
                //        + " G32SMS=@G32SMS,G32TEL=@G32TEL,G32UDT=@G32UDT,G32UTM=@G32UTM,G32USR=@G32USR,G32PGM=@G32PGM,G32DEL=@G32DEL "
                //        + " where G32GRP=@G32GRP and G32SUB=@G32SUB and G32SCD=@G32SCD ", m_Lib_GNTEST, m_TableName);
                //}
                else
                {
                    cmdText = $@"INSERT INTO {_dc.SchemaDB()?.GN}.GNSMS32 (G32GRP,G32SUB,G32SCD,G32SMS,G32TEL,G32UDT,G32UTM,G32USR,G32PGM,G32DEL) VALUES
                        ('{reqData.groupCode?.ToUpper().Trim()}',
                         '{reqData.subjectCode?.ToUpper().Trim()}',
                         '{reqData.smsCode?.ToUpper().Trim()}',
                         '{reqData.smsWordingTemplate?.ToUpper().Trim()}',
                         '{reqData.callInNo}',   
                         {updateDate},
                         {updateTime},
                        '{reqData.updateBy?.ToUpper().Trim()}',
                        '{"SMSTEMPLAT"}',
                        '{reqData.status?.ToUpper().Trim()}')";
                }

                var result = await _dc.Execute(cmdText, CommandType.Text);
                if (result.success)
                {
                    modelResult.success = result.success;
                    response.success = result.success;
                }

                response.data = modelResult;
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + result.message : result.message;
            }
            catch (Exception ex)
            {
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + ex.Message : ex.Message;
            }

            return await Task.FromResult(response);
        }
        public async Task<ResponseModel> UpdateSMSTemplate(RequestSaveSMSTemplate reqData)
        {
            var response = new ResponseModel();
            var modelResult = new ResultSaveSMSTemplate();
            try
            {
                int updateDate = int.TryParse(dateTime.ToString("yyMMdd", m_DThai), out updateDate) ? updateDate : 0;
                int updateTime = int.TryParse(dateTime.ToString("HHmmss", m_DThai), out updateTime) ? updateTime : 0;

                var cmdText = $@"UPDATE {_dc.SchemaDB()?.GN}.GNSMS32 SET G32PGM='{"SMSTEMPLAT"}',
                                    G32GRP='{reqData.groupCode?.ToUpper().Trim()}',
                                    G32SUB='{reqData.subjectCode?.ToUpper().Trim()}',
                                    G32SMS='{reqData.smsWordingTemplate?.ToUpper().Trim()}',
                                    G32TEL='{reqData.callInNo}',
                                    G32UDT={updateDate},
                                    G32UTM={updateTime},
                                    G32USR='{reqData.updateBy}',
                                    G32DEL='{reqData.status}'
                                    WHERE G32SCD='{reqData.smsCode?.ToUpper().Trim()}'";

                var result = await _dc.Execute(cmdText, CommandType.Text);
                if (result.success)
                {
                    modelResult.success = result.success;
                    response.success = result.success;
                }

                response.data = modelResult;
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + result.message : result.message;
            }
            catch (Exception ex)
            {
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + ex.Message : ex.Message;
            }

            return await Task.FromResult(response);
        }
        public async Task<ResponseModel> DeleteSMSTemplate(RequestSaveSMSTemplate reqData)
        {
            var response = new ResponseModel();
            var modelResult = new ResultSaveSMSTemplate();
            try
            {
                var status = "X";
                int updateDate = int.TryParse(DateTime.Now.ToString("yyMMdd", m_DThai), out updateDate) ? updateDate : 0;
                int updateTime = int.TryParse(DateTime.Now.ToString("HHmmss", m_DThai), out updateTime) ? updateTime : 0;
                var cmdText = $@"UPDATE {_dc.SchemaDB()?.GN}.GNSMS32 SET G32DEL='{status}',
                              G32USR='{reqData.updateBy}',
                              G32UDT={updateDate},
                              G32UTM={updateTime} 
                              WHERE G32SCD='{reqData.smsCode}'";

                var result = await _dc.Execute(cmdText, CommandType.Text);
                if (result.success)
                {
                    modelResult.success = result.success;
                    response.success = result.success;
                }

                response.data = modelResult;
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + result.message : result.message;
            }
            catch (Exception ex)
            {
                response.message = !string.IsNullOrEmpty(response.message) ? response.message + ", " + ex.Message : ex.Message;
            }

            return await Task.FromResult(response);
        }
        public async Task<ResponseModel> GetDDLSMSTemplatebyType(string type)
        {
            var response = new ResponseModel();
            try
            {
                string cmdText = "";
                if (type == "SMSGroup")
                {
                    cmdText = $"SELECT DISTINCT(G32GRP) FROM {_dc.SchemaDB()?.GN}.GNSMS32 ORDER BY G32GRP";
                }
                else if (type == "SMSSubject")
                {
                    cmdText = $"SELECT DISTINCT(G32SUB) FROM {_dc.SchemaDB()?.GN}.GNSMS32 ORDER BY G32SUB";
                }
                else if (type == "SMSTemplate")
                {
                    cmdText = $"SELECT G32SCD FROM {_dc.SchemaDB()?.GN}.GNSMS32 ORDER BY G32SCD ";
                }

                var result = await _dc.Get<List<ResultSMSTemplateModel>>(cmdText, CommandType.Text);

                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = result.data;
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }

            return await Task.FromResult(response);
        }
        public async Task<ResponseModel> GetDDlSMSGroupbyStatus(string type)
        {
            var response = new ResponseModel();
            try
            {
                string cmdText = "";
                string strWhere = " WHERE";
                if (type == "A")
                {
                    strWhere += " G30DEL = 'A' ";
                    //cmdText = $"SELECT G30GRP FROM {_dc.SchemaDB()?.GN}.GNSMS30 " + strWhere + " ORDER BY RRN(GNSMS30)";  //Code Old
                    cmdText = $"SELECT G30GRP FROM {_dc.SchemaDB()?.GN}.GNSMS30 " + strWhere + " ORDER BY RRN(GNSMS30)";
                    cmdText = $"SELECT G30GRP FROM (SELECT G30GRP, ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS RowNum FROM {_dc.SchemaDB()?.GN}.GNSMS30 {strWhere}) AS Temp" + " ORDER BY RowNum;";  //Code New
                }
                else
                {
                    //cmdText = $"SELECT G30GRP FROM {_dc.SchemaDB()?.GN}.GNSMS30 ORDER BY RRN(GNSMS30)";  //Code Old
                    cmdText = $"SELECT G30GRP FROM (SELECT G30GRP, ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS RowNum FROM {_dc.SchemaDB()?.GN}.GNSMS30) AS Temp ORDER BY RowNum";  //Code New
                }

                var result = await _dc.Get<List<ResultSMSGroupCodeModel>>(cmdText, CommandType.Text);

                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = result.data;
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }

            return await Task.FromResult(response);
        }
        public async Task<ResponseModel> GetDDlSMSSubjectbyStatus(string type)
        {
            var response = new ResponseModel();
            try
            {
                string cmdText = "";
                string strWhere = " WHERE";
                if (type == "A")
                {
                    strWhere += " G31DEL = 'A' ";
                    //cmdText = $"SELECT G31SUB FROM {_dc.SchemaDB()?.GN}.GNSMS31 " + strWhere + " ORDER BY RRN(GNSMS31)";  //Code Old

                    cmdText = $"SELECT G31SUB FROM (SELECT G31SUB, ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS RowNum FROM {_dc.SchemaDB()?.GN}.GNSMS31 {strWhere}) AS Temp" + " ORDER BY RowNum;";  //Code New
                }
                else
                {
                    //cmdText = $"SELECT G31SUB FROM {_dc.SchemaDB()?.GN}.GNSMS31 ORDER BY RRN(GNSMS31)";  //Code Old
                    cmdText = $"SELECT G31SUB FROM (SELECT G31SUB, ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS RowNum FROM {_dc.SchemaDB()?.GN}.GNSMS31) AS Temp ORDER BY RowNum";  //Code New
                }

                var result = await _dc.Get<List<ResultSMSSubjectModel>>(cmdText, CommandType.Text);

                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = result.data;
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }

            return await Task.FromResult(response);
        }
        public async Task<ResponseModel> GetSMSTemplateBindDDL(InputSMSTemplateDDLModel reqData)
        {
            var response = new ResponseModel();
            try
            {
                string strWhere = " WHERE";
                string cmdText = "";
                string? strGroup = reqData?.groupCode;
                string? strSubject = reqData?.subjectCode;
                string? strTemplate = reqData?.templateCode;

                if (reqData?.HeadDDL == "SMSGroup")
                {
                    cmdText = $"SELECT DISTINCT G32GRP FROM {_dc.SchemaDB()?.GN}.GNSMS32 ";
                    if (!strSubject.Equals("ALL") && !strSubject.Equals(""))
                    {
                        strWhere += " G32SUB='" + strSubject + "'";
                    }

                    if (!strTemplate.Equals("ALL") && !strTemplate.Equals("") && !strSubject.Equals("ALL") && !strSubject.Equals(""))
                    {
                        strWhere += " AND G32SCD='" + strTemplate + "'";
                    }
                    else if (!strTemplate.Equals("ALL") && !strTemplate.Equals("") && strSubject.Equals("ALL") && !strSubject.Equals(""))
                    {
                        strWhere += " G32SCD='" + strTemplate + "'";
                    }
                    cmdText += " " + strWhere + " ORDER BY G32GRP";
                }
                else if (reqData?.HeadDDL == "SMSSubject")
                {
                    cmdText = $"SELECT DISTINCT G32SUB FROM {_dc.SchemaDB()?.GN}.GNSMS32 ";
                    if (!strGroup.Equals("ALL") && !strGroup.Equals(""))
                    {
                        strWhere += " G32GRP='" + strGroup + "'";
                    }

                    if (!strTemplate.Equals("ALL") && !strTemplate.Equals("") && !strGroup.Equals("ALL") && !strGroup.Equals(""))
                    {
                        strWhere += " AND G32SCD='" + strTemplate + "'";
                    }
                    else if (!strTemplate.Equals("ALL") && !strTemplate.Equals("") && strGroup.Equals("ALL") && !strGroup.Equals(""))
                    {
                        strWhere += " G32SCD='" + strTemplate + "'";
                    }
                    cmdText += " " + strWhere + " ORDER BY G32SUB";
                }
                else if (reqData?.HeadDDL == "SMSTemplate")
                {
                    cmdText = $"SELECT DISTINCT G32SCD FROM {_dc.SchemaDB()?.GN}.GNSMS32 ";
                    if (!strGroup.Equals("ALL") && !strGroup.Equals(""))
                    {
                        strWhere += " G32GRP='" + strGroup + "'";
                    }

                    if (!strSubject.Equals("ALL") && !strSubject.Equals("") && !strGroup.Equals("ALL") && !strGroup.Equals(""))
                    {
                        strWhere += " AND G32SUB='" + strSubject + "'";
                    }
                    else if (!strSubject.Equals("ALL") && !strSubject.Equals("") && strGroup.Equals("ALL") && !strGroup.Equals(""))
                    {
                        strWhere += " G32SUB='" + strSubject + "'";
                    }
                    cmdText += " " + strWhere + " ORDER BY G32SCD";
                }

                var result = await _dc.Get<List<ResultSMSTemplateModel>>(cmdText, CommandType.Text);

                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = result.data;
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }

            return await Task.FromResult(response);
        }
        #endregion SMS Template
    }
}
