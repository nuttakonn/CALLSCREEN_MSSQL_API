﻿using CALLSCREEN_MSSQL_API.DataAccess.Interfaces;
using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Services.Interfaces;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json.Linq;
using Org.BouncyCastle.Ocsp;
using System.Data;
using System.Xml;

namespace CALLSCREEN_MSSQL_API.Services
{
    public class SharedService : ISharedService
    {
        protected readonly IDataCenter _dc;
        public SharedService(IDataCenter dc) => _dc = dc;

        public async Task<ResponseModel> ExecuteQuery(string query)
        {
            var response = new ResponseModel();
            try
            {
                var strCommand = query;
                var result = await _dc.Get<object>(strCommand, CommandType.Text);

                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = result.data;
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.message = ex.Message;
            }
            return response;
        }

        public async Task<ResponseModel> GetCustomerIDBizByContractNo(string contractNo)
        {
            var response = new ResponseModel();
            try
            {
                //var strCommand = @$"SELECT A.M30BUS AS biz, B.M00IDN AS customerID
                //                    FROM {_dc.SchemaDB()?.CS}.CSMS30 A
                //                    LEFT JOIN {_dc.SchemaDB()?.CS}.CSMS00 B ON A.M30CSN = B.M00CSN
                //                    WHERE A.M30CON = '{contractNo}'";                

                //var strCommand = @$"SELECT A.M30BUS AS biz, B.IDCard AS customerID
                //                    FROM {_dc.SchemaDB()?.CS}.CSMS30 A
                //                    LEFT JOIN {_dc.SchemaDB()?.CustomerInfo}.CustomerGeneral B ON A.M30CSN = B.CISNumber
                //                    WHERE A.M30CON = '{contractNo}'";

                var strCommand = @$"SELECT A.Biz, B.IDCard AS customerID
                                    FROM {_dc.SchemaDB()?.ContractInfo}.ContractGeneral A
                                    LEFT JOIN {_dc.SchemaDB()?.CustomerInfo}.CustomerGeneral B WITH (NOLOCK) ON A.CustID = B.ID
                                    WHERE A.ContractNumber = '{contractNo}'";
                var result = await _dc.Get<ResultCustomerIDBizByContractNoModel>(strCommand, CommandType.Text);

                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = result.data;
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.message = ex.Message;
            }
            return response;
        }

        public async Task<ResponseModel> Call_GNCHKNOR(InputGNCHKNORModel input)
        {
            var response = new ResponseModel();
            try
            {
                var strCommand = @$"EXEC {_dc.SchemaDB()?.GN}.GNCHKNOR '{input.branchCode?.Trim()}, {input.userName?.Trim()}, {input.customerID?.Trim()}, {input.biz?.Trim()}, {input.contractNo?.Trim()}'";
                var result = await _dc.Get<OutputGNCHKNORModel>(strCommand, CommandType.Text);
                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = new GNCHKNORModel { input = input, result = result.data };
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return response;
        }

        public async Task<ResponseModel> Call_CSGC020(string idNumber)
        {
            var response = new ResponseModel();
            try
            {
                var strCommand = @$"EXEC {_dc.SchemaDB()?.CustomerInfo}.CSGC020 '{idNumber?.Trim()}'";
                var result = await _dc.Get<List<object>>(strCommand, CommandType.Text);
                if (result.success)
                {
                    response.status = 200;
                    response.success = result.success;
                    response.data = result.data;
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return response;
        }

        public async Task<ResponseModel> GetTelephoneInfoList(InputTelephoneInfoModel input)  //Old Name: Call_CSGC013
        {
            var response = new ResponseModel();
            try
            {
                var strCommand = @$"EXEC {_dc.SchemaDB()?.CustomerInfo}.sp_GetTelephoneInfo '{input.collectorID?.Trim()}', '{input.idNo?.Trim()}'";
                var result = await _dc.Get<List<ResultTelephoneInfoModel>>(strCommand, CommandType.Text);
                if (result.success)
                {
                    response.status = 200;
                    response.success = result.success;
                    response.data = result.data;
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return response;
        }

        public async Task<ResponseModel> GetBusinessList(InputBusinessModel input)  //Old Name: Call_CSGC013
        {
            var response = new ResponseModel();
            try
            {
                var strCommand = @$"EXEC {_dc.SchemaDB()?.CustomerInfo}.sp_GetCustomer_Business  '{input.idNo?.Trim() ?? input.id?.Trim()}', '{input.collectorID?.Trim()}', '{input.type?.Trim() ?? input.status?.Trim()}'";
                var result = await _dc.Get<List<ResultBusinessModel>>(strCommand, CommandType.Text);
                if (result.success)
                {
                    response.status = 200;
                    response.success = result.success;
                    response.data = result.data;
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return response;
        }
        public async Task<ResponseModel> GetMapPortToUsername(string port, string user)
        {
            var response = new ResponseModel();
            try
            {
                var strCommand = @$"SELECT TOP(1) [M8RRNO],[M8PORT],[M8CUSR],[M8TUSR],[M8TDAT],[M8TTIM],[M8UPGM],[M8UUSR],[M8UJOB],[M8UDAT],[M8UTIM],[M8DEL] FROM {_dc.SchemaDB()?.GN}.[GNMS81] WHERE M8PORT = '{port}' AND M8CUSR = '{user}' AND M8DEL = ''  ";
                var result = await _dc.Get<JObject>(strCommand, CommandType.Text);

                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = (Int32)result.data?.GetValue("Column1") == 1;
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return response;
        }
        public async Task<ResponseModel> GetOfficerTeamMemberForLG(string port, string user)
        {
            var response = new ResponseModel();
            try
            {
                var strCommand = @$"SELECT COUNT(*)
                                    FROM{_dc.SchemaDB()?.CS}.[CSWKR124] WKR124
                                    JOIN {_dc.SchemaDB()?.CS}.CSWKR123 WKR123
                                    ON WKR124.WKCOTM = WKR123.WKCOTM
                                    WHERE WKCOID = '{port}'  AND WKTMLD = '{user}'";
                var result = await _dc.Get<JObject>(strCommand, CommandType.Text);

                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = (Int32)result.data?.GetValue("Column1") == 1;
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return response;
        }
        public async Task<ResponseModel> InsertLogDataTracking(CSMSLGModel input)
        {
            var response = new ResponseModel();
            try
            {
                string updateDate = (DateTime.Now.Year + 543).ToString() + DateTime.Now.ToString("MMdd");
                string updateTime = DateTime.Now.ToString("HHmmss");
                var strCommand = @$"INSERT INTO {_dc.SchemaDB()?.CS}.[CSMSLG]
           ([MLGTYP],[MLGSRH],[MLGTNM],[MLGTSN],[MLGUDT],[MLGUTM],[MLGUUS],[MLGUPG],[MLGUWS],[MLGSTS],[MLGBRN])
     VALUES
            ('{(string.IsNullOrEmpty(input.MLGTYP)? "" : input.MLGTYP)}'
            ,'{(string.IsNullOrEmpty(input.MLGSRH) ? "" : input.MLGSRH)}'
            ,'{(string.IsNullOrEmpty(input.MLGTNM) ? "" : input.MLGTNM)}'
            ,'{(string.IsNullOrEmpty(input.MLGTSN) ? "" : input.MLGTSN)}'
            ,{updateDate},{updateTime}
            ,'{(string.IsNullOrEmpty(input.MLGUUS) ? "" : input.MLGUUS)}'
            ,'{(string.IsNullOrEmpty(input.MLGUPG) ? "" : input.MLGUPG)}'
            ,'{(string.IsNullOrEmpty(input.MLGUWS) ? "" : input.MLGUWS)}'
            ,'{(string.IsNullOrEmpty(input.MLGSTS) ? "" : input.MLGSTS)}'
           ,'{(input.MLGBRN == null ? 0 : input.MLGBRN)}')";
                var result = await _dc.Execute(strCommand, CommandType.Text);
                if (result.success)
                {
                    response.success = result.success;
                    response.message = "Success";
                }
                else response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return response;
        }
    }
}
