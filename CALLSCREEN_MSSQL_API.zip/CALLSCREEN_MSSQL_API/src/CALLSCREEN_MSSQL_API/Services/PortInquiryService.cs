﻿using CALLSCREEN_MSSQL_API.DataAccess.Interfaces;
using CALLSCREEN_MSSQL_API.Models;
using System.Data;

namespace CALLSCREEN_MSSQL_API.Services
{
    public class PortInquiryService
    {
        protected readonly IDataCenter _dc;
        public PortInquiryService(IDataCenter dc) => _dc = dc;

        public async Task<ResponseModel> GetDataPortInquiry(GetDataPortInquiry input)  //Old Name: Call_CSGC00
        {
            var response = new ResponseModel();
            try
            {
                var strCommand = @$"EXEC {_dc.SchemaDB()?.RL}.[spGetPortInquiryList] '{input.collecterId}'";
                var result = await _dc.Get<List<DataPortInquiryModel>>(strCommand, CommandType.Text);
                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = result.data;
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return response;
        }

    }
}
