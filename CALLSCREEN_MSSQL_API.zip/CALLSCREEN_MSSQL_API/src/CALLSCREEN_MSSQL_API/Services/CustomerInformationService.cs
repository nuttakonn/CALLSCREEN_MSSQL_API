﻿using CALLSCREEN_MSSQL_API.DataAccess.Interfaces;
using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Models.CustomerInformation;
using System;
using System.Data;

namespace CALLSCREEN_MSSQL_API.Services
{
    public class CustomerInformationService
    {
        protected readonly IDataCenter _dc;
        public CustomerInformationService(IDataCenter dc) => _dc = dc;

        public async Task<ResponseModel> GetDataESTM(string idNumber)
        {
            var response = new ResponseModel();
            try
            {
                //var strCommand = @$"SELECT M00IDN, V7CSNO, V7RGDT, V7ACDT,
                //                       CASE V7CTYP WHEN 'M' THEN 'MO' WHEN 'L' THEN 'LINE' WHEN 'C' THEN 'Change Customer Data' WHEN 'R' THEN 'RL Screen' ELSE V7CTYP END AS V7CTYP
                //                    FROM {_dc.SchemaDB()?.RL}.RLMV07 A
                //                    INNER JOIN {_dc.SchemaDB()?.CS}.CSMS00 B on A.V7CSNO = B.M00CSN
                //                    WHERE M00IDN = '${idNumber?.Trim()}'";
                var strCommand = @$"SELECT IDCARD, V7CSNO, V7RGDT, V7ACDT,
                                      CASE V7CTYP WHEN 'M' THEN 'MO' WHEN 'L' THEN 'LINE' WHEN 'C' THEN 'CHANGE CUSTOMER DATA' WHEN 'R' THEN 'RL SCREEN' ELSE V7CTYP END AS V7CTYP
                                    FROM {_dc.SchemaDB()?.RL}.RLMV07 A WITH (NOLOCK)
                                    INNER JOIN {_dc.SchemaDB()?.CustomerInfo}.CUSTOMERGENERAL B WITH (NOLOCK) ON A.V7CSNO = B.CISNUMBER
                                    WHERE IDCARD = '{idNumber?.Trim()}'";

                var result = await _dc.Get<ESTMModel>(strCommand, CommandType.Text);
                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = result.data;
                }
                else
                    response.status = 400;
                response.success = true;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.message = ex.Message;
            }
            return await Task.FromResult(response);
        }


        public async Task<ResponseModel> GetDataRCLCode(string idNumber)
        {
            var response = new ResponseModel();
            try
            {
                var result = new RCLCodeModel();
                var strCommand = @$"EXEC {_dc.SchemaDB()?.CS}.CSGC110 '{idNumber?.Trim()}'";
                var resultHead = await _dc.Get<RCLCodeHeadModel>(strCommand, CommandType.Text);
                var resultDetail = await _dc.Get<List<RCLCodeDetailModel>>(strCommand, CommandType.Text);
                if (resultHead.success)
                {
                    response.status = 200;
                    response.success = resultHead.success;
                    response.data = resultHead.data;
                }
                else
                    response.status = 400;
                response.message = resultHead.message;

                result.RCLCodeHead = resultHead.data;
                result.RCLCodeDetail = resultDetail.data;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return response;
        }

        public async Task<ResponseModel> GetDataMobileApplication(string idNumber)  //Old Name: Call_CSGC048
        {
            var response = new ResponseModel();
            try
            {
                string strCommand = $@"SELECT 2RGDT AS registerDate,
                                             V2RGTM AS registerTime,
                                             V2CONT AS contractNo,
                                             V2CSNO AS csnNo,
                                             V2CARD AS cardNo,
                                             V2BDTE AS birthDate,
                                             V2IDNO AS idNo,
                                             V2CTYP AS channelType,
                                             V2UPDT AS updateDate,
                                             V2UPTM AS updateTime,
                                             V2UPUS AS userId,
                                             V2UPPG AS program,
                                             V2UPWS AS workStation,
                                             V2USTS AS userStatus
                                         FROM {_dc.SchemaDB()?.RL}.RLMV02 WITH (NOLOCK)
                                        WHERE V2IDNO = '${idNumber?.Trim()}'
                                          AND V2USTS = ''";
                var result = await _dc.Get<ResultMobileApplicationModel>(strCommand, CommandType.Text);
                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = result.data;
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return response;
        }

        public async Task<ResponseModel> GetDataConditionIncome(string brnach,string app,string vendorCode,string operationType)
        {
            var response = new ResponseModel();
            try
            {
                var strCommand = @$"SELECT [T05BRN] BranchCode,[T05APP] ApplicationCode,[T05VEN] VendorCdoe,[T05DTE] ProcessingDate,[T05OPR] OperationType,[T05STR] StartDate
,[T05END] EndDate,[T05INC] Income
FROM {_dc.SchemaDB()?.CS}.CSTB05 
WHERE T05BRN = '{brnach.Trim()}'
and T05APP = '{app.Trim()}'
and T05VEN = '{vendorCode.Trim()}'
and T05OPR = '{operationType.Trim()}'";
                var result = await _dc.Get<List<ResultDataConditionIncome>>(strCommand, CommandType.Text);
                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = result.data;
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.message = ex.Message;
            }
            return response;
        }
        
        public async Task<ResponseModel> GetCustomerNoByCSN(string CISNumber)
        {
            var response = new ResponseModel();
            try
            {
                var strCommand = @$"EXEC {_dc.SchemaDB()?.CustomerInfo}.sp_GetCustomerNoByCSN '{CISNumber?.Trim()}'";
                var result = await _dc.Get<CustomerNoModel>(strCommand, CommandType.Text);
                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = result.data;
                }
                else
                {
                    response.data = new CustomerNoModel() { CustomerNo = "0" };
                    response.status = 400;
                }
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.data = new CustomerNoModel() { CustomerNo = "0" };
                response.error = ex;
                response.message = ex.Message;
            }
            return response;
        }
    }
}
