﻿using CALLSCREEN_MSSQL_API.DataAccess.Interfaces;
using CALLSCREEN_MSSQL_API.Models;
using System.Data;

namespace CALLSCREEN_MSSQL_API.Services
{
    public class ChangeTelephoneService
    {
        protected readonly IDataCenter _dc;
        public ChangeTelephoneService(IDataCenter dc) => _dc = dc;

        public async Task<ResponseModel> GetDataRelation()  //Old Name: Call_CSGC041
        {
            var response = new ResponseModel();
            try
            {
                var strCommand = @$"SELECT DISTINCT GN14CD,
                                           GN14CD + ':' + GN14TD AS GN14TD
                                      FROM {_dc.SchemaDB()?.GN}.GNTB14 WITH (NOLOCK)
                                  ORDER BY GN14CD";
                var result = await _dc.Get<List<ResultRelationModel>>(strCommand, CommandType.Text);
                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = result.data;
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return response;
        }
        public async Task<ResponseModel> GetCustomerContractPhoneNumber(RequestChangeTelModel input) // Oldname Call_GNSRTELS
        {
            var response = new ResponseModel();
            try
            {
                var strCommand = @$"EXEC {_dc.SchemaDB()?.CustomerInfo}.spGetCustomerPhoneNumber '{input.csnNo?.Trim()}', '{input.idno?.Trim()}'";
                var result = await _dc.Get<List<GNSRTELSModel>>(strCommand, CommandType.Text);
                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = result.data;
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return response;
        }
    }
}
