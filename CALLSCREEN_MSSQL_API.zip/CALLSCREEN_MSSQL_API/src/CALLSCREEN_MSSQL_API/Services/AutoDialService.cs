﻿using CALLSCREEN_MSSQL_API.DataAccess.Interfaces;
using CALLSCREEN_MSSQL_API.Models;
using System.Data;
using System.DirectoryServices;

namespace CALLSCREEN_MSSQL_API.Services
{
    public class AutoDialService
    {
        protected readonly IDataCenter _dc;
        public AutoDialService(IDataCenter dc) => _dc = dc;

        public async Task<ResponseModel> ExecuteQuery(string query)
        {
            var response = new ResponseModel();
            try
            {
                var strCommand = query;
                var result = await _dc.Get<object>(strCommand, CommandType.Text);

                if (result.success)
                {
                    response.status = 200;
                    response.success = result.success;
                    response.data = result.data;
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.message = ex.Message;
            }
            return response;
        }

        public async Task<ResponseModel> IsAuthenticatedLDAP(LoginModel input)
        {
            var response = new ResponseModel();
            try
            {
                //var settingLDAP = JsonConvert.DeserializeObject<AuthenticatedLDAPModel>(AppSetting.Configuration["AuthenticatedLDAP"]);
                var settingLDAP = AppSetting.Configuration?.GetSection("AuthenticatedLDAP")?.Get<AuthenticatedLDAPModel>() ?? new AuthenticatedLDAPModel();
                string initLDAPPath = string.Format("dc={0}, dc={1}", settingLDAP.AutoDialDC1, settingLDAP.AutoDialDC2);
                string? initLADPServer = settingLDAP.AutoDialServerIP;
                string? initShortDomainName = settingLDAP.AutoDialDomainName;
                string? strCommu = ("LDAP://" + (initLADPServer + ("/" + initLDAPPath)));
                string? domainAndUsername = initShortDomainName + @"\" + input.Username;
                DirectoryEntry entry = new DirectoryEntry(strCommu, domainAndUsername, input.Password);

                DirectorySearcher search = new DirectorySearcher(entry);
                //search.Filter = "(&(objectClass=user) (cn=" + input.Username + "))";
                search.Filter = "(SAMAccountName=" + input.Username + ")";
                search.PropertiesToLoad.Add("cn");
                SearchResult result = search.FindOne();

                if (result != null)
                {
                    response.status = 200;
                    response.success = true;
                    response.data = true;
                }
                else
                {
                    response.status = 400;
                    response.data = false;
                }
                response.message = "Connection successful.";
            }
            catch (Exception ex)
            {
                response.data = false;
                response.error = ex;
                response.message = ex.Message;
            }
            return await Task.FromResult(response);
        }
    }
}
