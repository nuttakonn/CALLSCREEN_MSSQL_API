﻿using CALLSCREEN_MSSQL_API.DataAccess.Interfaces;
using CALLSCREEN_MSSQL_API.Models;
using Newtonsoft.Json.Linq;
using System.Data;

namespace CALLSCREEN_MSSQL_API.Services
{
    public class HomeService
    {
        protected readonly IDataCenter _dc;
        public HomeService(IDataCenter dc) => _dc = dc;

        public async Task<ResponseModel> GetCurrentDate()
        {
            var response = new ResponseModel();
            try
            {
                //var strCommand = @$"SELECT M97DTE + 25000000 AS CurrentDate FROM CSOD0001.CSMS97 WHERE M97CDE = '01'";
                var strCommand = @$"SELECT CAST(M97DTE + 25000000 AS INTEGER) AS CurrentDate FROM {_dc.SchemaDB()?.CS}.CSMS97 WITH (NOLOCK) WHERE M97CDE = '01'";
                var result = await _dc.Get<HomeModel>(strCommand, CommandType.Text);

                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = result.data?.CurrentDate;
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.message = ex.Message;
            }
            return await Task.FromResult(response);
        }

        public async Task<ResponseModel> CheckCallIn(string username, string deptCode)  //Old Name: Call_CSGC190
        {
            var response = new ResponseModel();
            try
            {
                var strCommand = string.Empty;
                if (deptCode == "CAL4")
                {
                    string strTime = DateTime.Now.ToString("HHmmss");
                    string strcsms97 = @$"(SELECT M97DTE + 25000000 FROM {_dc.SchemaDB()?.CS}.CSMS97 WITH (NOLOCK) WHERE M97CDE = '01')";
                    strCommand = @$"SELECT COUNT(*) FROM {_dc.SchemaDB()?.CS}.CSMCB11 WITH (NOLOCK) WHERE T1PCNO = '{username}' AND T1DEL <> 'X' 
                                    AND (T1SDAT < {strcsms97} OR 
                                        T1SDAT = {strcsms97} AND T1STIM <= {strTime} 
                                    AND T1EDAT > {strcsms97} OR 
                                        T1EDAT = {strcsms97} AND T1ETIM >= {strTime})";
                }
                else
                {
                    strCommand = @$"SELECT COUNT(*) FROM {_dc.SchemaDB()?.GenPortInfo}.LogInCallScreen WITH (NOLOCK) WHERE Collector = '{username?.Trim()}' AND Campaign = 'CALL-IN'";
                }
                var result = await _dc.Get<JObject>(strCommand, CommandType.Text);
                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = (Int32)result.data?.GetValue("Column1") == 1;
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return response;
        }

        public async Task<ResponseModel> GetHomeParameter(string username)
        {
            var response = new ResponseModel();
            try
            {
                var strCommand = @$"SELECT TOP(1) Level AS UserLevel, Campaign FROM {_dc.SchemaDB()?.GenPortInfo}.LogInCallScreen WITH (NOLOCK)
                                    WHERE Collector = '{username}' AND Level = (SELECT MAX(Level) FROM {_dc.SchemaDB()?.GenPortInfo}.LogInCallScreen WHERE Collector = '{username}' AND RecordStatus <> 'I') AND RecordStatus <> 'I' ";
                var result = await _dc.Get<HomeParameterModel>(strCommand, CommandType.Text);

                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = new HomeModel { UserLevel = result.data?.userLevel ?? 0, Campaign = new CampaignModel { campaign = result.data?.campaign, isError = result.data?.campaign == null } };
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }
            return response;
        }
    }
}
