﻿using CALLSCREEN_MSSQL_API.DataAccess.Interfaces;
using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Services.Interfaces;
using System.Data;

namespace CALLSCREEN_MSSQL_API.Services
{
    public class AddNoteService : IAddNoteService
    {
        protected readonly IDataCenter _dc;
        public AddNoteService(IDataCenter dc) => _dc = dc;

        public async Task<ResponseModel> GetSMSMain()
        {
            var response = new ResponseModel();
            try
            {
                string cmdText = $@"SELECT G32GRP, G30DSE, G32SUB, G31DSE, G32SCD, G32SMS, G32TEL
                                    FROM {_dc.SchemaDB()?.GN}.GNSMS32
                                    INNER JOIN {_dc.SchemaDB()?.GN}.GNSMS30 ON G30GRP = G32GRP
                                    INNER JOIN {_dc.SchemaDB()?.GN}.GNSMS31 ON G31SUB = G32SUB
                                    WHERE G30DEL = 'A' AND G31DEL = 'A' AND G32DEL = 'A'
                                    ORDER BY ROW_NUMBER() OVER (ORDER BY (SELECT NULL)), G32SUB, G32SCD";

                var result = await _dc.Get<List<ResultSMSMainModel>>(cmdText, CommandType.Text);

                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = result.data;
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }

            return await Task.FromResult(response);
        } 
    }
}
