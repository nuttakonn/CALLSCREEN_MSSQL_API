﻿namespace CALLSCREEN_MSSQL_API.Common.Interfaces
{
    public interface ICipher
    {
        public string Decrypt(string cyphertext);
        public string EncryptString(string InputText);
        public string DecryptString(string InputText);
    }
}
