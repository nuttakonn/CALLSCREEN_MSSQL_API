﻿using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Math;
using Org.BouncyCastle.OpenSsl;
using System.Security.Cryptography;
using System.Text;

namespace CALLSCREEN_MSSQL_API.Common
{
    public class Cipher : Interfaces.ICipher
    {
        private readonly string _keyPath;
        private readonly IConfiguration _config;
        public Cipher(IConfiguration config)
        {
            _config = config;
            _keyPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot");
        }
        public string Decrypt(string cyphertext)
        {
            var privKeyFile = Path.Combine(_keyPath, _config.GetValue<string>("PrivateKey"));
            using TextReader privReader = new StringReader(System.IO.File.ReadAllText(privKeyFile));
            var keyPair = (AsymmetricCipherKeyPair)new PemReader(privReader).ReadObject();
            var privParams = (RsaPrivateCrtKeyParameters)keyPair.Private;
            var rsaParams = _ConvertRSAParameters(privParams);

            var bCypherText2 = Convert.FromBase64String(cyphertext);
            var csp2 = new RSACryptoServiceProvider(2048);
            csp2.ImportParameters(rsaParams);

            var bPlaintext = csp2.Decrypt(bCypherText2, RSAEncryptionPadding.Pkcs1);
            return System.Text.Encoding.Unicode.GetString(bPlaintext);
        }
        private RSAParameters _ConvertRSAParameters(RsaPrivateCrtKeyParameters privKey)
        {
            RSAParameters rp = new RSAParameters();
            rp.Modulus = privKey.Modulus.ToByteArrayUnsigned();
            rp.Exponent = privKey.PublicExponent.ToByteArrayUnsigned();
            rp.P = privKey.P.ToByteArrayUnsigned();
            rp.Q = privKey.Q.ToByteArrayUnsigned();
            rp.D = _ConvertRSAParametersField(privKey.Exponent, rp.Modulus.Length);
            rp.DP = _ConvertRSAParametersField(privKey.DP, rp.P.Length);
            rp.DQ = _ConvertRSAParametersField(privKey.DQ, rp.Q.Length);
            rp.InverseQ = _ConvertRSAParametersField(privKey.QInv, rp.Q.Length);
            return rp;
        }

        private byte[] _ConvertRSAParametersField(BigInteger n, int size)
        {
            byte[] bs = n.ToByteArrayUnsigned();

            if (bs.Length == size)
                return bs;

            if (bs.Length > size)
                throw new ArgumentException("Specified size too small", "size");

            byte[] padded = new byte[size];
            Array.Copy(bs, 0, padded, size - bs.Length, bs.Length);
            return padded;
        }

        /// ConnectionEcrypt
        public string EncryptString(string InputText)
        {
            RijndaelManaged rijndaelManaged = new RijndaelManaged();
            byte[] bytes = Encoding.Unicode.GetBytes(InputText);
            byte[] bytes2 = Encoding.ASCII.GetBytes(sKey.Length.ToString());
            PasswordDeriveBytes passwordDeriveBytes = new PasswordDeriveBytes(sKey, bytes2);
            ICryptoTransform transform = rijndaelManaged.CreateEncryptor(passwordDeriveBytes.GetBytes(16), passwordDeriveBytes.GetBytes(16));
            MemoryStream memoryStream = new MemoryStream();
            CryptoStream cryptoStream = new CryptoStream(memoryStream, transform, CryptoStreamMode.Write);
            cryptoStream.Write(bytes, 0, bytes.Length);
            cryptoStream.FlushFinalBlock();
            byte[] inArray = memoryStream.ToArray();
            memoryStream.Close();
            cryptoStream.Close();
            return Convert.ToBase64String(inArray);
        }

        public string DecryptString(string InputText)
        {
            string result;
            try
            {
                RijndaelManaged rijndaelManaged = new RijndaelManaged();
                byte[] array = Convert.FromBase64String(InputText);
                byte[] bytes = Encoding.ASCII.GetBytes(sKey.Length.ToString());
                PasswordDeriveBytes passwordDeriveBytes = new PasswordDeriveBytes(sKey, bytes);
                ICryptoTransform transform = rijndaelManaged.CreateDecryptor(passwordDeriveBytes.GetBytes(16), passwordDeriveBytes.GetBytes(16));
                MemoryStream memoryStream = new MemoryStream(array);
                CryptoStream cryptoStream = new CryptoStream(memoryStream, transform, CryptoStreamMode.Read);
                byte[] array2 = new byte[array.Length];
                int count = cryptoStream.Read(array2, 0, array2.Length);
                memoryStream.Close();
                cryptoStream.Close();
                string @string = Encoding.Unicode.GetString(array2, 0, count);
                result = @string;
            }
            catch (Exception ex)
            {
                result = ex.Message;
            }
            return result;
        }
        private static string sKey = "UJYHCX783her*&5@$%#(MJCX**38n*#6835ncv56tvbry(&#MX98cn342cn4*&X#&";
    }
}
