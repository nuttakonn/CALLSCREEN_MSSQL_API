﻿namespace CALLSCREEN_MSSQL_API.Models
{
    public class HomeModel
    {
        public int UserLevel { get; set; }
        public bool CheckSoftPhone { get; set; }
        public bool CheckAutoDial { get; set; }
        public string? CurrentDate { get; set; }
        public UserSoftPhoneModel? SoftPhoneUser { get; set; }
        public CampaignModel? Campaign { get; set; }
        public TimeSpan TimeStamp { get; set; }
    }
    public class UserSoftPhoneModel
    {
        public string? user { get; set; }
        public string? branch { get; set; }

    }
    public class CampaignModel
    {
        public string? campaign { get; set; }
        public string? lastError { get; set; }
        public bool isError { get; set; }
    }

    public class HomeParameterModel
    {
        public int userLevel { get; set; }
        public string? campaign { get; set; }
    }
}
