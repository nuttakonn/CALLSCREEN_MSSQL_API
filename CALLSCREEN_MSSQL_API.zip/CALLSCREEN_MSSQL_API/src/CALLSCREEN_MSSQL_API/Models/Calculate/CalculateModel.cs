﻿namespace CALLSCREEN_MSSQL_API.Models.Calculate
{
    public class CalculateModel
    {
        public string? contractNo { get; set; }
        public double principal { get; set; }
        public string? contDate { get; set; }
        public double duty { get; set; }
    }

    public class ResultILClosing
    {
        public string? P23TTM { get; set; }
        public decimal P23INY { get; set; }
        public decimal P23CRY { get; set; }
        public decimal P23IN1 { get; set; }
        public decimal P23IN2 { get; set; }
        public decimal P23IN3 { get; set; }
        public decimal D012IR { get; set; }
        public decimal D012CR { get; set; }
        public string? TotalTerm { get => P23TTM?.Trim(); set => P23TTM = value?.Trim(); }
        public decimal IntYear { get => P23INY; set => P23INY = value; }
        public decimal CruYear { get => P23CRY; set => P23CRY = value; }
        public decimal Term1 { get => P23IN1; set => P23IN1 = value; }
        public decimal Term29 { get => P23IN2; set => P23IN2 = value; }
        public decimal Term10 { get => P23IN3; set => P23IN3 = value; }
        public decimal Ints { get => D012IR; set => D012IR = value; }
        public decimal Cre { get => D012CR; set => D012CR = value; }
    }

    public class LoanILContractModel
    {
        public int P23TTM { get; set; }
        public decimal P23INY { get; set; }
        public decimal P23CRY { get; set; }
        public decimal P23IN1 { get; set; }
        public decimal P23IN2 { get; set; }
        public decimal P23IN3 { get; set; }
    }

    public class InterestRateModel
    {
        public decimal D012IR { get; set; }
        public decimal D012CR { get; set; }
    }

    public class InstallmentDetail
    {
        public int Term { get; set; }
        public string? BeginDate { get; set; }
        public int Days { get; set; }
        public decimal Interest { get; set; }
        public decimal CRUsage { get; set; }
        public decimal Income { get; set; }
        public decimal Installment { get; set; }
        public decimal PayPrincipal { get; set; }
        public decimal Amount { get; set; }
        public decimal Rebate { get; set; }
        public decimal PrinCipal { get; set; }
    }

    public class DueDateModel
    {
        public decimal P21DUE { get; set; }
    }
}
