﻿namespace CALLSCREEN_MSSQL_API.Models
{
    public class ResultDataCallRemindRM
    {
        public string? G34IDN { get; set; }
        public decimal G34DUE { get; set; }
        public string? G34CNT { get; set; }
    }
}
