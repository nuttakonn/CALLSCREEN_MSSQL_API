﻿namespace CALLSCREEN_MSSQL_API.Models
{
    public class WriteOffSellModel
    {
        public string? WOStatus { get; set; }

    }

    public class TotalWOAmtModel
    {
        public decimal TotalWOAmt { get; set; }
    }

    public class GetTotalWOAmtModel
    {
        public string? business { get; set; }
        public string? contractNo { get; set; }
    }
}
