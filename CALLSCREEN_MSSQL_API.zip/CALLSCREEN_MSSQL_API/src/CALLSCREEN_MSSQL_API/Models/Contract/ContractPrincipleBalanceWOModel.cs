﻿namespace CALLSCREEN_MSSQL_API.Models.Contract
{
    public class ContractPrincipleBalanceWOModel
    {
        public List<PrincipleModel> principleList { get; set; }
        public ContractPrincipleBalanceWOModel(){
            this.principleList = new List<PrincipleModel>();
        }
    }
    public class PrincipleModel
    {
        public string ContractNumber { get; set; }
        public decimal PrincipleBalance { get; set; }
    }
}
