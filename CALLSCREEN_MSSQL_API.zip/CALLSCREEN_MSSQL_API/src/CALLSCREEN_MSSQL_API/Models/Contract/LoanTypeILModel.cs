﻿namespace CALLSCREEN_MSSQL_API.Models
{
    public class GetLoanTypeILModel
    {
        public string? contractNo { get; set; }
        public string? branchNo { get; set; }
    }

    public class ResultLoanTypeILModel
    {
        public string? loanType { get; set; }
    }
}
