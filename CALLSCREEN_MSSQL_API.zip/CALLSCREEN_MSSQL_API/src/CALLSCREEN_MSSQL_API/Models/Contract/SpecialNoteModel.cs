﻿namespace CALLSCREEN_MSSQL_API.Models
{
    public class SpecialNoteModel
    {
        public string? SpecialNote { get; set; }

    }
}
