﻿namespace CALLSCREEN_MSSQL_API.Models
{
    public class GetContractLeaderCodeModel
    {
        public string? leaderCode { get; set; }
    }
}
