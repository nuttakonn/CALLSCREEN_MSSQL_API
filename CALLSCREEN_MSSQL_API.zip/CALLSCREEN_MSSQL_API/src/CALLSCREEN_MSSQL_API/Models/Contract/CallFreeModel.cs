﻿using System.Globalization;

namespace CALLSCREEN_MSSQL_API.Models
{
    public class ResultCallFreeModel
    {
        public string? T8TELN { get; set; }
        public string? T8DESC { get; set; }
        public decimal T8UDAT { get; set; }
        public decimal T8UTIM { get; set; }
        public string? T8UUSR { get; set; }
        public string? T8UPGM { get; set; }
        public string? T8UJOB { get; set; }
        public string? T8DEL { get; set; }

        public string? telNo { get => T8TELN?.Trim(); set => T8TELN = value; }
        public string? telDetail { get => T8DESC?.Trim(); set => T8DESC = value; }
        public DateTime? updateDate
        {
            get
            {
                if (T8UDAT.ToString("#").Length >= 8) return DateTime.ParseExact(T8UDAT.ToString("#"), "yyyyMMdd", new CultureInfo("th-TH"));
                else if (T8UDAT.ToString("#").Length == 6) return DateTime.ParseExact(T8UDAT.ToString("#"), "yyMMdd", new CultureInfo("th-TH"));
                else return default(DateTime?);
            }
            set => T8UDAT = decimal.Parse(value?.ToString("yyyyMMdd") ?? "0");
        }
        public string? updateTime
        {
            get
            {
                if (T8UTIM.ToString("#").Length == 6) return DateTime.ParseExact(T8UTIM.ToString("#"), "HHmmss", new CultureInfo("th-TH")).ToString("HH:mm:ss");
                else return default;
            }
            set => T8UTIM = decimal.Parse(value?.ToString() ?? "0");
        }
        public string? userID { get => T8UUSR?.Trim(); set => T8UUSR = value?.Trim(); }
        public string? updateByProgram { get => T8UPGM?.Trim(); set => T8UPGM = value?.Trim(); }
        public string? updateWorkStation { get => T8UJOB?.Trim(); set => T8UJOB = value?.Trim(); }
        public string? recordStatus { get => T8DEL?.Trim(); set => T8DEL = value?.Trim(); }
    }
}
