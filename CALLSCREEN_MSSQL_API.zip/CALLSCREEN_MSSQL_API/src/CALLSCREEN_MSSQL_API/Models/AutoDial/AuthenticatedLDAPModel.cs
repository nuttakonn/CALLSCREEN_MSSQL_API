﻿namespace CALLSCREEN_MSSQL_API.Models
{
    public class AuthenticatedLDAPModel
    {
        public string? AutoDialDC1 { get; set; }
        public string? AutoDialDC2 { get; set; }
        public string? AutoDialServerIP { get; set; }
        public string? AutoDialDomainName { get; set; }
    }
}
