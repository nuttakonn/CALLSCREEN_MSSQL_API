﻿namespace CALLSCREEN_MSSQL_API.Models.Negotiate
{
    public class NegotiateModel
    {
        public PaymentDetailModel paymentDetail { get; set; }
        public List<PaymentListModel> paymentData { get; set; }
        public List<ContractListModel> contactData { get; set; }
        public NegotiateModel()
        {
            this.paymentDetail = new PaymentDetailModel();
            this.paymentData = new List<PaymentListModel>();
            this.contactData = new List<ContractListModel>();
        }
    }

    public class RequestNegotiateModel
    {
        public string idNo { get; set; }
        public string contractNo { get; set; }
    }

    public class PaymentDetailModel
    {
        public DateTime? bookingDate { get; set; }
        public DateTime? receiveDate { get; set; }
        public decimal receiveAmount { get; set; }
        public DateTime? ppDate { get; set; }
        public DateTime? ppTime { get; set; }
        public decimal ppAmount { get; set; }
        public string ppChannel { get; set; }
        public decimal ppNo { get; set; }
        public decimal penaltyNo { get; set; }
        public decimal pdAmount { get; set; }
        public string pdChannel { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }

    }

    public class PaymentListModel
    {
        public DateTime? bookingDate { get; set; }
        public DateTime? receiveDate { get; set; }
        public decimal receiveAmount { get; set; }
        public string channel { get; set; }
    }

    public class ContractListModel
    {
        public string biz { get; set; }
        public string telType { get; set; }
        public string personCode { get; set; }
        public string resultCode { get; set; }
        public string description { get; set; }
        public DateTime? date { get; set; }
    }
}
