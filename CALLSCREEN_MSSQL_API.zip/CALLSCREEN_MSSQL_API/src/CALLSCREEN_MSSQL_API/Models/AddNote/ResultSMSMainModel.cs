﻿namespace CALLSCREEN_MSSQL_API.Models
{
    public class ResultSMSMainModel
    {
        public string? G32GRP { get; set; }
        public string? G30DSE { get; set; }
        public string? G32SUB { get; set; }
        public string? G31DSE { get; set; }
        public string? G32SCD { get; set; }
        public string? G32SMS { get; set; }
        public string? G32TEL { get; set; }
        public string? GROUP32 { get => G32GRP?.Trim(); set => G32GRP = value; }
        public string? DESCRIPTION30 { get => G30DSE?.Trim(); set => G30DSE = value; }
        public string? SUB32 { get => G32SUB?.Trim(); set => G32SUB = value; }
        public string? DESCRIPTION31 { get => G31DSE?.Trim(); set => G31DSE = value; }
        public string? SCD32 { get => G32SCD?.Trim(); set => G32SCD = value; }
        public string? SMS32 { get => G32SMS?.Trim(); set => G32SMS = value; }
        public string? callInNo { get => G32TEL?.Trim(); set => G32TEL = value; }
    }
}
