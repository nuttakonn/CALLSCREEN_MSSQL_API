﻿namespace CALLSCREEN_MSSQL_API.Models
{
    public class ResultLGInstallmentModel
    {
        public List<LGInstallmentDetailModel>? detail { get; set; }
    }

    public class LGInstallmentDetailModel
    {
        public decimal C7STRDAT { get; set; }
        public decimal C7ENDDAT { get; set; }
        public decimal C7RATE { get; set; }

        public string? startDate { get => this.C7STRDAT.ToString("#"); set => C7STRDAT = decimal.TryParse(value, out Decimal valueParse) ? valueParse : default(decimal); }
        public string? endDate { get => this.C7ENDDAT.ToString("#"); set => C7ENDDAT = decimal.TryParse(value, out Decimal valueParse) ? valueParse : default(decimal); }
        public decimal amount { get => this.C7RATE; set => this.C7RATE = value; }
    }
}
