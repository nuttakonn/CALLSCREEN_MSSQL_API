﻿using System.Globalization;

namespace CALLSCREEN_MSSQL_API.Models
{
    public class InputLGReceiveModel
    {
        public string? contractNo { get; set; }
        public string? receiptNo { get; set; }
    }

    public class ResultLGReceiveModel
    {
        public LGReceiveHeaderModel? header { get; set; }
        public List<LGReceiveDetailModel>? detail { get; set; }
    }

    public class LGReceiveHeaderModel
    {
        public string? C2TYPE { get; set; }
        public decimal C2RCDAT { get; set; }
        public decimal C2BKDAT { get; set; }
        public decimal C2BKTIM { get; set; }
        public string? C2RCNO { get; set; }
        public decimal C2RCAMT { get; set; }
        public decimal C2RCFAM { get; set; }
        public decimal C2RCJBAL { get; set; }
        public string? C2RCUSR { get; set; }
        public string? C2RCCOL { get; set; }
        public decimal C2BJDBL { get; set; }
        public string? C2RCTYP { get; set; }
        public decimal C2RCEXC { get; set; }
        public decimal C2RCOVC { get; set; }
        public decimal C2JDOVC { get; set; }
        public string? C2RCDED { get; set; }
        public string? C2CANC { get; set; }
        public decimal C2CDATE { get; set; }
        public decimal C2CTIME { get; set; }
        public string? C2CUSER { get; set; }


        public DateTime? recDate
        {
            get
            {
                if (C2RCDAT.ToString("#").Length == 8) return DateTime.ParseExact(C2RCDAT.ToString("#"), "yyyyMMdd", new CultureInfo("th-TH"));
                else if (C2RCDAT.ToString("#").Length == 6) return DateTime.ParseExact(C2RCDAT.ToString("#"), "yyMMdd", new CultureInfo("th-TH"));
                else return default(DateTime?);
            }
            set => C2RCDAT = decimal.Parse(value?.ToString("yyyyMMdd") ?? "0");
        }
        public DateTime? bookingDate
        {
            get
            {
                if (C2BKDAT.ToString("#").Length == 8) return DateTime.ParseExact(C2BKDAT.ToString("#"), "yyyyMMdd", new CultureInfo("th-TH"));
                else if (C2BKDAT.ToString("#").Length == 6) return DateTime.ParseExact(C2BKDAT.ToString("#"), "yyMMdd", new CultureInfo("th-TH"));
                else return default(DateTime?);
            }
            set => C2BKDAT = decimal.Parse(value?.ToString("yyyyMMdd") ?? "0");
        }
        public string? receiptNo { get => C2RCNO?.Trim(); set => C2RCNO = value?.Trim(); }
        public decimal receiptAmount { get => C2RCAMT; set => C2RCAMT = value; }
        public decimal referenceAmount { get => C2RCFAM; set => C2RCFAM = value; }
        public decimal judgeBal { get => C2RCJBAL; set => C2RCJBAL = value; }
        public string? bookingBy { get => C2RCUSR?.Trim(); set => C2RCUSR = value?.Trim(); }
        public string? collector { get => C2RCCOL?.Trim(); set => C2RCCOL = value?.Trim(); }
        public decimal totJD { get => C2BJDBL; set => C2BJDBL = value; }
        public string? recType { get => C2RCTYP?.Trim(); set => C2RCTYP = value?.Trim(); }
        public decimal excAmount { get => C2RCEXC; set => C2RCEXC = value; }
        public decimal recOverClosing { get => C2RCOVC; set => C2RCOVC = value; }
        public decimal judgeOverClosing { get => C2JDOVC; set => C2JDOVC = value; }
        public string? rcvDeduct { get => C2RCDED?.Trim(); set => C2RCDED = value?.Trim(); }
        public string? tempstr1 { get => C2CANC?.Trim(); set => C2CANC = value?.Trim(); }
        public string? tempstr2 { get => C2CDATE.ToString("#"); set => C2CDATE = decimal.Parse(value?.Trim() ?? "0"); }
        public string? tempstr3 { get => C2CTIME.ToString("#"); set => C2CTIME = decimal.Parse(value?.Trim() ?? "0"); }
        public string? tempstr4 { get => C2CUSER?.Trim(); set => C2CUSER = value?.Trim(); }
    }

    public class LGReceiveDetailModel
    {
        public string? C3ACTYP { get; set; }
        public string? C3DFTYP { get; set; }
        public decimal C3RCAMT { get; set; }
        public string? C3RCNO { get; set; }

        public string? accountType { get => C3ACTYP?.Trim(); set => C3ACTYP = value?.Trim(); }
        public string? accountDesc { get => C3RCNO?.Trim(); set => C3RCNO = value?.Trim(); }
        public string? typeofDefault { get => C3DFTYP?.Trim(); set => C3DFTYP = value?.Trim(); }
        public decimal amount { get => C3RCAMT; set => C3RCAMT = value; }
    }
}
