﻿namespace CALLSCREEN_MSSQL_API.Models
{
    public class ResultLGTemplateModel
    {
        public LGTemplateHeaderModel? header { get; set; }
        public List<LGTemplateDetailModel>? detail { get; set; }
    }

    public class LGTemplateHeaderModel
    {
        public decimal C4STRDAT { get; set; }
        public decimal C4ENDDAT { get; set; }
        public string? C4TMPDES { get; set; }

        public string? tempStartDate { get => C4STRDAT.ToString("#"); set => C4STRDAT = decimal.Parse(value?.Trim() ?? "0"); }
        public string? tempEndDate { get => C4ENDDAT.ToString("#"); set => C4ENDDAT = decimal.Parse(value?.Trim() ?? "0"); }
        public string? tempDetail { get => C4TMPDES?.Trim(); set => C4TMPDES = value?.Trim(); }
    }

    public class LGTemplateDetailModel
    {
        public string? C4STRDAT { get; set; }
        public string? C4ENDDAT { get; set; }
        public string? C4TMPDES { get; set; }
        public string? C4TMPDD { get; set; }
        public decimal C4TMPPR { get; set; }
        public string? C4ACTYP { get; set; }
        public string? C4ACDES { get; set; }

        public string? deductType { get => C4TMPDD?.Trim(); set => C4TMPDD = value?.Trim(); }
        public int priority { get => (Int32)C4TMPPR; set => this.C4TMPPR = value; }
        public string? accountType { get => C4ACTYP?.Trim(); set => this.C4ACTYP = value?.Trim(); }
        public string? accountDesc { get => C4ACDES?.Trim(); set => this.C4ACDES = value?.Trim(); }
    }
}
