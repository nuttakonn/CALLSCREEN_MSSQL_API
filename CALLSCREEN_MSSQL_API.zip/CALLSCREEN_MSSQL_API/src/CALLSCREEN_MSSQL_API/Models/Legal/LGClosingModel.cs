﻿namespace CALLSCREEN_MSSQL_API.Models
{
    public class InputLGClosingModel
    {
        public string? contractNo { get; set; }
        public string? curDate { get; set; }
    }

    public class ResultLGClosingModel
    {
        public LGClosingHeaderModel? header { get; set; }
        public List<LGClosingDetailModel>? detail { get; set; }
    }

    public class LGClosingHeaderModel
    {
        public string C9BIZ { get; set; }
        public decimal C9TJBAL { get; set; }
        public decimal C9CLAMT { get; set; }
        public decimal C9JUDBAL { get; set; }
        public decimal C9RTAMT { get; set; }
        public decimal C9EPAMT { get; set; }

        public string biz { get => C9BIZ; }
        public decimal totalJudgBal { get => C9TJBAL; set => C9TJBAL = value; }
        public decimal closingAmount { get => C9CLAMT; set => C9CLAMT = value; }
        public decimal judgeBalance { get => C9JUDBAL; set => C9JUDBAL = value; }
        public decimal rateAmount { get => C9RTAMT; set => C9RTAMT = value; }
        public decimal expenseAmount { get => C9EPAMT; set => C9EPAMT = value; }
    }

    public class LGClosingDetailModel
    {
        public string? C9ACTYP { get; set; }
        public string? C9ACDES { get; set; }
        public string? C9RTTYP { get; set; }
        public decimal C9STRDAT { get; set; }
        public decimal C9ENDDAT { get; set; }
        public decimal C9RATE { get; set; }
        public decimal C9TMPDD { get; set; }
        public decimal C9RCDAT { get; set; }
        public decimal C9RCAMT { get; set; }
        public decimal C9UPDAMT { get; set; }

        public string? accoutType { get => C9ACTYP?.Trim(); set => C9ACTYP = value?.Trim(); }
        public string? accountDesc { get => C9ACDES?.Trim(); set => C9ACDES = value?.Trim(); }
        public string? rateType { get => C9RTTYP?.Trim(); set => C9RTTYP = value?.Trim(); }
        public string? startMonthDate { get => C9STRDAT.ToString("#"); set => C9STRDAT = decimal.TryParse(value?.Trim(), out decimal valueOut) ? valueOut : default(decimal); }
        public string? endMonthDate { get => C9ENDDAT.ToString("#"); set => C9ENDDAT = decimal.TryParse(value?.Trim(), out decimal valueOut) ? valueOut : default(decimal); }
        public decimal rate { get => C9RATE; set => C9RATE = value; }
        public int days { get => (Int32)C9TMPDD; set => C9TMPDD = value; }
        public decimal amount { get => C9RCAMT; set => C9RCAMT = value; }
        public decimal unpaidAmount { get => C9UPDAMT; set => C9UPDAMT = value; }
        public decimal totalAmount { get => C9RCDAT; set => C9RCDAT = value; }
    }
}
