﻿using System.Globalization;

namespace CALLSCREEN_MSSQL_API.Models
{
    public class ResultLGSkipDueModel
    {
        public List<LGSkipDueDetailModel>? detail { get; set; }
    }

    public class LGSkipDueDetailModel
    {
        public decimal C9STRDAT { get; set; }
        public decimal C9ENDDAT { get; set; }
        public string? C9KYUSR { get; set; }
        public decimal C9KYDAT { get; set; }

        public string? startMonth { get => C9STRDAT.ToString("#"); set => C9STRDAT = decimal.Parse(value?.Trim() ?? "0"); }
        public string? endMonth { get => C9ENDDAT.ToString("#"); set => C9ENDDAT = decimal.Parse(value?.Trim() ?? "0"); }
        public string? keyBy { get => C9KYUSR?.Trim(); set => C9KYUSR = value?.Trim(); }
        public DateTime? keyDate
        {
            get
            {
                if (C9KYDAT.ToString("#").Length == 8) return DateTime.ParseExact(C9KYDAT.ToString("#"), "yyyyMMdd", new CultureInfo("th-TH"));
                else if (C9KYDAT.ToString("#").Length == 6) return DateTime.ParseExact(C9KYDAT.ToString("#"), "yyMMdd", new CultureInfo("th-TH"));
                else return default(DateTime?);
            }
            set => C9KYDAT = decimal.Parse(value?.ToString("yyyyMMdd") ?? "0");
        }
    }
}
