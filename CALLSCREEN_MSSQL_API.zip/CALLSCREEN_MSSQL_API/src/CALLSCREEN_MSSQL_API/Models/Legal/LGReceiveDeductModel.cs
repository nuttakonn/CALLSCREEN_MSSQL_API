﻿using System.Globalization;

namespace CALLSCREEN_MSSQL_API.Models
{
    public class ResultLGReceiveDeductModel
    {
        public List<LGReceiveDeductDetailModel>? detail { get; set; }
    }

    public class LGReceiveDeductDetailModel
    {
        public string? C8RCNO { get; set; }
        public string? C8TMPDD { get; set; }
        public string? C8LTTYP { get; set; }
        public decimal C8RCDAT { get; set; }
        public decimal C8BKDAT { get; set; }
        public decimal C8RCAMT { get; set; }

        public string? receiptNo { get => C8RCNO?.Trim(); set => C8RCNO = value?.Trim(); }
        public string? deductType { get => C8TMPDD?.Trim(); set => C8TMPDD = value?.Trim(); }
        public string? letterType { get => C8LTTYP?.Trim(); set => C8LTTYP = value?.Trim(); }
        public DateTime? receiveDate
        {
            get
            {
                if (C8RCDAT.ToString("#").Length == 8) return DateTime.ParseExact(C8RCDAT.ToString("#"), "yyyyMMdd", new CultureInfo("th-TH"));
                else if (C8RCDAT.ToString("#").Length == 6) return DateTime.ParseExact(C8RCDAT.ToString("#"), "yyMMdd", new CultureInfo("th-TH"));
                else return default(DateTime?);
            }
            set => C8RCDAT = decimal.Parse(value?.ToString("yyyyMMdd") ?? "0");
        }
        public DateTime? bookingDate
        {
            get
            {
                if (C8BKDAT.ToString("#").Length == 8) return DateTime.ParseExact(C8BKDAT.ToString("#"), "yyyyMMdd", new CultureInfo("th-TH"));
                else if (C8BKDAT.ToString("#").Length == 6) return DateTime.ParseExact(C8BKDAT.ToString("#"), "yyMMdd", new CultureInfo("th-TH"));
                else return default(DateTime?);
            }
            set => C8BKDAT = decimal.Parse(value?.ToString("yyyyMMdd") ?? "0");
        }
        public decimal receiptAmount { get => C8RCAMT; set => C8RCAMT = value; }
    }
}
