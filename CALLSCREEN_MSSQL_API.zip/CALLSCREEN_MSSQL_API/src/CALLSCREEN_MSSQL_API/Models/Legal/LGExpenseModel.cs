﻿namespace CALLSCREEN_MSSQL_API.Models
{
    public class ResultLGExpenseModel
    {
        public List<LGExpenseDetailModel>? detail { get; set; }
    }

    public class LGExpenseDetailModel
    {
        public string? C6ACTYP { get; set; }
        public string? C6ACDES { get; set; }
        public decimal C6STRDAT { get; set; }
        public decimal C6ENDDAT { get; set; }
        public decimal C6RATE { get; set; }
        public decimal C6MAXAMT { get; set; }
        public decimal C6PADAMT { get; set; }
        public decimal C6UPDAMT { get; set; }

        public string? accountType { get => C6ACTYP?.Trim(); set => C6ACTYP = value; }
        public string? accountTypeDesc { get => C6ACDES?.Trim(); set => C6ACDES = value; }
        public string? startMonth { get => C6STRDAT.ToString("#"); set => C6STRDAT = decimal.Parse(value?.Trim() ?? "0"); }
        public string? endMonth { get => C6ENDDAT.ToString("#"); set => C6ENDDAT = decimal.Parse(value?.Trim() ?? "0"); }
        public decimal amount { get => C6RATE; set => C6RATE = value; }
        public decimal limitAmount { get => C6MAXAMT; set => C6MAXAMT = value; }
        public decimal paidAmount { get => C6PADAMT; set => C6PADAMT = value; }
        public decimal unPaidAmount { get => C6UPDAMT; set => C6UPDAMT = value; }
    }
}
