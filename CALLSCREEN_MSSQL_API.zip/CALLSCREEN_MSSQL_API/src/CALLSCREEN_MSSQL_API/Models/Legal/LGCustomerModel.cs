﻿using System.Globalization;

namespace CALLSCREEN_MSSQL_API.Models
{
    public class InputLGCustomerModel
    {
        public string? contractNo { get; set; }
        public string? curDate { get; set; }
    }

    public class ResultLGCustomerModel
    {
        public LGCustomerHeaderModel? header { get; set; }
        public List<LGCustomerDetailModel>? detail { get; set; }
    }

    public class LGCustomerHeaderModel
    {
        public string? C1NAM { get; set; }
        public string? C1NCK { get; set; }
        public string? C1IDN { get; set; }
        public string? C1JDTYP { get; set; }
        public decimal C1IC1D { get; set; }
        public string? C1COLL { get; set; }
        public decimal C1CLAMT { get; set; }
        public string? C1RUNN { get; set; }
        public string? C1CRTCD { get; set; }
        public string? C1CRTNM { get; set; }
        public string? C1CRTNO { get; set; }
        public string? C1ISSUE { get; set; }
        public decimal C1ACUDAT { get; set; }
        public decimal C1ACUAMT { get; set; }
        public decimal C1JUDDAT { get; set; }
        public decimal C1JUDAMT { get; set; }
        public decimal C1JUDBAL { get; set; }
        public decimal C1JUDTBL { get; set; }
        public decimal C1TOTREC { get; set; }
        public decimal C1KEYDAT { get; set; }
        public string? C1KEYUSR { get; set; }
        public decimal C1EXCAMT { get; set; }
        public decimal C1TOTTRM { get; set; }
        public string? C1DEFFLG { get; set; }
        public decimal C1STRDEF { get; set; }
        public decimal C1DUE { get; set; }
        public decimal C1FSTDUE { get; set; }
        public decimal C1LSTDUE { get; set; }
        public decimal C1CLODAT { get; set; }
        public string? C1TMID { get; set; }
        public string? C1TMPDES { get; set; }

        public string? nameSurname => C1NAM?.Trim();
        public string? nickName => C1NCK?.Trim();
        public string? customerID => C1IDN?.Trim();
        public string? judgeCompromise => C1JDTYP?.Trim();
        public DateTime? icsd
        {
            get
            {
                if (C1IC1D.ToString("#").Length == 8) return DateTime.ParseExact(C1IC1D.ToString("#"), "yyyyMMdd", new CultureInfo("th-TH"));
                else if (C1IC1D.ToString("#").Length == 6) return DateTime.ParseExact(C1IC1D.ToString("#"), "yyMMdd", new CultureInfo("th-TH"));
                else return default(DateTime?);
            }
            set => C1IC1D = decimal.Parse(value?.ToString("yyyyMMdd") ?? "0");
        }
        public string? collector => C1COLL?.Trim();
        public decimal closingAmount => C1CLAMT;
        public string? runningNo => C1RUNN?.Trim();
        public string? courtCode => C1CRTCD?.Trim();
        public string? courtName => C1CRTNM?.Trim();
        public string? courtNo => C1CRTNO?.Trim();
        public string? issueNo => C1ISSUE?.Trim();
        public DateTime? accuseDate
        {
            get
            {
                if (this.C1ACUDAT.ToString("#").Length == 8) return DateTime.ParseExact(this.C1ACUDAT.ToString("#"), "yyyyMMdd", new CultureInfo("th-TH"));
                else if (this.C1ACUDAT.ToString("#").Length == 6) return DateTime.ParseExact(this.C1ACUDAT.ToString("#"), "yyMMdd", new CultureInfo("th-TH"));
                else return default(DateTime?);
            }
            set => this.C1ACUDAT = decimal.Parse(value?.ToString("yyyyMMdd") ?? "0");
        }
        public decimal accuseAmount => C1ACUAMT;
        public DateTime? judgeDate
        {
            get
            {
                if (C1JUDDAT.ToString("#").Length == 8) return DateTime.ParseExact(C1JUDDAT.ToString("#"), "yyyyMMdd", new CultureInfo("th-TH"));
                else if (C1JUDDAT.ToString("#").Length == 6) return DateTime.ParseExact(C1JUDDAT.ToString("#"), "yyMMdd", new CultureInfo("th-TH"));
                else return default(DateTime?);
            }
            set => C1JUDDAT = decimal.Parse(value?.ToString("yyyyMMdd") ?? "0");
        }
        public decimal judgeAmount => C1JUDAMT;
        public decimal judgeBal => C1JUDBAL;
        public decimal totJudgeBal => C1JUDTBL;
        public decimal totRec => C1TOTREC;
        public DateTime? keyDate
        {
            get
            {
                if (C1KEYDAT.ToString("#").Length == 8) return DateTime.ParseExact(C1KEYDAT.ToString("#"), "yyyyMMdd", new CultureInfo("th-TH"));
                else if (C1KEYDAT.ToString("#").Length == 6) return DateTime.ParseExact(C1KEYDAT.ToString("#"), "yyMMdd", new CultureInfo("th-TH"));
                else return default(DateTime?);
            }
            set => C1KEYDAT = decimal.Parse(value?.ToString("yyyyMMdd") ?? "0");
        }
        public string? keyBy { get => C1KEYUSR?.Trim(); set => C1KEYUSR = value?.Trim(); }
        public decimal excAmount { get => C1EXCAMT; set => C1EXCAMT = value; }
        public decimal totTerm { get => C1TOTTRM; set => C1TOTTRM = value; }
        public string? defaultFlag { get => C1DEFFLG?.Trim(); set => C1DEFFLG = value?.Trim(); }
        public DateTime? startDate
        {
            get
            {
                if (C1STRDEF.ToString("#").Length == 8) return DateTime.ParseExact(C1STRDEF.ToString("#"), "yyyyMMdd", new CultureInfo("th-TH"));
                else if (C1STRDEF.ToString("#").Length == 6) return DateTime.ParseExact(C1STRDEF.ToString("#"), "yyMMdd", new CultureInfo("th-TH"));
                else return default(DateTime?);
            }
            set => C1STRDEF = decimal.Parse(value?.ToString("yyyyMMdd") ?? "0");
        }
        public decimal due => C1DUE;
        public DateTime? firstDue
        {
            get
            {
                if (C1FSTDUE.ToString("#").Length == 8) return DateTime.ParseExact(C1FSTDUE.ToString("#"), "yyyyMMdd", new CultureInfo("th-TH"));
                else if (C1FSTDUE.ToString("#").Length == 6) return DateTime.ParseExact(C1FSTDUE.ToString("#"), "yyMMdd", new CultureInfo("th-TH"));
                else return default(DateTime?);
            }
            set => C1FSTDUE = decimal.Parse(value?.ToString("yyyyMMdd") ?? "0");
        }
        public DateTime? lastDue
        {
            get
            {
                if (C1LSTDUE.ToString("#").Length == 8) return DateTime.ParseExact(C1LSTDUE.ToString("#"), "yyyyMMdd", new CultureInfo("th-TH"));
                else if (C1LSTDUE.ToString("#").Length == 6) return DateTime.ParseExact(C1LSTDUE.ToString("#"), "yyMMdd", new CultureInfo("th-TH"));
                else return default(DateTime?);
            }
            set => C1LSTDUE = decimal.Parse(value?.ToString("yyyyMMdd") ?? "0");
        }
        public DateTime? closeDate
        {
            get
            {
                if (C1CLODAT.ToString("#").Length == 8) return DateTime.ParseExact(C1CLODAT.ToString("#"), "yyyyMMdd", new CultureInfo("th-TH"));
                else if (C1CLODAT.ToString("#").Length == 6) return DateTime.ParseExact(C1CLODAT.ToString("#"), "yyMMdd", new CultureInfo("th-TH"));
                else return default(DateTime?);
            }
            set => C1CLODAT = decimal.Parse(value?.ToString("yyyyMMdd") ?? "0");
        }
        public string? templateID => C1TMID?.Trim();
        public string? templateDesc => C1TMPDES?.Trim();
        public string? biz { get; set; }
    }

    public class LGCustomerDetailModel
    {
        public string? C2RTYPE { get; set; }
        public decimal C2RCDAT { get; set; }
        public decimal C2BKDAT { get; set; }
        public string? C2RCNO { get; set; }
        public decimal C2RCAMT { get; set; }
        public decimal C2RCFAM { get; set; }
        public decimal C2RCJBAL { get; set; }
        public string? C2RCUSR { get; set; }
        public string? C2RCCOL { get; set; }
        public decimal C2BJDBL { get; set; }
        public string? C2RCTYP { get; set; }
        public decimal C2RCEXC { get; set; }
        public decimal C2RCOVC { get; set; }
        public string? C2RCDED { get; set; }
        public string? C2RCCAN { get; set; }

        public string? type { get => C2RTYPE?.Trim(); set => C2RTYPE = value; }
        public DateTime? receiveDate
        {
            get
            {
                if (C2RCDAT.ToString("#").Length == 8) return DateTime.ParseExact(C2RCDAT.ToString("#"), "yyyyMMdd", new CultureInfo("th-TH"));
                else if (C2RCDAT.ToString("#").Length == 6) return DateTime.ParseExact(C2RCDAT.ToString("#"), "yyMMdd", new CultureInfo("th-TH"));
                else return default(DateTime?);
            }
            set => C2RCDAT = decimal.Parse(value?.ToString("yyyyMMdd") ?? "0");
        }
        public DateTime? bookingDate
        {
            get
            {
                if (C2BKDAT.ToString("#").Length == 8) return DateTime.ParseExact(C2BKDAT.ToString("#"), "yyyyMMdd", new CultureInfo("th-TH"));
                else if (C2BKDAT.ToString("#").Length == 6) return DateTime.ParseExact(C2BKDAT.ToString("#"), "yyMMdd", new CultureInfo("th-TH"));
                else return default(DateTime?);
            }
            set => C2BKDAT = decimal.Parse(value?.ToString("yyyyMMdd") ?? "0");
        }
        public string? receiptNo { get => C2RCNO?.Trim(); set => C2RCNO = value?.Trim(); }
        public decimal receiptAmount { get => C2RCAMT; set => C2RCAMT = value; }
        public decimal referenceAmount { get => C2RCFAM; set => C2RCFAM = value; }
        public decimal JudgeAmount { get => C2RCJBAL; set => C2RCJBAL = value; }
        public string? user { get => C2RCUSR?.Trim(); set => C2RCUSR = value?.Trim(); }
        public string? collector { get => C2RCCOL?.Trim(); set => C2RCCOL = value?.Trim(); }
        public string? recType { get => C2RCTYP?.Trim(); set => C2RCTYP = value?.Trim(); }
        public decimal totJDBeforeRC { get => C2BJDBL; set => C2BJDBL = value; }
        public decimal excessAmout { get => C2RCEXC; set => C2RCEXC = value; }
        public decimal recOverClosing { get => C2RCOVC; set => C2RCOVC = value; }
        public string? rcvDeduct { get => C2RCDED; set => C2RCDED = value?.Trim(); }
        public string? can { get => C2RCCAN?.Trim(); set => C2RCCAN = value?.Trim(); }
    }
}
