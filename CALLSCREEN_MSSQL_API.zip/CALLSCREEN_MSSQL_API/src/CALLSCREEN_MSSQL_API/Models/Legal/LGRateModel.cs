﻿using System.Globalization;

namespace CALLSCREEN_MSSQL_API.Models
{
    public class ResultLGRateModel
    {
        public LGRateHeaderModel? header { get; set; }
        public List<LGRateDetailModel>? detail { get; set; }
    }
    public class LGRateHeaderModel
    {
        public decimal C5LCBRAT { get; set; }
        public decimal C5LCBDAT { get; set; }
        public decimal C5LCARAT { get; set; }
        public decimal C5LCADAT { get; set; }

        public decimal lossCostBeforeRate { get => C5LCBRAT; set => C5LCADAT = value; }
        public decimal lossCostAfterRate { get => C5LCARAT; set => C5LCADAT = value; }
        public decimal lossCostBeforeStartDate { get => C5LCBDAT; set => C5LCADAT = value; }
        public decimal lossCostAfterStartDate { get => C5LCADAT; set => C5LCADAT = value; }
    }

    public class LGRateDetailModel
    {
        public string? C5ACTYP { get; set; }
        public string? C5ACDES { get; set; }
        public string? C5DFTYP { get; set; }
        public decimal C5STRDAT { get; set; }
        public decimal C5ENDDAT { get; set; }
        public decimal C5RATE { get; set; }
        public decimal C5PRINC { get; set; }
        public decimal C5MAXAMT { get; set; }
        public decimal C5PADAMT { get; set; }
        public decimal C5UPDAMT { get; set; }

        public string? accountType { get => C5ACTYP?.Trim(); set => C5ACTYP = value?.Trim(); }
        public string? accountTypeDesc { get => C5ACDES?.Trim(); set => C5ACDES = value?.Trim(); }
        public string? typeOfDefault { get => C5DFTYP?.Trim(); set => C5DFTYP = value?.Trim(); }
        public DateTime? startDate
        {
            get
            {
                if (C5STRDAT.ToString("#").Length == 8) return DateTime.ParseExact(C5STRDAT.ToString("#"), "yyyyMMdd", new CultureInfo("th-TH"));
                else if (C5STRDAT.ToString("#").Length == 6) return DateTime.ParseExact(C5STRDAT.ToString("#"), "yyMMdd", new CultureInfo("th-TH"));
                else return default(DateTime?);
            }
            set => C5STRDAT = decimal.Parse(value?.ToString("yyyyMMdd") ?? "0");
        }
        public DateTime? endDate
        {
            get
            {
                if (C5ENDDAT.ToString("#").Length == 8) return DateTime.ParseExact(C5ENDDAT.ToString("#"), "yyyyMMdd", new CultureInfo("th-TH"));
                else if (C5ENDDAT.ToString("#").Length == 6) return DateTime.ParseExact(C5ENDDAT.ToString("#"), "yyMMdd", new CultureInfo("th-TH"));
                else return default(DateTime?);
            }
            set => C5ENDDAT = decimal.Parse(value?.ToString("yyyyMMdd") ?? "0");
        }
        public decimal rate { get => C5RATE; set => C5RATE = value; }
        public decimal principal { get => C5PRINC; set => C5PRINC = value; }
        public decimal limitAmount { get => C5MAXAMT; set => C5MAXAMT = value; }
        public decimal paidAmount { get => C5PADAMT; set => C5PADAMT = value; }
        public decimal unPaidAmount { get => C5UPDAMT; set => C5UPDAMT = value; }
    }
}
