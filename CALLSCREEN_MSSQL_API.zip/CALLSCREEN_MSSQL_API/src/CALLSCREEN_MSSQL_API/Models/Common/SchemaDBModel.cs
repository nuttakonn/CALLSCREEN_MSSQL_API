﻿namespace CALLSCREEN_MSSQL_API.Models
{
    public class SchemaDBModel
    {
        public string? BI { get; set; }
        public string? BL { get; set; }
        public string? CS { get; set; }
        public string? GL { get; set; }
        public string? GN { get; set; }
        public string? HM { get; set; }
        public string? HP { get; set; }
        public string? IL { get; set; }
        public string? IS { get; set; }
        public string? PH { get; set; }
        public string? PL { get; set; }
        public string? PM { get; set; }
        public string? PW { get; set; }
        public string? RL { get; set; }
        public string? SY { get; set; }
        public string? CustomerInfo { get; set; }
        public string? ContractInfo { get; set; }
        public string? GenPortInfo { get; set; }
    }
}
