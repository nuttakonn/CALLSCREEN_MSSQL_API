﻿using System.Globalization;

namespace CALLSCREEN_MSSQL_API.Models
{
    public class PortInquiryModel
    {
        public GetDataPortInquiry input { get; set; }
        public ResultGetDataPortInquiryModel result { get; set; }
        public PortInquiryModel()
        {
            this.input = new GetDataPortInquiry();
            this.result = new ResultGetDataPortInquiryModel();
        }
    }

    public class GetDataPortInquiry
    {
        public string? collecterId { get; set; }
    }
    public class GetDataPortInquiryENTModel
    {
        public string? collecterId { get; set; }
        public string? department { get; set; }
    }

    public class ResultGetDataPortInquiryModel
    {
        public List<DataPortInquiryModel>? portInquiryData { get; set; }
        public string? status { get; set; }
        public string? msgError { get; set; }
    }

    public class DataPortInquiryModel
    {
        public string? idNo { get; set; }
        public string? name { get; set; }
        public string? title { get; set; }
        public decimal balance { get; set; }
        public string? contractNo { get; set; }
        public DateTime? actionDate { get; set; }
        public DateTime? actionTime { get; set; }
        public string? actionCode { get; set; }
        public string? actionDesc { get; set; }
        public string? resultCode { get; set; }
        public DateTime? ppDate { get; set; }
        public DateTime? ppTime { get; set; }
        public string? status { get; set; }
        public string? user { get; set; }
        public int noOfContract { get; set; }
        public DateTime? woDate
        {
            get
            {
                if (this.woDatestr.ToString().Length == 8)
                {
                    return DateTime.ParseExact(woDatestr.ToString(), "yyyyMMdd", new CultureInfo("th-TH"));
                }
                else if (this.woDatestr.ToString().Length == 6)
                {
                    return DateTime.ParseExact(woDatestr.ToString(), "yyMMdd", new CultureInfo("th-TH"));
                }
                else
                {
                    return null;
                }
            }
            set => woDatestr = value?.ToString("yyyyMMdd") ?? default;
        }
        public string? woDatestr { get; set; }
        public DateTime? genDate
        {
            get
            {
                if (this.genDatestr?.ToString().Length == 8)
                {
                    return DateTime.ParseExact(genDatestr.ToString(), "yyyyMMdd", new CultureInfo("th-TH"));
                }
                else if (this.genDatestr?.ToString().Length == 6)
                {
                    return DateTime.ParseExact(genDatestr.ToString(), "yyMMdd", new CultureInfo("th-TH"));
                }
                else
                {
                    return null;
                }
            }
            set => genDatestr = value?.ToString("yyyyMMdd");
        }
        public string? genDatestr { get; set; }
        public string? customerType { get; set; }
        public string? customerDesc { get; set; }
        public DateTime? reAssignDate
        {
            get
            {
                if (this.reAssignDatestr?.ToString().Length == 8)
                {
                    return DateTime.ParseExact(reAssignDatestr.ToString(), "yyyyMMdd", new CultureInfo("th-TH"));
                }
                else if (this.reAssignDatestr?.ToString().Length == 6)
                {
                    return DateTime.ParseExact(reAssignDatestr.ToString(), "yyMMdd", new CultureInfo("th-TH"));
                }
                else
                {
                    return null;
                }
            }
            set => reAssignDatestr = value?.ToString("yyyyMMdd");
        }
        public string? reAssignDatestr { get; set; }
        public string? reAssignOA { get; set; }
        public string? actionOA { get; set; }
        public string? reAssignLG { get; set; }
        public string? actionLG { get; set; }
        public string? lgEnforce { get; set; }
        public string? actionEN { get; set; }
        public string? flag { get; set; }
        public string? colorCode { get; set; }
        public int custID { get; set; }
        public string? csnNo { get; set; }
    }
}
