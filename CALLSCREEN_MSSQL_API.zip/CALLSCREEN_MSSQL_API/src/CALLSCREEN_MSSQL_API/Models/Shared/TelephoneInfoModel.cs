﻿namespace CALLSCREEN_MSSQL_API.Models
{
    public class InputTelephoneInfoModel
    {
        public string? collectorID { get; set; }
        public string? idNo { get; set; }
    }

    public class ResultTelephoneInfoModel
    {
        public string? C1CSTTP { get; set; }
        public string? C1SBTYP { get; set; }
        public string? C1CSTEL { get; set; }
        public string? C1CSTEX { get; set; }
        public string? C1CSNAM { get; set; }
        public string? C1TLCNT { get; set; }
        public string? C1LIMFG { get; set; }
        public string? C1TLCNTM { get; set; }
        public string? C1LMCNT { get; set; }
        public string? C1CLTFG { get; set; }
        public string? C1LMCNM { get; set; }

        public string? telType { get => this.C1CSTTP?.Trim(); set => this.C1CSTTP = value?.Trim(); }
        public string? telSeq { get => this.C1SBTYP?.Trim(); set => this.C1SBTYP = value?.Trim(); }
        public string? lastTel { get => this.C1CSTEL?.Trim(); set => this.C1CSTEL = value?.Trim(); }
        public string? btype { get => this.C1SBTYP?.Trim(); set => this.C1SBTYP = value?.Trim(); }
        public string? custTelNo { get => this.C1CSTEL?.Trim(); set => this.C1CSTEL = value?.Trim(); }
        public string? custTelEx { get => this.C1CSTEX?.Trim(); set => this.C1CSTEX = value?.Trim(); }
        public string? contactName { get => this.C1CSNAM?.Trim(); set => this.C1CSNAM = value?.Trim(); }
        public decimal telDay { get => decimal.TryParse(C1TLCNT?.Trim(), out decimal valueOut) ? valueOut : default(decimal); set => this.C1TLCNT = value.ToString(); }
        public string? telLimit { get => this.C1LIMFG?.Trim(); set => this.C1LIMFG = value?.Trim(); }
        public string? pkey { get; set; }
        public string? telNo { get; set; }
        public string? telEXT { get; set; }
        public decimal telMonth { get => decimal.TryParse(C1TLCNTM?.Trim(), out decimal valueOut) ? valueOut : default(decimal); set => this.C1TLCNTM = value.ToString(); }
        public decimal telLimitDay { get => decimal.TryParse(C1LMCNT?.Trim(), out decimal valueOut) ? valueOut : default(decimal); set => this.C1LMCNT = value.ToString(); }
        public string? lastFlag { get => this.C1CLTFG?.Trim(); set => this.C1CLTFG = value?.Trim(); }
        public decimal telLimitMonth { get => decimal.TryParse(C1LMCNM?.Trim(), out decimal valueOut) ? valueOut : default(decimal); set => this.C1LMCNM = value.ToString(); }
    }
}
