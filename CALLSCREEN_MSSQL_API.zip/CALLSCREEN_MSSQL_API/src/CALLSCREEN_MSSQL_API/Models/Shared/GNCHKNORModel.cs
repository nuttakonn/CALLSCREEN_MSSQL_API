﻿namespace CALLSCREEN_MSSQL_API.Models
{
    public class GNCHKNORModel
    {
        public InputGNCHKNORModel input { get; set; }
        public OutputGNCHKNORModel result { get; set; }

        public GNCHKNORModel()
        {
            this.result = new OutputGNCHKNORModel();
        }
    }

    public class InputGNCHKNORModel
    {
        public string? branchCode { get; set; }
        public string? userName { get; set; }
        public string? customerID { get; set; }
        public string? biz { get; set; }
        public string? contractNo { get; set; }
    }

    public class OutputGNCHKNORModel
    {
        public string? authFlag { get; set; }
    }
}
