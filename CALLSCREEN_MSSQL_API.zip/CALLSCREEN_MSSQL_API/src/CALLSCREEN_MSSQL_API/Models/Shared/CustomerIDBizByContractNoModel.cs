﻿namespace CALLSCREEN_MSSQL_API.Models
{
    public class ResultCustomerIDBizByContractNoModel
    {
        public string? biz { get; set; }
        public string? customerID { get; set; }
    }
}
