﻿namespace CALLSCREEN_MSSQL_API.Models
{
    public class InputBusinessModel
    {
        public string? id { get; set; }
        public string? status { get; set; }

        public string? idNo { get; set; }
        public string? collectorID { get; set; }
        public string? type { get; set; }
    }

    public class ResultBusinessModel
    {
        public string? C1BUSS { get; set; }
        public string? C1BUSSDS { get; set; }

        public string? bizCode { get => C1BUSS?.Trim(); set => C1BUSS = value?.Trim(); }
        public string? bizDescription { get => C1BUSSDS?.Trim(); set => C1BUSSDS = value?.Trim(); }
    }
}
