﻿namespace CALLSCREEN_MSSQL_API.Models
{
    public class CSMSLGModel
    {
        public int MLGRRNO { get; set; }
        public string? MLGTYP { get; set; }
        public string? MLGSRH { get; set; }
        public string? MLGTNM { get; set; }
        public string? MLGTSN { get; set; }
        public decimal? MLGUDT { get; set; }
        public decimal? MLGUTM { get; set; }
        public string? MLGUUS { get; set; }
        public string? MLGUPG { get; set; }
        public string? MLGUWS { get; set; }
        public string? MLGSTS { get; set; }
        public decimal? MLGBRN { get; set; }
    }
}
