﻿namespace CALLSCREEN_MSSQL_API.Models.CustomerInformation
{
    public class RCLCodeModel
    {
        public RCLCodeHeadModel RCLCodeHead { set; get; }
        public List<RCLCodeDetailModel> RCLCodeDetail { set; get; }
        public RCLCodeModel()
        {
            this.RCLCodeHead = new RCLCodeHeadModel();
            this.RCLCodeDetail = new List<RCLCodeDetailModel>();
        }
    }

    public class RCLCodeHeadModel
    {
        public string? result { set; get; }
        public decimal creditLimitTCL { set; get; }
        public decimal creditAvailableTCA { set; get; }
        public decimal paymentAbility { set; get; }
        public string? ilMessage { set; get; }
    }

    public class RCLCodeDetailModel
    {
        public string? POCOND { get; set; }
        public string? POPASS { get; set; }
        public string? PONPAS { get; set; }

        public int no { get; set; }
        public string? condition { get => POCOND?.Trim(); set => POCOND = value?.Trim(); }
        public string? pass { get => POPASS?.Trim(); set => POPASS = value?.Trim(); }
        public string? notpass { get => PONPAS?.Trim(); set => PONPAS = value?.Trim(); }
    }

    public class ResultDataConditionIncome
    {
        public string? BranchCode { get; set; }
        public string? ApplicationCode { get; set; }
        public string? VendorCdoe { get; set; }
        public string? ProcessingDate { get; set; }
        public string? OperationType { get; set; }
        public string? StartDate { get; set; }
        public string? EndDate { get; set; }
        public string? Income { get; set; }
    }
}
