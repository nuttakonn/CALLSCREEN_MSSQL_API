﻿namespace CALLSCREEN_MSSQL_API.Models.CustomerInformation
{
    public class CustomerNoModel
    {
        public string CustomerNo { get; set; }
    }
}
