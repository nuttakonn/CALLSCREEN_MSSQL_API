﻿namespace CALLSCREEN_MSSQL_API.Models
{
    public class ResultMobileApplicationModel
    {
        public decimal registerDate { get; set; }
        public decimal registerTime { get; set; }
        public decimal contractNo { get; set; }
        public decimal csnNo { get; set; }
        public decimal cardNo { get; set; }
        public decimal birthDate { get; set; }
        public string? idNo { get; set; }
        public string? channelType { get; set; }
        public decimal updateDate { get; set; }
        public decimal updateTime { get; set; }
        public string? userId { get; set; }
        public string? program { get; set; }
        public string? workStation { get; set; }
        public string? userStatus { get; set; }
    }
}
