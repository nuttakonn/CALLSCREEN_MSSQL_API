﻿using System.Globalization;

namespace CALLSCREEN_MSSQL_API.Models
{
    public class ESTMModel
    {
        public decimal V7RGDT { get; set; }
        public string? V7CTYP { get; set; }
        public decimal V7ACDT { get; set; }


        public DateTime? registerEStatementDate
        {
            get
            {
                if (V7RGDT != 0)
                {
                    string strDate = V7RGDT.ToString().PadLeft(8, '0').Substring(6, 2) + V7RGDT.ToString().Substring(4, 2) + V7RGDT.ToString().Substring(0, 4);
                    //DateTime dateTime = new DateTime();
                    //strDate.ToString().Trim().BuddhistDateStringToDate(ref dateTime, "ddMMyyyy");
                    //return dateTime;
                    return DateTime.ParseExact(strDate, "ddMMyyyy", new CultureInfo("th-TH"));
                }
                else
                {
                    return null;
                }
            }
        }
        public string? channel => V7CTYP?.Trim();
        public DateTime? activateEStatementDate
        {
            get
            {
                if (V7ACDT != 0)
                {
                    string strDate = V7ACDT.ToString().PadLeft(8, '0').Substring(6, 2) + V7ACDT.ToString().Substring(4, 2) + V7ACDT.ToString().Substring(0, 4);
                    //DateTime dateTime = new DateTime();
                    //strDate.ToString().Trim().BuddhistDateStringToDate(ref dateTime, "ddMMyyyy");
                    //return dateTime;
                    return DateTime.ParseExact(strDate, "ddMMyyyy", new CultureInfo("th-TH"));
                }
                else
                {
                    return null;
                }
            }
            set => V7ACDT = decimal.Parse(value?.ToString("yyyyMMdd") ?? "0");
        }
    }
}
