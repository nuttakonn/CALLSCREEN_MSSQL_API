﻿namespace CALLSCREEN_MSSQL_API.Models
{
    public class ResultRelationModel
    {
        public string? GN14CD { get; set; }
        public string? GN14TD { get; set; }
        public string? relationCode { get => GN14CD?.Trim(); set => GN14CD = value?.Trim(); }
        public string? relationDesc { get => GN14TD?.Trim(); set => GN14TD = value?.Trim(); }
    }
}
