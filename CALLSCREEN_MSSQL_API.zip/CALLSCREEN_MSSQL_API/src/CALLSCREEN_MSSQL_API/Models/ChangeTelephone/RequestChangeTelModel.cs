﻿namespace CALLSCREEN_MSSQL_API.Models
{
    public class RequestChangeTelModel
    {
        public string? csnNo { get; set; }
        public string? idno { get; set; }
    }
    public class GNSRTELSModel
    {
        public string? type { get; set; }
        public decimal seq { get; set; }
        public string? phone { get; set; }
        public string? ext { get; set; }
        public string? limitFlag { get; set; }
    }

}
