﻿namespace CALLSCREEN_MSSQL_API.Models
{
    public class SMSSubjectModel
    {
        public InputSMSSubjectModel input { get; set; }
        public List<ResultSMSSubjectModel> result { get; set; }

        public SMSSubjectModel()
        {
            this.input = new InputSMSSubjectModel();
            this.result = new List<ResultSMSSubjectModel>();
        }
    }

    public class InputSMSSubjectModel : LoginModel
    {
        public string? keyword { get; set; }
    }

    public class ResultSMSSubjectModel
    {
        public string? G31SUB { get; set; }  //SubjectCode
        public string? G31DSE { get; set; }  //Description(Eng)
        public string? G31DST { get; set; }  //Description(Thai)
        public string? G31FIL { get; set; }
        public decimal G31UDT { get; set; }
        public decimal G31UTM { get; set; }
        public string? G31USR { get; set; }  //Update By
        public string? G31DSP { get; set; }
        public string? G31PGM { get; set; }
        public string? G31DEL { get; set; }  //Status


        public string? subjectCode { get => this.G31SUB?.Trim(); set => this.G31SUB = value; }
        public string? descriptionEN { get => this.G31DSE?.Trim(); set => this.G31DSE = value; }
        public string? descriptionTH { get => this.G31DST?.Trim(); set => this.G31DST = value; }
        public string? updateBy { get => this.G31USR?.Trim(); set => this.G31USR = value; }
        public string? status { get => this.G31DEL?.Trim(); set => this.G31DEL = value; }
    }

    public class InputSMSSubjectCodeModel
    {
        public string? G31SUB { get; set; }  //SubjectCode
        public string? G31DSE { get; set; }  //Description(Eng)
        public string? G31DST { get; set; }  //Description(Thai)
        public string? G31FIL { get; set; }
        public decimal G31UDT { get; set; }
        public decimal G31UTM { get; set; }
        public string? G31USR { get; set; }  //Update By
        public string? G31DSP { get; set; }
        public string? G31PGM { get; set; }
        public string? G31DEL { get; set; }  //Status


        public string? subjectCode => this.G31SUB?.Trim();
        public string? descriptionEN => this.G31DSE?.Trim();
        public string? descriptionTH => this.G31DST?.Trim();
        public string? updateBy => this.G31USR?.Trim();
        public string? status => this.G31DEL?.Trim();
    }

    public class ResultSaveSMSSubject
    {
        public bool success { get; set; }
        public string? lastError { get; set; }

        public ResultSaveSMSSubject()
        {
            this.success = false;
            this.lastError = "";
        }
    }
}
