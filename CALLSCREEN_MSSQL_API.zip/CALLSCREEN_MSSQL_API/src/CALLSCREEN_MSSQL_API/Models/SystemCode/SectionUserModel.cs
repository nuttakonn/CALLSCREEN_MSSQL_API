﻿using CALLSCREEN_MSSQL_API.Common.Extensions;

namespace CALLSCREEN_MSSQL_API.Models.SystemCode
{
    public class RequestSectionUserModel
    {
        public string calType { get; set; }
        public string sectionUser { get; set; }
        public string departmentUser { get; set; }
    }
    public class GetSectionUserModel
    {
        public string T9SECT { get; set; }
        public string T9DPCD { get; set; }
        public string T9DPUS { get; set; }
        public decimal T9UDAT { get; set; }
        public decimal T9UTIM { get; set; }
        public string T9UUSR { get; set; }
        public string T9UPGM { get; set; }
        public string T9UJOB { get; set; }
        public string T9DEL { get; set; }

        public string sectionUserName => this.T9SECT?.Trim();
        public string departmentCode => this.T9DPCD?.Trim();
        public string departmentUser => this.T9DPUS?.Trim();
        public DateTime? updateDate
        {
            get
            {
                DateTime dateTime = new DateTime();
                //check decimal
                long dateInt = (long)Math.Truncate(T9UDAT);
                if (dateInt.ToString().Length == 8)
                {
                    string date = dateInt.ToString().PadLeft(8, '0');
                    date.ToString().Trim().BuddhistDateStringToDate(ref dateTime, "yyyyMMdd");
                    return dateTime;
                }
                else if (T9UDAT.ToString().Length == 6)
                {
                    string date = dateInt.ToString().PadLeft(6, '0');
                    date.ToString().Trim().BuddhistDateStringToDate(ref dateTime, "yyMMdd");
                    return dateTime;
                }
                else
                {
                    return null;
                }
            }
        }
        public string updateTime
        {
            get
            {
                DateTime dateTime = new DateTime();
                //check decimal
                long timeInt = (long)Math.Truncate(T9UTIM);
                if (timeInt.ToString().Length == 6)
                {
                    string time = timeInt.ToString().PadLeft(6, '0');
                    time.ToString().Trim().BuddhistDateStringToDate(ref dateTime, "HHmmss");
                    return dateTime.ToString("HH:mm:ss");
                }
                else
                {
                    return null;
                }
            }
        }
        public string userID => this.T9UUSR?.Trim();
        public string userByProgram => this.T9UPGM?.Trim();
        public string userByWorkStation => this.T9UJOB?.Trim();
        public string recordStatus => this.T9DEL?.Trim();
    }
    public class RequestSaveSectionUserModel
    {
        public string calType { get; set; }
        public string sectionUser { get; set; }
        public string departmentUser { get; set; }
        public string userName { get; set; }
        public string updByProgram { get; set; }
        public string updWorkStation { get; set; }
        public string recordStatus { get; set; }
    }
}
