﻿using System.Globalization;

namespace CALLSCREEN_MSSQL_API.Models.SystemCode
{
    public class RequestGetDataCustomerGroupModel
    {
        public string? custGrpStatus { get; set; }
        public string? typeSequence { get; set; }
        public string? typeCode { get; set; }
        public string? typeDescription { get; set; }
        public string? fromLastMonth { get; set; }
        public string? toLastMonth { get; set; }
    }
    public class GetDataCustomerGroupModel
    {
        public string? T7STAS { get; set; }
        public string? T7TYSQ { get; set; }
        public string? T7TYCD { get; set; }
        public string? T7TYDS { get; set; }
        public decimal T7MONF { get; set; }
        public decimal T7MONT { get; set; }
        public string? T7ARRY { get; set; }
        public decimal T7UDAT { get; set; }
        public decimal T7UTIM { get; set; }
        public string? T7UUSR { get; set; }
        public string? T7UPGM { get; set; }
        public string? T7UJOB { get; set; }
        public string? T7DEL { get; set; }

        public string? custGrpStatus => this.T7STAS?.Trim();
        public string? typeSequence => this.T7TYSQ?.Trim();
        public string? typeCode => this.T7TYCD?.Trim();
        public string? typeDescription => this.T7TYDS?.Trim();
        public string? fromLastMonth { get => T7MONF.ToString("0.##"); set => T7MONF = Decimal.Parse(value ?? "0"); }
        public string? toLastMonth { get => T7MONT.ToString("0.##"); set => T7MONT = Decimal.Parse(value ?? "0"); }
        public string? arrayBy6 => this.T7ARRY?.Trim();
        public DateTime? updateDate
        {
            get
            {
                if (T7UDAT.ToString("#").Length >= 8) return DateTime.ParseExact(T7UDAT.ToString("#"), "yyyyMMdd", new CultureInfo("th-TH"));
                else if (T7UDAT.ToString("#").Length == 6) return DateTime.ParseExact(T7UDAT.ToString("#"), "yyMMdd", new CultureInfo("th-TH"));
                else return default(DateTime?);
            }
            set => T7UDAT = decimal.Parse(value?.ToString("yyyyMMdd") ?? "0");
        }
        public string? updateTime
        {
            get
            {
                if (T7UTIM.ToString("#").Length == 6) return DateTime.ParseExact(T7UTIM.ToString("#"), "HHmmss", new CultureInfo("th-TH")).ToString("HH:mm:ss");
                else return default;
            }
            set => T7UTIM = decimal.Parse(value?.ToString() ?? "0");
        }
        public string? userID => this.T7UUSR?.Trim();
        public string? userByProgram => this.T7UPGM?.Trim();
        public string? userByWorkStation => this.T7UJOB?.Trim();
        public string? recordStatus => this.T7DEL?.Trim();
    }
    public class RequestSaveCustomerGroupModel
    {
        public string? custGrpStatus { get; set; }
        public string? typeSequence { get; set; }
        public string? typeCode { get; set; }
        public string? typeDescription { get; set; }
        public string? array6 { get; set; }
        public string? fromLastMonth { get; set; }
        public string? toLastMonth { get; set; }
        public string? userName { get; set; }
        public string? updByProgram { get; set; }
        public string? updWorkStation { get; set; }
        public string? recordStatus { get; set; }
    }
    public class ResultSaveCustomerGroupModel
    {
        public bool success { get; set; }
        public string? lastError { get; set; }

        public ResultSaveCustomerGroupModel()
        {
            this.success = false;
            this.lastError = "";
        }
    }
}
