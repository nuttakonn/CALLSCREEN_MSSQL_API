﻿namespace CALLSCREEN_MSSQL_API.Models
{
    public class SMSKeywordModel
    {
        public InputSMSKeywordCodeModel input { get; set; }
        public List<ResultSMSKeywordCodeModel> result { get; set; }
        public SMSKeywordModel()
        {
            this.input = new InputSMSKeywordCodeModel();
            this.result = new List<ResultSMSKeywordCodeModel>();
        }
    }
    public class InputSMSKeywordCodeModel : LoginModel
    {
        public string? keyword { get; set; }
    }
    public class ResultSMSKeywordCodeModel
    {
        public string? G33KWD { get; set; }  //GroupKeyword
        public decimal G33LEN { get; set; }  //Length
        public string? G33DSE { get; set; }  //Description(Eng)
        public string? G33DST { get; set; }  //Description(Thai)
        public string? G33USR { get; set; }  //Update By
        public string? G33DEL { get; set; }  //Status


        public string? groupKeyword { get => this.G33KWD?.Trim(); set => this.G33KWD = value; }
        public decimal length { get => this.G33LEN; set => this.G33LEN = value; }
        public string? descriptionEN { get => this.G33DSE?.Trim(); set => this.G33DSE = value; }
        public string? descriptionTH { get => this.G33DST?.Trim(); set => this.G33DST = value; }
        public string? updateBy { get => this.G33USR?.Trim(); set => this.G33USR = value; }
        public string? status { get => this.G33DEL?.Trim(); set => this.G33DEL = value; }
    }
    public class InputSMSKeywordForUpdate
    {
        public string? groupKeyword { get; set; }
        public decimal length { get; set; }
        public string? descriptionEN { get; set; }
        public string? descriptionTH { get; set; }
        public string? updateBy { get; set; }
        public string? status { get; set; }
    }
    public class InputSMSKeywordForInsert : InputSMSKeywordForUpdate
    {

    }
    public class InputSMSKeywordForDelete : InputSMSKeywordForUpdate
    {

    }
    public class ResultSaveSMSKeyword
    {
        public bool success { get; set; }
        public string? lastError { get; set; }

        public ResultSaveSMSKeyword()
        {
            this.success = false;
            this.lastError = "";
        }
    }
}
