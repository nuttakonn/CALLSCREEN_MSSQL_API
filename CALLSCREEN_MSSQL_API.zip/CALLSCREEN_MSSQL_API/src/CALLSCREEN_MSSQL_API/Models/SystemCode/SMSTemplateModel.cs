﻿namespace CALLSCREEN_MSSQL_API.Models
{
    public class SMSTemplateModel
    {
        public InputSMSTemplateModel input { get; set; }
        public List<ResultSMSTemplateModel> result { get; set; }

        public SMSTemplateModel()
        {
            this.input = new InputSMSTemplateModel();
            this.result = new List<ResultSMSTemplateModel>();
        }
    }

    public class InputSMSTemplateModel : LoginModel
    {
        public string? groupCode { get; set; }
        public string? subjectCode { get; set; }
        public string? templateCode { get; set; }
    }

    public class InputSMSTemplateDDLModel
    {
        public string? HeadDDL { get; set; }
        public string? groupCode { get; set; }
        public string? subjectCode { get; set; }
        public string? templateCode { get; set; }
    }

    public class ResultSMSTemplateModel
    {
        public string? G32GRP { get; set; }
        public string? G32SUB { get; set; }
        public string? G32SCD { get; set; }
        public string? G32SMS { get; set; }
        public string? G32TEL { get; set; }
        public decimal G32UDT { get; set; }
        public decimal G32UTM { get; set; }
        public string? G32USR { get; set; }
        public string? G32PGM { get; set; }
        public string? G32DEL { get; set; }


        public string? groupCode => this.G32GRP?.Trim();
        public string? subjectCode => this.G32SUB?.Trim();
        public string? smsCode => this.G32SCD?.Trim();
        public string? smsWordingTemplate => this.G32SMS?.Trim();
        public string? callInNo => this.G32TEL?.Trim();
        public string? updateBy => this.G32USR?.Trim();
        public string? status => this.G32DEL?.Trim();

    }

    public class RequestSaveSMSTemplate
    {
        public string? groupCode { get; set; }
        public string? subjectCode { get; set; }
        public string? smsCode { get; set; }
        public string? smsWordingTemplate { get; set; }
        public string? callInNo { get; set; }
        public string? updateBy { get; set; }
        public string? status { get; set; }
    }

    public class ResultSaveSMSTemplate
    {
        public bool success { get; set; }
        public string? lastError { get; set; }

        public ResultSaveSMSTemplate()
        {
            this.success = false;
            this.lastError = "";
        }
    }
}
