﻿namespace CALLSCREEN_MSSQL_API.Models
{
    public class SMSDefaultModel
    {
        public InputSMSDefaultModel input { get; set; }
        public List<ResultSMSDefaultModel> result { get; set; }

        public SMSDefaultModel()
        {
            this.input = new InputSMSDefaultModel();
            this.result = new List<ResultSMSDefaultModel>();
        }
    }

    public class InputSMSDefaultModel : LoginModel
    {
        public string? keyword { get; set; }
    }

    public class ResultSMSDefaultModel
    {
        public string? G34GRP { get; set; }  //GroupCode
        public string? G34COL { get; set; }  //Collector Code
        public string? G34FIL { get; set; }
        public decimal G34UDT { get; set; }
        public decimal G34UTM { get; set; }
        public string? G34USR { get; set; }  //Update By
        public string? G34DSP { get; set; }
        public string? G34PGM { get; set; }
        public string? G34DEL { get; set; }  //Status


        public string? groupCode => this.G34GRP?.Trim();
        public string? collectorCode => this.G34COL?.Trim();
        public string? updateBy => this.G34USR?.Trim();
        public string? status => this.G34DEL?.Trim();
    }

    public class RequestSaveSMSDefaultModel
    {
        public string? G34GRP { get; set; }  //GroupCode
        public string? G34COL { get; set; }  //Collector Code
        public string? G34FIL { get; set; }
        public decimal G34UDT { get; set; }
        public decimal G34UTM { get; set; }
        public string? G34USR { get; set; }  //Update By
        public string? G34DSP { get; set; }
        public string? G34PGM { get; set; }
        public string? G34DEL { get; set; }  //Status


        public string? groupCode => this.G34GRP?.Trim();
        public string? collectorCode => this.G34COL?.Trim();
        public string? updateBy => this.G34USR?.Trim();
        public string? status => this.G34DEL?.Trim();
    }

    public class ResultSaveSMSDefault
    {
        public bool success { get; set; }
        public string? lastError { get; set; }

        public ResultSaveSMSDefault()
        {
            this.success = false;
            this.lastError = "";
        }
    }
}
