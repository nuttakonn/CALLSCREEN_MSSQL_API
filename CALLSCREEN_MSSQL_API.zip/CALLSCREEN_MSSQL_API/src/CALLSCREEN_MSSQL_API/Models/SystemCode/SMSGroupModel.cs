﻿namespace CALLSCREEN_MSSQL_API.Models
{
    public class SMSGroupModel
    {
        public InputSMSGroupCodeModel input { get; set; }
        public List<ResultSMSGroupCodeModel> result { get; set; }

        public SMSGroupModel()
        {
            this.input = new InputSMSGroupCodeModel();
            this.result = new List<ResultSMSGroupCodeModel>();
        }
    }

    public class InputSMSGroupCodeModel : LoginModel
    {
        public string? keyword { get; set; }
    }

    public class ResultSMSGroupCodeModel
    {
        public string? G30GRP { get; set; }  //GroupCode
        public string? G30DSE { get; set; }  //Description(Eng)
        public string? G30DST { get; set; }  //Description(Thai)
        public decimal G30CFL { get; set; }
        public string? G30FIL { get; set; }
        public decimal G30UDT { get; set; }
        public decimal G30UTM { get; set; }
        public string? G30USR { get; set; }  //Update By
        public string? G30DSP { get; set; }
        public string? G30PGM { get; set; }
        public string? G30DEL { get; set; }  //Status


        public string? groupCode { get => this.G30GRP?.Trim(); set => G30GRP = value?.Trim(); }
        public string? descriptionEN { get => this.G30DSE?.Trim(); set => G30DSE = value?.Trim(); }
        public string? descriptionTH { get => this.G30DST?.Trim(); set => G30DST = value?.Trim(); }
        public string? updateBy { get => this.G30USR?.Trim(); set => G30USR = value?.Trim(); }
        public string? status { get => this.G30DEL?.Trim(); set => G30DEL = value?.Trim(); }
    }

    public class InputSMSGroupModel
    {
        public string? G30GRP { get; set; }  //GroupCode
        public string? G30DSE { get; set; }  //Description(Eng)
        public string? G30DST { get; set; }  //Description(Thai)
        public decimal G30CFL { get; set; }
        public string? G30FIL { get; set; }
        public decimal G30UDT { get; set; }
        public decimal G30UTM { get; set; }
        public string? G30USR { get; set; }  //Update By
        public string? G30DSP { get; set; }
        public string? G30PGM { get; set; }
        public string? G30DEL { get; set; }  //Status


        public string? groupCode { get => this.G30GRP?.Trim(); set => G30GRP = value?.Trim(); }
        public string? descriptionEN { get => this.G30DSE?.Trim(); set => G30DSE = value?.Trim(); }
        public string? descriptionTH { get => this.G30DST?.Trim(); set => G30DST = value?.Trim(); }
        public string? updateBy { get => this.G30USR?.Trim(); set => G30USR = value?.Trim(); }
        public string? status { get => this.G30DEL?.Trim(); set => G30DEL = value?.Trim(); }
    }

    public class ResultSaveSMSGroup
    {
        public bool success { get; set; }
        public string? lastError { get; set; }

        public ResultSaveSMSGroup()
        {
            this.success = false;
            this.lastError = "";
        }
    }
}
