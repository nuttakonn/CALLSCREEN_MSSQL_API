﻿namespace CALLSCREEN_MSSQL_API.Models.SystemCode
{
    public class RequestGetListCampaignModel
    {
        public string callUser { get; set; }
    }
    public class ResultGetListCampaignModel
    {
        public string T2NUSR { get; set; }
        public string T2CAMP { get; set; }
        public string callUser => this.T2NUSR?.Trim();
        public string campaign => this.T2CAMP?.Trim();
    }
    public class InputCampaignNewStaffForCRUD
    {
        public string callUser { get; set; }
        public string campaign { get; set; }
        public string updateby { get; set; }
    }
}
