﻿namespace CALLSCREEN_MSSQL_API.Models.SystemCode
{
    public class RequestAppointPeriodModel
    {
        public string? type { get; set; }        //for : get, save
        public string? startTime { get; set; }   //for : save
        public string? endTime { get; set; }     //for : save
        public string? username { get; set; }    //for : save 
        public string? workStation { get; set; } //for : save
    }
    public class ResultAppointPeriodModel
    {
        // AS400
        public string? T5TYPE { get; set; }
        public decimal T5STIM { get; set; }
        public decimal T5ETIM { get; set; }

        public string? type { get => T5TYPE?.Trim(); set => T5TYPE = value; }
        public string? startTime
        {
            get
            {
                long timeInt = (long)Math.Truncate(T5STIM);
                var txt = timeInt.ToString().PadLeft(6, '0');
                return $"{txt[..2]}:{txt.Substring(2, 2)}:{txt[4..]}";
            }
        }
        public string? endTime
        {
            get
            {
                long timeInt = (long)Math.Truncate(T5ETIM);
                var txt = timeInt.ToString().PadLeft(6, '0');
                return $"{txt[..2]}:{txt.Substring(2, 2)}:{txt[4..]}";
            }
        }
    }
    public class InputAppointPeriodForCRUD : RequestAppointPeriodModel { }

    public class ResultSaveAppointPeriod
    {
        public bool success { get; set; }
        public string? lastError { get; set; }

        public ResultSaveAppointPeriod()
        {
            this.success = false;
            this.lastError = "";
        }
    }
}
