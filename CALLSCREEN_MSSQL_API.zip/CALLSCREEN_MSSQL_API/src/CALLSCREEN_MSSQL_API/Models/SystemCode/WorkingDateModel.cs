﻿using System.Globalization;

namespace CALLSCREEN_MSSQL_API.Models.SystemCode
{
    public class RequestWorkingDateModel
    {
        public string? workingDate { get; set; }  //for : get, save
        public string? startTime { get; set; }    //for : save
        public string? endTime { get; set; }      //for : save
        public string? username { get; set; }     //for : save
        public string? workStation { get; set; }  //for : save
    }

    public class ResultWorkingDateModel
    {
        public decimal T4HDAT { get; set; }
        public decimal T4STIM { get; set; }
        public decimal T4ETIM { get; set; }

        // AS400
        public string? date { get => T4HDAT.ToString("#").Length == 8 ? DateTime.ParseExact(T4HDAT.ToString("#"), "yyyyMMdd", new CultureInfo("th-TH", false)).ToString("dd/MM/yyyy", new CultureInfo("th-TH", false)) : " "; set => T4HDAT = Decimal.Parse(value ?? "0"); }
        public string? startTime
        {
            get
            {
                var txt = T4STIM.ToString("#").Length == 5 ? T4STIM.ToString("#").PadLeft(6, '0') : T4STIM.ToString();
                return $"{txt.Substring(0, 2)}:{txt.Substring(2, 2)}:{txt.Substring(4)}";
            }
        }
        public string? endTime
        {
            get
            {
                //var txt = T4ETIM.ToString().PadLeft(6, '0');
                var txt = T4ETIM.ToString("#").Length == 5 ? T4ETIM.ToString("#").PadLeft(6, '0') : T4ETIM.ToString("#");
                return $"{txt.Substring(0, 2)}:{txt.Substring(2, 2)}:{txt.Substring(4)}";
            }
        }
    }
    public class ResultSaveWorkingDate
    {
        public bool success { get; set; }
        public string? lastError { get; set; }
        public ResultSaveWorkingDate()
        {
            this.success = false;
            this.lastError = "";
        }
    }
}