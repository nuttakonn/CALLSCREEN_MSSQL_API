﻿
using CALLSCREEN_MSSQL_API.Common.Extensions;

namespace CALLSCREEN_MSSQL_API.Models.SystemCode
{
    public class RequestGetDataTypeAndResultModel
    {
        public string typeCode { get; set; }
        public string resultCode { get; set; }
    }

    public class GetDataTypeCodeModel
    {
        public string T8TYCD { get; set; }
        public string typeCode => this.T8TYCD?.Trim();
    }

    public class GetDataResultCodeModel
    {
        public string T8RSCD { get; set; }
        public string resultCode => this.T8RSCD?.Trim();
    }

    public class GetDataTypeCodeAndResultCodeModel
    {
        public string T8TYCD { get; set; }
        public string T8RSCD { get; set; }
        public decimal? T8UDAT { get; set; }
        public decimal? T8UTIM { get; set; }
        public string T8UUSR { get; set; }
        public string T8UPGM { get; set; }
        public string T8UJOB { get; set; }
        public string T8DEL { get; set; }

        public string typeCode => this.T8TYCD?.Trim();
        public string resultCode => this.T8RSCD?.Trim();
        public DateTime? updateDate
        {
            get
            {
                if (T8UDAT.ToString().Length == 8)
                {
                    DateTime dateTime = new DateTime();
                    string date = this.T8UDAT.ToString().PadLeft(8, '0');
                    date.ToString().Trim().BuddhistDateStringToDate(ref dateTime, "yyyyMMdd");
                    return dateTime;
                }
                else if (T8UDAT.ToString().Length == 6)
                {
                    DateTime dateTime = new DateTime();
                    string date = this.T8UDAT.ToString().PadLeft(6, '0');
                    date.ToString().Trim().BuddhistDateStringToDate(ref dateTime, "yyMMdd");
                    return dateTime;
                }
                else
                {
                    return null;
                }
            }
        }
        public string updateTime
        {
            get
            {
                if (T8UTIM.ToString().Length == 6)
                {
                    DateTime dateTime = new DateTime();
                    string time = T8UTIM.ToString().PadLeft(6, '0');
                    time.ToString().Trim().BuddhistDateStringToDate(ref dateTime, "HHmmss");
                    return dateTime.ToString("HH:mm:ss");
                }
                else
                {
                    return null;
                }
            }
        }
        public string userID => this.T8UUSR?.Trim();
        public string userByProgram => this.T8UPGM?.Trim();
        public string userByWorkStation => this.T8UJOB?.Trim();
        public string recordStatus => this.T8DEL?.Trim();
    }

    public class RequestSaveTypeAndResultModel
    {
        public string? typeCode { get; set; }
        public string? resultCode { get; set; }
        public string? userName { get; set; }
        public string? updByProgram { get; set; }
        public string? updWorkStation { get; set; }
        public string? recordStatus { get; set; }
    }

    public class ResultSaveTypeAndResultModel
    {
        public bool success { get; set; }
        public string lastError { get; set; }

        public ResultSaveTypeAndResultModel()
        {
            this.success = false;
            this.lastError = "";
        }
    }
}
