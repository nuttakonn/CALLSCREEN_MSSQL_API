﻿namespace CALLSCREEN_MSSQL_API.Models.SystemCode
{
    public class RequestDataRankingModel
    {
        public bool isShowAll { get; set; }
        public string rankCode { get; set; }
        public string biz { get; set; }
        public string due { get; set; }
        public string odStatus { get; set; }
        public string odTerm { get; set; }
    }
    public class ResultGetListRankingModel
    {
        public string T9CODE { get; set; }
        public string T9DESC { get; set; }
        public string T9PERC { get; set; }
        public decimal T9BALA { get; set; }
        public decimal T9CASH { get; set; }
        public decimal T9CASE { get; set; }

        public string rankCode
        {
            get
            {
                return T9CODE?.Trim();
            }
        }
        public string description
        {
            get
            {
                return T9DESC?.Trim();
            }
        }
        public string rankUsePercentage
        {
            get
            {
                return T9PERC?.Trim();
            }
        }
        public decimal rankBalance
        {
            get
            {
                return T9BALA;
            }
        }
        public decimal rankCash
        {
            get
            {
                return T9CASH;
            }
        }
        public decimal rankCase
        {
            get
            {
                return T9CASE;
            }
        }
    }
    public class RequestSaveRankingModel
    {
        public string rankCode { get; set; }
        public string description { get; set; }
        public string rankUsePercentage { get; set; }
        public decimal rankBalance { get; set; }
        public decimal rankCash { get; set; }
        public decimal rankCase { get; set; }
        public string username { get; set; }
        public object dataDetail { get; set; }
    }
    public class ResultGetListRankingDetailModel
    {
        public string T1CODE { get; set; }
        public string T1BIZ { get; set; }
        public string T1DUE { get; set; }
        public string T1ODST { get; set; }
        public string T1ODT { get; set; }
        public string T1DEL { get; set; }
        public decimal T1UDAT { get; set; }
        public decimal T1UTIM { get; set; }
        public string T1UUSR { get; set; }
        public string T1UPGM { get; set; }
        public string T1UJOB { get; set; }
    }
}
