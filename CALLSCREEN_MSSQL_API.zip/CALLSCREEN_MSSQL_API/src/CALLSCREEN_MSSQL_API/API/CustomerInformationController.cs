﻿using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Services;
using Microsoft.AspNetCore.Mvc;

namespace CALLSCREEN_MSSQL_API.API
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerInformationController : ControllerBase
    {
        protected readonly CustomerInformationService _customerInfoSV;
        public CustomerInformationController(CustomerInformationService customerInfoSV) => _customerInfoSV = customerInfoSV;

        [HttpGet("GetDataESTM/{idNumber}", Name = "GetDataESTM")]
        public async Task<IActionResult> GetDataESTM(string idNumber)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _customerInfoSV.GetDataESTM(idNumber);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpGet("GetDataRCLCode/{idNumber}", Name = "GetDataRCLCode")]
        public async Task<IActionResult> GetDataRCLCode(string idNumber)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _customerInfoSV.GetDataRCLCode(idNumber);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpGet("GetDataMobileApplication/{idNumber}", Name = "GetDataMobileApplication")]
        public async Task<IActionResult> GetDataMobileApplication(string idNumber)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _customerInfoSV.GetDataMobileApplication(idNumber);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpGet("GetDataMobileApplication/{branach}/{app}/{vendorCode}/{operationType}", Name = "GetDataConditionIncome")]
        public async Task<IActionResult> GetDataConditionIncome(string branach, string app, string vendorCode, string operationType)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _customerInfoSV.GetDataConditionIncome(branach,app, vendorCode,operationType);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
        
        [HttpGet("GetCustomerNoByCSN/{CISNumber}", Name = "GetCustomerNoByCSN")]
        public async Task<IActionResult> GetCustomerNoByCSN(string CISNumber)

        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _customerInfoSV.GetCustomerNoByCSN(CISNumber);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
    }
}