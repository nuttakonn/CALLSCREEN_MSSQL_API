﻿using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace CALLSCREEN_MSSQL_API.API
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class AddNoteController : ControllerBase
    {
        protected readonly IAddNoteService _addNoteSV;
        public AddNoteController(IAddNoteService addNoteSV) => _addNoteSV = addNoteSV;

        [HttpGet("GetSMSMain")]
        public async Task<IActionResult> GetLGCustomer()  //Old Name: Call_CSGC040
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _addNoteSV.GetSMSMain();
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
    }
}
