﻿using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Services;
using Microsoft.AspNetCore.Mvc;

namespace CALLSCREEN_MSSQL_API.API
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class LegalController : ControllerBase
    {
        protected readonly LegalService _legalSV;
        public LegalController(LegalService legalSV) => _legalSV = legalSV;

        [HttpPost("GetLGCustomer")]
        public async Task<IActionResult> GetLGCustomer(InputLGCustomerModel input)  //Old Name: Call_CSGC040
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _legalSV.GetLGCustomer(input);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpPost("GetLGReceiveDetail")]
        public async Task<IActionResult> GetLGReceiveDetail(InputLGReceiveModel input)  //Old Name: Call_CSGC041
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _legalSV.GetLGReceiveDetail(input);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpGet("GetLGTemplateDetail/{templateID}")]
        public async Task<IActionResult> GetLGTemplateDetail(string templateID)  //Old Name: Call_CSGC042
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _legalSV.GetLGTemplateDetail(templateID);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpGet("GetLGRateDetail/{contractNo}")]
        public async Task<IActionResult> GetLGRateDetail(string contractNo)  //Old Name: Call_CSGC043
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _legalSV.GetLGRateDetail(contractNo);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpGet("GetLGExpenseDetail/{contractNo}")]
        public async Task<IActionResult> GetLGExpenseDetail(string contractNo)  //Old Name: Call_CSGC044
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _legalSV.GetLGExpenseDetail(contractNo);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpGet("GetLGInstallment/{contractNo}")]
        public async Task<IActionResult> GetLGInstallment(string contractNo)  //Old Name: Call_CSGC045
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _legalSV.GetLGInstallment(contractNo);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpGet("GetLGReceiveDeduct/{contractNo}")]
        public async Task<IActionResult> GetLGReceiveDeduct(string contractNo)  //Old Name: Call_CSGC046
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _legalSV.GetLGReceiveDeduct(contractNo);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpPost("GetLGClosing")]
        public async Task<IActionResult> GetLGClosing(InputLGClosingModel input)  //Old Name: Call_CSGC047
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _legalSV.GetLGClosing(input);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpGet("GetLGSkipDue/{contractNo}")]
        public async Task<IActionResult> GetLGSkipDue(string contractNo)  //Old Name: Call_CSGC048
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _legalSV.GetLGSkipDue(contractNo);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
    }
}
