﻿using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Models.Calculate;
using CALLSCREEN_MSSQL_API.Services;
using Microsoft.AspNetCore.Mvc;

namespace CALLSCREEN_MSSQL_API.API
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class CalculateController : ControllerBase
    {
        protected readonly CalculateService _calculateSV;
        public CalculateController(CalculateService calculateSV) => _calculateSV = calculateSV;

        [HttpPost("CalculateClosingIL", Name = "CalculateClosingIL")]
        public async Task<IActionResult> CalculateClosingIL(CalculateModel input)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _calculateSV.CalculateClosingIL(input);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
    }
}
