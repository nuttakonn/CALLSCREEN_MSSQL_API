﻿using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Services;
using Microsoft.AspNetCore.Mvc;

namespace CALLSCREEN_MSSQL_API.API
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class ChangeTelephoneController : ControllerBase
    {
        protected readonly ChangeTelephoneService _chgTelSV;
        public ChangeTelephoneController(ChangeTelephoneService chgTelSV) => _chgTelSV = chgTelSV;

        [HttpGet("GetDataRelation")]
        public async Task<IActionResult> GetDataRelation()
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _chgTelSV.GetDataRelation();
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
        [HttpPost("GetCustomerContractPhoneNumber")]
        public async Task<IActionResult> GetCustomerContractPhoneNumber(RequestChangeTelModel input)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _chgTelSV.GetCustomerContractPhoneNumber(input);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
    }
}
