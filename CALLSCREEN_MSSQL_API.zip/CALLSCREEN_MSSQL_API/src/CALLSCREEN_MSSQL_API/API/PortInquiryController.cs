﻿using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Services;
using Microsoft.AspNetCore.Mvc;

namespace CALLSCREEN_MSSQL_API.API
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class PortInquiryController : ControllerBase
    {
        protected readonly PortInquiryService _PortSV;
        public PortInquiryController(PortInquiryService PortSV) => _PortSV = PortSV;

        [HttpPost("GetDataPortInquiry")]
        public async Task<IActionResult> GetDataPortInquiry(GetDataPortInquiry input)  //Old Name: Call_CSGC040
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _PortSV.GetDataPortInquiry(input);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
    }
}
