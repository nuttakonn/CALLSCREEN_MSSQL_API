﻿using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Services;
using Microsoft.AspNetCore.Mvc;

namespace CALLSCREEN_MSSQL_API.API
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class HomePageController : ControllerBase
    {
        protected readonly HomeService _homeSV;
        public HomePageController(HomeService homeSV) => _homeSV = homeSV;

        [HttpGet("GetCurrentDate", Name = "GetCurrentDate")]
        public async Task<IActionResult> GetCurrentDate()
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _homeSV.GetCurrentDate();
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpGet("CheckCallIn/{username}/{deptCode}")]
        public async Task<IActionResult> CheckCallIn(string username, string deptCode)  //Old Name: Call_CSGC190
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _homeSV.CheckCallIn(username, deptCode);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpGet("GetHomeParameter/{username}")]
        public async Task<IActionResult> GetHomeParameter(string username)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _homeSV.GetHomeParameter(username);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
    }
}
