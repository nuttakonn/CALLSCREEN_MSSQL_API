﻿using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Services;
using Microsoft.AspNetCore.Mvc;

namespace CALLSCREEN_MSSQL_API.API
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class ContractController : ControllerBase
    {
        protected readonly ContractService _contractSV;
        public ContractController(ContractService contractSV) => _contractSV = contractSV;

        [HttpGet("GetDataCallRemindRM/{idNo}", Name = "GetDataCallRemindRM")]
        public async Task<IActionResult> GetDataCallRemindRM(string idNo)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _contractSV.GetDataCallRemindRM(idNo);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpGet("GetListCallFree", Name = "GetListCallFree")]
        public async Task<IActionResult> GetListCallFree()
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _contractSV.GetListCallFree();
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpPost("GetLoanTypeIL", Name = "GetLoanTypeIL")]
        public async Task<IActionResult> GetLoanTypeIL(GetLoanTypeILModel input)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _contractSV.GetLoanTypeIL(input);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
        [HttpPost("GetContractLeader/{collector}", Name = "GetExtNo")]
        public async Task<IActionResult> GetContractLeader(string collector)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _contractSV.GetContractLeader(collector);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpPost("GetPrincipleBalanceWO/{idno}", Name = "GetPrincipleBalanceWO")]
        public async Task<IActionResult> GetPrincipleBalanceWO(string idno)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _contractSV.GetPrincipleBalanceWO(idno);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpGet("GetSpecialNote/{idNo}", Name = "GetSpecialNote")]
        public async Task<IActionResult> GetSpecialNote(string idNo)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _contractSV.GetSpecialNote(idNo);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpGet("CheckstatusWriteoffSell/{contractNo}", Name = "CheckstatusWriteoffSell")]
        public async Task<IActionResult> CheckstatusWriteoffSell(string contractNo)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _contractSV.CheckstatusWriteoffSell(contractNo);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpPost("GetTotalWOAmtByBusiness", Name = "GetTotalWOAmtByBusiness")]
        public async Task<IActionResult> GetTotalWOAmtByBusiness(GetTotalWOAmtModel input)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _contractSV.GetTotalWOAmtByBusiness(input);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
    }
}
