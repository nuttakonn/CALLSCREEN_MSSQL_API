﻿using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Models.SystemCode;
using CALLSCREEN_MSSQL_API.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace CALLSCREEN_MSSQL_API.API
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class SystemCodeController : ControllerBase
    {
        protected readonly ISystemCodeService _sysSV;
        public SystemCodeController(ISystemCodeService systemSV) => _sysSV = systemSV;

        #region Appoint Period
        [HttpPost("AppointPeriod/Get", Name = "AppointPeriod/Get")]
        public async Task<IActionResult> GetAppointPeriod(RequestAppointPeriodModel input)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.GetAppointPeriod(input);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpPost("AppointPeriod/Add", Name = "AppointPeriod/Add")]
        public async Task<IActionResult> AddAppointPeriod(InputAppointPeriodForCRUD reqData)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.AddAppointPeriod(reqData);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpPost("AppointPeriod/Update", Name = "AppointPeriod/Update")]
        public async Task<ResponseModel> UpdateAppointPeriod(InputAppointPeriodForCRUD input)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                response = await _sysSV.UpdateAppointPeriod(input);
                return response;
            }
            catch (Exception ex)
            {
                response.message = $"{ex.Message} - {ex.InnerException}";
                return response;
            }
        }

        [HttpPost("AppointPeriod/Delete", Name = "AppointPeriod/Delete")]
        public async Task<ResponseModel> DeleteAppointPeriod(InputAppointPeriodForCRUD input)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                response = await _sysSV.DeleteAppointPeriod(input);
                return response;
            }
            catch (Exception ex)
            {
                response.message = $"{ex.Message} - {ex.InnerException}";
                return response;
            }
        }
        #endregion

        #region Campaign NewStaff
        [HttpPost("Campaign/GetDataCampaign", Name = "Campaign/GetDataCampaign")]
        public async Task<IActionResult> GetDataCampaign(RequestGetListCampaignModel input)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.GetDataCampaign(input);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpPost("CampaignNewStaff/AddCampaignNewStaff", Name = "CampaignNewStaff/AddCampaignNewStaff")]
        public async Task<ResponseModel> AddCampaignNewStaff(InputCampaignNewStaffForCRUD input)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                response = await _sysSV.AddCampaignNewStaff(input);
                return response;
            }
            catch (Exception ex)
            {
                response.message = $"{ex.Message} - {ex.InnerException}";
                return response;
            }
        }

        [HttpPost("CampaignNewStaff/EditCampaignNewStaff", Name = "CampaignNewStaff/EditCampaignNewStaff")]
        public async Task<ResponseModel> EditCampaignNewStaff(InputCampaignNewStaffForCRUD input)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                response = await _sysSV.EditCampaignNewStaff(input);
                return response;
            }
            catch (Exception ex)
            {
                response.message = $"{ex.Message} - {ex.InnerException}";
                return response;
            }
        }

        [HttpPost("CampaignNewStaff/DeleteCampaignNewStaff", Name = "CampaignNewStaff/DeleteCampaignNewStaff")]
        public async Task<ResponseModel> DeleteCampaignNewStaff(InputCampaignNewStaffForCRUD input)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                response = await _sysSV.DeleteCampaignNewStaff(input);
                return response;
            }
            catch (Exception ex)
            {
                response.message = $"{ex.Message} - {ex.InnerException}";
                return response;
            }
        }
        #endregion

        #region Customer Group
        [HttpPost("CustomerGroup/GetListCustomerGroup", Name = "CustomerGroup/GetListCustomerGroup")]
        public async Task<IActionResult> GetListCustomerGroup(RequestGetDataCustomerGroupModel input)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.GetListCustomerGroup(input);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpPost("CustomerGroup/GetCustomerGroup", Name = "CustomerGroup/GetCustomerGroup")]
        public async Task<IActionResult> GetCustomerGroup(RequestGetDataCustomerGroupModel input)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.GetCustomerGroup(input);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpPost("CustomerGroup/CreateCustomerGroupData", Name = "CustomerGroup/CreateCustomerGroupData")]
        public async Task<ResponseModel> CreateCustomerGroupData(RequestSaveCustomerGroupModel input)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                response = await _sysSV.CreateCustomerGroupData(input);
                return response;
            }
            catch (Exception ex)
            {
                response.message = $"{ex.Message} - {ex.InnerException}";
                return response;
            }
        }

        [HttpPost("CustomerGroup/UpdateCustomerGroupData", Name = "CustomerGroup/UpdateCustomerGroupData")]
        public async Task<ResponseModel> UpdateCustomerGroupData(RequestSaveCustomerGroupModel input)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                response = await _sysSV.UpdateCustomerGroupData(input);
                return response;
            }
            catch (Exception ex)
            {
                response.message = $"{ex.Message} - {ex.InnerException}";
                return response;
            }
        }

        [HttpPost("CustomerGroup/DeleteCustomerGroupData", Name = "CustomerGroup/DeleteCustomerGroupData")]
        public async Task<ResponseModel> DeleteCustomerGroupData(RequestSaveCustomerGroupModel input)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                response = await _sysSV.DeleteCustomerGroupData(input);
                return response;
            }
            catch (Exception ex)
            {
                response.message = $"{ex.Message} - {ex.InnerException}";
                return response;
            }
        }
        #endregion

        #region Ranking Code
        [HttpPost("Ranking/GetDataRanking", Name = "Ranking/GetDataRanking")]
        public async Task<IActionResult> GetDataRankingCode(RequestDataRankingModel input)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.GetDataRankingCode(input);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpPost("Ranking/GetNewRankCode", Name = "Ranking/GetNewRankCode")]
        public async Task<IActionResult> GetNewRankingCode()
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.GetNewRankingCode();
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpPost("Ranking/Find_RabkHead", Name = "Ranking/Find_RabkHead")]
        public async Task<IActionResult> Find_RankHead(RequestSaveRankingModel input)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.Find_RankHead(input);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpPost("Ranking/Find_RankDetail", Name = "Ranking/Find_RankDetail")]
        public async Task<IActionResult> Find_RankDetail(RequestSaveRankingModel input)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.Find_RankDetail(input);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpPost("Ranking/Save_Rank", Name = "Ranking/Save_Rank")]
        public async Task<ResponseModel> CreateRankingCode(RequestSaveRankingModel input)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                response = await _sysSV.CreateRankingCode(input);
                return response;
            }
            catch (Exception ex)
            {
                response.message = $"{ex.Message} - {ex.InnerException}";
                return response;
            }
        }

        [HttpPost("Ranking/CreateDetail_Rank", Name = "Ranking/CreateDetail_Rank")]
        public async Task<ResponseModel> UpdateRankingCode(ResultGetListRankingDetailModel input)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                response = await _sysSV.UpdateRankingCode(input);
                return response;
            }
            catch (Exception ex)
            {
                response.message = $"{ex.Message} - {ex.InnerException}";
                return response;
            }
        }

        [HttpPost("Ranking/Delete_Rank", Name = "Ranking/Delete_Rank")]
        public async Task<ResponseModel> DeleteRankingCode(RequestSaveRankingModel input)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                response = await _sysSV.DeleteRankingCode(input);
                return response;
            }
            catch (Exception ex)
            {
                response.message = $"{ex.Message} - {ex.InnerException}";
                return response;
            }
        }
        #endregion

        #region Section User
        [HttpPost("SectionUser/GetListSectionUser", Name = "SectionUser/GetListSectionUser")]
        public async Task<IActionResult> GetListSectionUser(RequestSectionUserModel input)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                response = await _sysSV.GetListSectionUser(input);
                return await Task.FromResult(Ok(response));
            }
            catch (Exception ex)
            {
                response.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(response));
            }
        }

        [HttpPost("SectionUser/GetSectionUser", Name = "SectionUser/GetSectionUser")]
        public async Task<IActionResult> GetSectionUser(RequestSectionUserModel input)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.GetSectionUser(input);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpPost("SectionUser/CreateSectionUserData", Name = "SectionUser/CreateSectionUserData")]
        public async Task<ResponseModel> CreateSectionUserData(RequestSaveSectionUserModel input)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                response = await _sysSV.CreateSectionUserData(input);
                return response;
            }
            catch (Exception ex)
            {
                response.message = $"{ex.Message} - {ex.InnerException}";
                return response;
            }
        }

        [HttpPost("SectionUser/UpdateSectionUserData", Name = "SectionUser/UpdateSectionUserData")]
        public async Task<ResponseModel> UpdateSectionUserData(RequestSaveSectionUserModel input)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                response = await _sysSV.UpdateSectionUserData(input);
                return response;
            }
            catch (Exception ex)
            {
                response.message = $"{ex.Message} - {ex.InnerException}";
                return response;
            }
        }

        [HttpPost("SectionUser/DeleteSectionUserData", Name = "SectionUser/DeleteSectionUserData")]
        public async Task<ResponseModel> DeleteSectionUserData(RequestSaveSectionUserModel input)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                response = await _sysSV.DeleteSectionUserData(input);
                return response;
            }
            catch (Exception ex)
            {
                response.message = $"{ex.Message} - {ex.InnerException}";
                return response;
            }
        }
        #endregion

        #region Type and Result

        [HttpPost("TypeAndResult/GetListTypeAndResultByTypeCodeResultCode", Name = "TypeAndResult/GetListTypeAndResultByTypeCodeResultCode")]
        public async Task<IActionResult> GetListTypeAndResultByTypeCodeResultCode(RequestGetDataTypeAndResultModel input)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.GetListTypeAndResultByTypeCodeResultCode(input);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpPost("TypeAndResult/GetListTypeCodeByTypeCode", Name = "TypeAndResult/GetListTypeCodeByTypeCode")]
        public async Task<IActionResult> GetListTypeCodeByTypeCode(RequestGetDataTypeAndResultModel input)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.GetListTypeCodeByTypeCode(input);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpPost("TypeAndResult/GetListResultCodeByTypeCode", Name = "TypeAndResult/GetListResultCodeByTypeCode")]
        public async Task<IActionResult> GetListResultCodeByTypeCode(RequestGetDataTypeAndResultModel input)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.GetListResultCodeByTypeCode(input);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpPost("TypeAndResult/GetTypeAndResultByTypeCodeResultCode", Name = "TypeAndResult/GetTypeAndResultByTypeCodeResultCode")]
        public async Task<IActionResult> GetTypeAndResultByTypeCodeResultCode(RequestGetDataTypeAndResultModel input)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.GetTypeAndResultByTypeCodeResultCode(input);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpPost("TypeAndResult/CreateTypeAndResultData", Name = "TypeAndResult/CreateTypeAndResultData")]
        public async Task<ResponseModel> CreateTypeAndResultData(RequestSaveTypeAndResultModel input)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.CreateTypeAndResultData(input);
                return returnResponse;
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return returnResponse;
            }
        }

        [HttpPost("TypeAndResult/UpdateTypeAndResultData", Name = "TypeAndResult/UpdateTypeAndResultData")]
        public async Task<ResponseModel> UpdateTypeAndResultData(RequestSaveTypeAndResultModel input)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.UpdateTypeAndResultData(input);
                return returnResponse;
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return returnResponse;
            }
        }

        [HttpPost("TypeAndResult/DeleteTypeAndResultData", Name = "TypeAndResult/DeleteTypeAndResultData")]
        public async Task<ResponseModel> DeleteTypeAndResultData(RequestSaveTypeAndResultModel input)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.DeleteTypeAndResultData(input);
                return returnResponse;
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return returnResponse;
            }
        }
        #endregion Type and Result

        #region Working Date
        [HttpPost("WorkingDate/Get", Name = "WorkingDate/Get")]
        public async Task<IActionResult> GetWorkingDate(RequestWorkingDateModel input)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                response = await _sysSV.GetWorkingDate(input);
                return await Task.FromResult(Ok(response));
            }
            catch (Exception ex)
            {
                response.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(response));
            }
        }

        [HttpPost("WorkingDate/Add", Name = "WorkingDate/Add")]
        public async Task<ResponseModel> AddWorkingDate(RequestWorkingDateModel input)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                response = await _sysSV.AddWorkingDate(input);
                return response;
            }
            catch (Exception ex)
            {
                response.message = $"{ex.Message} - {ex.InnerException}";
                return response;
            }
        }
        [HttpPost("WorkingDate/Update", Name = "WorkingDate/Update")]
        public async Task<ResponseModel> UpdateWorkingDate(RequestWorkingDateModel input)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                response = await _sysSV.UpdateWorkingDate(input);
                return response;
            }
            catch (Exception ex)
            {
                response.message = $"{ex.Message} - {ex.InnerException}";
                return response;
            }
        }
        [HttpPost("WorkingDate/Delete", Name = "WorkingDate/Delete")]
        public async Task<ResponseModel> DeleteWorkingDate(RequestWorkingDateModel input)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                response = await _sysSV.DeleteWorkingDate(input);
                return response;
            }
            catch (Exception ex)
            {
                response.message = $"{ex.Message} - {ex.InnerException}";
                return response;
            }
        }
        #endregion





        #region SMS Default Group
        [HttpPost("SMSDefault/GetDataSMSDefault")]
        public async Task<IActionResult> GetDataSMSDefault(InputSMSDefaultModel reqData)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.GetDataSMSDefault(reqData);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
        [HttpPost("SMSDefault/AddSMSDefault")]
        public async Task<IActionResult> AddSMSDefault(RequestSaveSMSDefaultModel reqData)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.AddSMSDefault(reqData);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
        [HttpPost("SMSDefault/UpdateSMSDefault")]
        public async Task<IActionResult> UpdateSMSDefault(RequestSaveSMSDefaultModel reqData)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.UpdateSMSDefault(reqData);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
        [HttpPost("SMSDefault/DeleteSMSDefault")]
        public async Task<IActionResult> DeleteSMSDefault(RequestSaveSMSDefaultModel reqData)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.DeleteSMSDefault(reqData);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
        #endregion SMS Default Group


        #region SMS Group
        [HttpPost("SMSGroup/GetDataSMSGroup")]
        public async Task<IActionResult> GetDataSMSGroup(InputSMSGroupCodeModel reqData)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.GetDataSMSGroup(reqData);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
        [HttpPost("SMSGroup/AddSMSGroup")]
        public async Task<IActionResult> AddSMSGroup(InputSMSGroupModel reqData)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.AddSMSGroup(reqData);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
        [HttpPost("SMSGroup/UpdateSMSGroup")]
        public async Task<IActionResult> UpdateSMSGroup(InputSMSGroupModel reqData)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.UpdateSMSGroup(reqData);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
        [HttpPost("SMSGroup/DeleteSMSGroup")]
        public async Task<IActionResult> DeleteSMSGroup(InputSMSGroupModel reqData)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.DeleteSMSGroup(reqData);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
        #endregion SMS Group


        #region SMS Keyword
        [HttpPost("SMSKeyword/GetDataSMSKeyword")]
        public async Task<IActionResult> GetDataSMSKeyword(InputSMSKeywordCodeModel reqData)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.GetDataSMSKeyword(reqData);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
        [HttpPost("SMSKeyword/AddSMSKeyword")]
        public async Task<IActionResult> AddSMSKeyword(InputSMSKeywordForInsert reqData)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.AddSMSKeyword(reqData);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
        [HttpPost("SMSKeyword/UpdateSMSKeyword")]
        public async Task<IActionResult> UpdateSMSKeyword(InputSMSKeywordForUpdate reqData)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.UpdateSMSKeyword(reqData);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
        [HttpPost("SMSKeyword/DeleteSMSKeyword")]
        public async Task<IActionResult> DeleteSMSKeyword(InputSMSKeywordForDelete reqData)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.DeleteSMSKeyword(reqData);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
        #endregion SMS Keyword


        #region SMS Subject
        [HttpPost("SMSSubject/GetDataSMSSubject")]
        public async Task<IActionResult> GetDataSMSSubject(InputSMSSubjectModel reqData)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.GetDataSMSSubject(reqData);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
        [HttpPost("SMSSubject/AddSMSSubject")]
        public async Task<IActionResult> AddSMSSubject(InputSMSSubjectCodeModel reqData)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.AddSMSSubject(reqData);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
        [HttpPost("SMSSubject/UpdateSMSSubject")]
        public async Task<IActionResult> UpdateSMSSubject(InputSMSSubjectCodeModel reqData)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.UpdateSMSSubject(reqData);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
        [HttpPost("SMSSubject/DeleteSMSSubject")]
        public async Task<IActionResult> DeleteSMSSubject(InputSMSSubjectCodeModel reqData)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.DeleteSMSSubject(reqData);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
        #endregion SMS Subject


        #region SMS Template
        [HttpPost("SMSTemplate/GetDataSMSTemplate")]
        public async Task<IActionResult> GetDataSMSTemplate(InputSMSTemplateModel reqData)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.GetDataSMSTemplate(reqData);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
        [HttpPost("SMSTemplate/AddSMSTemplate")]
        public async Task<IActionResult> AddSMSTemplate(RequestSaveSMSTemplate reqData)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.AddSMSTemplate(reqData);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
        [HttpPost("SMSTemplate/UpdateSMSTemplate")]
        public async Task<IActionResult> UpdateSMSTemplate(RequestSaveSMSTemplate reqData)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.UpdateSMSTemplate(reqData);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
        [HttpPost("SMSTemplate/DeleteSMSTemplate")]
        public async Task<IActionResult> DeleteSMSTemplate(RequestSaveSMSTemplate reqData)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.DeleteSMSTemplate(reqData);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
        [HttpGet("SMSTemplate/GetDDLSMSTemplatebyType/{type}")]
        public async Task<IActionResult> GetDDLSMSTemplatebyType(string type)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.GetDDLSMSTemplatebyType(type);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
        [HttpGet("SMSTemplate/GetDDlSMSGroupbyStatus/{type}")]
        public async Task<IActionResult> GetDDlSMSGroupbyStatus(string type)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.GetDDlSMSGroupbyStatus(type);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
        [HttpGet("SMSTemplate/GetDDlSMSSubjectbyStatus/{type}")]
        public async Task<IActionResult> GetDDlSMSSubjectbyStatus(string type)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.GetDDlSMSSubjectbyStatus(type);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
        [HttpPost("SMSTemplate/GetSMSTemplateBindDDL")]
        public async Task<IActionResult> GetSMSTemplateBindDDL(InputSMSTemplateDDLModel reqData)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sysSV.GetSMSTemplateBindDDL(reqData);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
        #endregion SMS Template
    }
}
