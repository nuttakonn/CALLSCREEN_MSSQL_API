﻿using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Models.Negotiate;
using CALLSCREEN_MSSQL_API.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace CALLSCREEN_MSSQL_API.API
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class NegotiateController : ControllerBase
    {
        private readonly INegotiateService _negotiateService;
        public NegotiateController(INegotiateService negotiateService)
        {
            _negotiateService = negotiateService;
        }

        [HttpPost("GetReceiveNegotiate")]
        public async Task<IActionResult> GetReceiveNegotiate(RequestNegotiateModel request)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _negotiateService.GetReceiveNegotiate(request);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
    }
}
