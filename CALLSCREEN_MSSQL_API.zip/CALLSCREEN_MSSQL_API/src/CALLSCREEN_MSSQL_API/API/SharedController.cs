﻿using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace CALLSCREEN_MSSQL_API.API
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class SharedController : ControllerBase
    {
        protected readonly ISharedService _sharedSV;
        public SharedController(ISharedService sharedSV) => _sharedSV = sharedSV;

        [HttpGet("ExecuteQuery", Name = "ExecuteQuery")]
        public async Task<IActionResult> ExecuteQuery(string query)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sharedSV.ExecuteQuery(query);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpGet("GetCustomerIDBizByContractNo/{contractNo}", Name = "GetCustomerIDBizByContractNo")]
        public async Task<IActionResult> GetCustomerIDBizByContractNo(string contractNo)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sharedSV.GetCustomerIDBizByContractNo(contractNo);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpPost("Call_GNCHKNOR", Name = "Call_GNCHKNOR")]
        public async Task<IActionResult> Call_GNCHKNOR(InputGNCHKNORModel input)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sharedSV.Call_GNCHKNOR(input);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpPost("Call_CSGC013")]
        [HttpPost("GetTelephoneInfoList")]
        public async Task<IActionResult> GetTelephoneInfoList(InputTelephoneInfoModel input)  //Old Name: Call_CSGC013
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sharedSV.GetTelephoneInfoList(input);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpPost("Call_CSGC209")]
        [HttpPost("GetBusinessList")]
        public async Task<IActionResult> GetBusinessList(InputBusinessModel input)  //Old Name: Call_CSGC209
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sharedSV.GetBusinessList(input);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }

        [HttpGet("Call_CSGC020/{idNumber}", Name = "Call_CSGC020")]
        public async Task<IActionResult> Call_CSGC020(string idNumber)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sharedSV.Call_CSGC020(idNumber);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
        [HttpGet("GetMapPortToUsername/{port}/{user}")]
        public async Task<IActionResult> GetMapPortToUsername(string port, string user)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sharedSV.GetMapPortToUsername(port, user);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
        [HttpGet("GetOfficerTeamMemberForLG/{port}/{user}")]
        public async Task<IActionResult> GetOfficerTeamMemberForLG(string port, string user)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sharedSV.GetOfficerTeamMemberForLG(port, user);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
        [HttpPost("InsertLogDataTracking")]
        public async Task<IActionResult> InsertLogDataTracking(CSMSLGModel input) 
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _sharedSV.InsertLogDataTracking(input);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
    }
}
