﻿using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Services;
using Microsoft.AspNetCore.Mvc;

namespace CALLSCREEN_MSSQL_API.API
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class AutoDialController : ControllerBase
    {
        protected readonly AutoDialService _autoDialSV;
        public AutoDialController(AutoDialService autoDialSV) => _autoDialSV = autoDialSV;

        [HttpPost("IsAuthenticatedLDAP", Name = "IsAuthenticatedLDAP")]
        public async Task<IActionResult> IsAuthenticatedLDAP(LoginModel input)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _autoDialSV.IsAuthenticatedLDAP(input);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return await Task.FromResult(BadRequest(returnResponse));
            }
        }
    }
}
