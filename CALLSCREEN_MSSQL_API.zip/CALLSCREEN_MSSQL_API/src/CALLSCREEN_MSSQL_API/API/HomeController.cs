﻿using CALLSCREEN_MSSQL_API.Models;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.Reflection;

namespace CALLSCREEN_MSSQL_API.API
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            var assemblyAll = Assembly.GetEntryAssembly()?.GetName();
            IndexModel model = new IndexModel();
            model.IP = GetIPAddress();
            model.AssemblyName = assemblyAll?.Name;
            model.AssemblyVersion = assemblyAll?.Version?.ToString();
            model.AspNetCoreEnvironment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
            model.DateModified = AppSetting.DateModified;
            return View(model);
        }

        private string GetIPAddress()
        {
            try
            {
                return Dns.GetHostEntry(Dns.GetHostName()).HostName;
            }
            catch
            {
                return "";
            }
        }
    }
}