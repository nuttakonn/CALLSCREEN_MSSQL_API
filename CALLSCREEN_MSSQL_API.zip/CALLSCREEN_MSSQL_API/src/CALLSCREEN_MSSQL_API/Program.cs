using CALLSCREEN_MSSQL_API.Common.Extensions;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Mvc.ApplicationModels;
using Microsoft.AspNetCore.Mvc.Authorization;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using StackExchange.Redis;
using System.Reflection;
using System.Text;

var aspnetcoreENV = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
if (string.IsNullOrEmpty(aspnetcoreENV)) throw new ArgumentException("Not found ASPNETCORE_ENVIRONMENT Variable");
var builder = WebApplication.CreateBuilder(args);
builder.WebHost.UseUrls("http://*:5001");
AppSetting.Configuration = builder.Configuration;

// Add services to the container.
builder.Services.AddControllers();
builder.Services.AddControllersWithViews();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddHttpContextAccessor();
builder.Services.AddAutoScope();
builder.Services.AddMvc(option => option.Conventions.Add(new JwtAuthorizationConvention("JwtPolicy", Convert.ToBoolean(builder.Configuration["Jwt:Authen"]), builder?.Configuration["Jwt:ActionIgnore"]?.Split(',')))).AddNewtonsoftJson();

//Authen 1
builder.Services.AddCors(options =>
{
    options.AddPolicy("CorsPolicy",
        builder => builder.AllowAnyOrigin()
          .AllowAnyMethod()
          .AllowAnyHeader()
    //.AllowCredentials()
    .Build());
});

//Authen 2
try
{
    var accessRedis = $"{builder.Configuration["Redis:Host"]}:{builder.Configuration["Redis:Port"]},Password={builder.Configuration["Redis:Password"]}";
    var _redis = ConnectionMultiplexer.Connect(accessRedis);
    builder.Services.AddSingleton<IConnectionMultiplexer>(_redis);
}
catch { /**/ }
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
 .AddJwtBearer(options =>
 {
     options.TokenValidationParameters = new TokenValidationParameters
     {
         ValidateIssuer = true,
         ValidateAudience = true,
         ValidateLifetime = true,
         ValidateIssuerSigningKey = true,
         ValidIssuer = builder.Configuration["Jwt:Issuer"],
         ValidAudience = builder.Configuration["Jwt:Issuer"],
         IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"]))
     };
 });
builder.Services.AddAuthorization(option =>
{
    option.AddPolicy("JwtPolicy", builder =>
    {
        builder.RequireAuthenticatedUser();
        builder.AddAuthenticationSchemes(JwtBearerDefaults.AuthenticationScheme);
    });
});
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = $"{AppSetting.AssemblyName} ({AppSetting.DateModified}) - {aspnetcoreENV}", Version = "v1" });
    c.AddSecurityDefinition("Login", new OpenApiSecurityScheme
    {
        Name = "AccessKey",
        Type = SecuritySchemeType.ApiKey,
        Scheme = "Login",
        BearerFormat = "JWT",
        In = ParameterLocation.Header,
        Description = $@"Standard Private-Authen header using the Login scheme. Example: ""[Username & Password Encryption]"" 
                        <br>Test Key (actor: ChangeCust, role: ADMIN) <br />
                        <br>Please copy text below and paste in value input. <br />
                        <textarea readonly style='height:150px;min-height:unset;'>
                            UDQyMDEwMDVfMDQtMDgtMjAyMi0wOToyODoxOQ==
                        </textarea>"
    });
    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Name = "Authorization",
        Type = SecuritySchemeType.ApiKey,
        Scheme = "Bearer",
        BearerFormat = "JWT",
        In = ParameterLocation.Header,
        Description = $@"Standard Authorization header using the Bearer scheme. Example: ""bearer [token]"" 
                        <br>Test Key (actor: Note, role: ADMIN) <br />
                        <br>Please copy text below and paste in value input. <br /> 
                        <textarea readonly style='height:150px;min-height:unset;'>
                            {aspnetcoreENV?.GetBearerSchem()}
                        </textarea>"
    });
    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "Login",
                }
            },
            new string[] {}
        }
    });
    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            new string[] {}
        }
    });
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsProduction())
{
    app.UseDeveloperExceptionPage();
    app.UseSwagger();
    app.UseSwaggerUI(c => c.SwaggerEndpoint("../swagger/v1/swagger.json", $"{AppSetting.AssemblyName} v1"));
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();
app.MapControllerRoute(name: "default", pattern: "{controller=Home}/{action=Index}/{id?}");
app.Run();

public static class AppSetting
{
    public static IConfiguration? Configuration { get; set; }
    public static string? AssemblyName { get; set; } = Assembly.GetExecutingAssembly().GetName().Name;
    public static string? SystemMessage(string? code) => Configuration?[$"SystemMessage:{code?.ToUpper()}"];
    public static string? DateModified { get; } = new FileInfo(Assembly.GetExecutingAssembly().Location).LastWriteTime.ToString("dd/MM/yyyy - HH:mm:ss", new System.Globalization.CultureInfo("en-EN", false));
}

public static class SetupServiceLifeTime
{
    public static void AddAutoScope(this IServiceCollection services)
    {
        List<Type> allType = new List<Type>();
        List<string> nsRange = new List<string> { $"{AppSetting.AssemblyName}.Services", $"{AppSetting.AssemblyName}.Common", $"{AppSetting.AssemblyName}.DataAccess" };
        nsRange.ForEach(n =>
        {
            List<Type> srvTyp = Assembly.GetExecutingAssembly().GetTypes()
                                    .Where(t => t.Namespace != null && t.Namespace.StartsWith(n))
                                    .Where(t => t.IsClass && !t.IsAbstract && t.IsPublic).ToList();

            allType.AddRange(srvTyp);
        });

        if (!allType.IsEmpty())
        {
            allType.ForEach(clss =>
            {
                var intrf = clss.GetInterfaces().FirstOrDefault();
                if (intrf != null)
                {
                    services.AddScoped(intrf, clss);
                }
                else
                {
                    services.AddScoped(clss);
                }
            });
        }
    }
}

public class JwtAuthorizationConvention : IApplicationModelConvention
{
    private readonly string[] _actionIgnore;
    private readonly string _policy;
    private readonly bool _auth;

    public JwtAuthorizationConvention(string policy, bool auth, string[] actionIgnore)
    {
        _policy = policy;
        _auth = auth;
        _actionIgnore = actionIgnore;
    }

    public void Apply(ApplicationModel application)
    {
        if (_auth)
        {
            application.Controllers.ToList().ForEach(controller =>
            {
                var isController = controller.Selectors.Any(x => x.AttributeRouteModel != null
                                                        && x.AttributeRouteModel.Template.ToLower().StartsWith("api"));
                if (isController)
                {
                    controller.Actions.ToList().ForEach(action =>
                    {
                        var myList = _actionIgnore.ConvertToModel<List<string>>().ConvertAll(x => x.ToLower());
                        var isActionAuthen = _actionIgnore == null || myList?.Contains(action.ActionName.ToLower()) == false;
                        if (isActionAuthen)
                        {
                            action.Filters.Add(new AuthorizeFilter(_policy));
                        }
                    });
                }
            });
        }
    }
}

public static class NswagExtensions
{
    public static string GetBearerSchem(this string env)
    {
        string token = "";
        try
        {
            if (env.ToLower() == "development")
            {
                token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA5LzA5L2lkZW50aXR5L2NsYWltcy9hY3RvciI6ImFkbWluIiwiaHR0cDovL3NjaGVtYXMubWljcm9zb2Z0LmNvbS93cy8yMDA4LzA2L2lkZW50aXR5L2NsYWltcy9yb2xlIjoidXNlciIsImh0dHA6Ly9zY2hlbWFzLnhtbHNvYXAub3JnL3dzLzIwMDUvMDUvaWRlbnRpdHkvY2xhaW1zL2hhc2giOiI4Y2ExZDM2ZS03MDMxLTQwZjYtOGQyNi0wY2U5Y2YzZGRiOWEiLCJleHAiOjE4MDgxMzQyMzgsIm5iZiI6MTcxMzUyNjIzOCwiaXNzIjoiY2FsbHNjcmVlbnN5c3RlbSIsImF1ZCI6ImNhbGxzY3JlZW5zeXN0ZW0ifQ.b3HY5ACMkzNgJ6HP3zow8fyzUxJC06sTXk1aqi7ggUw";
            }
            else if (env.ToLower() == "uat")
            {
                token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA5LzA5L2lkZW50aXR5L2NsYWltcy9hY3RvciI6ImFkbWluIiwiaHR0cDovL3NjaGVtYXMubWljcm9zb2Z0LmNvbS93cy8yMDA4LzA2L2lkZW50aXR5L2NsYWltcy9yb2xlIjoidXNlciIsImh0dHA6Ly9zY2hlbWFzLnhtbHNvYXAub3JnL3dzLzIwMDUvMDUvaWRlbnRpdHkvY2xhaW1zL2hhc2giOiI5OGVmYWIzZi0yMzQyLTRlMzMtOWU4NS05OGFkMTI3YTg5ZTciLCJleHAiOjE4MDgxMzQyODcsIm5iZiI6MTcxMzUyNjI4NywiaXNzIjoiY2FsbHNjcmVlbnN5c3RlbSIsImF1ZCI6ImNhbGxzY3JlZW5zeXN0ZW0ifQ.f0EgxWXBLl7aIBSEgW32MTsoOS4-grjlvpvRajhpkik";
            }
            else if (env.ToLower() == "production")
            {
                token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA5LzA5L2lkZW50aXR5L2NsYWltcy9hY3RvciI6ImFkbWluIiwiaHR0cDovL3NjaGVtYXMubWljcm9zb2Z0LmNvbS93cy8yMDA4LzA2L2lkZW50aXR5L2NsYWltcy9yb2xlIjoidXNlciIsImh0dHA6Ly9zY2hlbWFzLnhtbHNvYXAub3JnL3dzLzIwMDUvMDUvaWRlbnRpdHkvY2xhaW1zL2hhc2giOiIxOTU5YTAyYi0yMmJjLTRiY2UtYTk3Mi04YTgwMzc4MWI2YjYiLCJleHAiOjE4MDgxMzQyOTQsIm5iZiI6MTcxMzUyNjI5NCwiaXNzIjoiY2FsbHNjcmVlbnN5c3RlbSIsImF1ZCI6ImNhbGxzY3JlZW5zeXN0ZW0ifQ.oyXGmvmtERamQI-p-JM6x1JXaS7igSzZvnoMVwhYUuA";
            }

            return token = !string.IsNullOrWhiteSpace(token) ? $"Bearer {token}" : token;
        }
        catch
        {
            return token;
        }
    }
}