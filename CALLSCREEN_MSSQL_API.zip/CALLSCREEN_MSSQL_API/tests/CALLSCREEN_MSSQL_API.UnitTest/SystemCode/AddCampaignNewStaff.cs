﻿using CALLSCREEN_MSSQL_API.DataAccess.Interfaces;
using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Models.SystemCode;
using Microsoft.Extensions.Configuration;
using Moq;
using System;
using System.Globalization;
using System.Threading.Tasks;
using System.Xml;
using Xunit;

namespace CALLSCREEN_MSSQL_API.UnitTest.SystemCode
{
    public class AddCampaignNewStaff
    {
        protected readonly IConfiguration conf;
        protected readonly Mock<IDataCenter> mock;
        protected readonly SchemaDBModel schemaDB;

        private DateTime dateTime = DateTime.Now;
        private DateTimeFormatInfo m_DThai = new CultureInfo("th-TH", false).DateTimeFormat;

        public AddCampaignNewStaff()
        {
            string env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")?.ToString() ?? "Development";
            conf = new ConfigurationBuilder()
                    .AddJsonFile($"appsettings.{env}.json", optional: true, reloadOnChange: true)
                    .AddEnvironmentVariables().Build();
            mock = new Mock<IDataCenter>();
            mock.Setup(s => s.SchemaDB()).Returns(conf.GetSection("SchemaDB").Get<SchemaDBModel>());
            schemaDB = mock.Object.SchemaDB();
        }

        [Fact]
        //[Theory]
        //[InlineData("1111111111111")]
        public async Task AddCampaignNewStaff_Success()
        {
            InputCampaignNewStaffForCRUD request = new InputCampaignNewStaffForCRUD() { callUser = "",campaign = "",updateby = ""};

            mock.Setup(s => s.Get<ResultGetListCampaignModel>(It.IsAny<string>(), System.Data.CommandType.Text, null)).ReturnsAsync((true, "Success", new ResultGetListCampaignModel() { T2NUSR = null, T2CAMP = null }));
            mock.Setup(s => s.Get<ResultGetListCampaignModel>(It.IsAny<string>(), System.Data.CommandType.Text, null)).ReturnsAsync((true, "Success", new ResultGetListCampaignModel() { T2NUSR = null, T2CAMP = null }));
            mock.Setup(dc => dc.Execute(It.IsAny<string>(), System.Data.CommandType.Text, null))
            .ReturnsAsync((true, "Success"));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.AddCampaignNewStaff(request);
            Assert.True(result.success);
            Assert.Equal("Success", result.message);
        }

        [Fact]
        //[Theory]
        //[InlineData("0000000000000")]
        public async Task AddCampaignNewStaff_Fail_DataNotFound()
        {
            InputCampaignNewStaffForCRUD request = new InputCampaignNewStaffForCRUD();
            mock.Setup(s => s.Get<ResultGetListCampaignModel>(It.IsAny<string>(), System.Data.CommandType.Text, null)).ReturnsAsync((true, "Success", new ResultGetListCampaignModel() { T2NUSR = "", T2CAMP = null }));
            mock.Setup(s => s.Get<ResultGetListCampaignModel>(It.IsAny<string>(), System.Data.CommandType.Text, null)).ReturnsAsync((true, "Success", new ResultGetListCampaignModel() { T2NUSR = "", T2CAMP = null }));
            mock.Setup(s => s.Execute(It.IsAny<string>(), System.Data.CommandType.Text, null)).ReturnsAsync((false, "Data not found."));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.AddCampaignNewStaff(request);
            //Assert.True(!result.success);
            Assert.Contains(", this Code already exists.", result.message);
        }
    }
}
