﻿using CALLSCREEN_MSSQL_API.DataAccess.Interfaces;
using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Models.SystemCode;
using Microsoft.Extensions.Configuration;
using Moq;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Threading.Tasks;
using Xunit;

namespace CALLSCREEN_MSSQL_API.UnitTest.SystemCode
{
    public class GetWorkingDate
    {
        protected readonly IConfiguration conf;
        protected readonly Mock<IDataCenter> mock;
        protected readonly SchemaDBModel schemaDB;


        private DateTime dateTime = DateTime.Now;
        private DateTimeFormatInfo m_DThai = new CultureInfo("th-TH", false).DateTimeFormat;
        public GetWorkingDate()
        {
            string env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")?.ToString() ?? "Development";
            conf = new ConfigurationBuilder()
                    .AddJsonFile($"appsettings.{env}.json", optional: true, reloadOnChange: true)
                    .AddEnvironmentVariables().Build();
            mock = new Mock<IDataCenter>();
            mock.Setup(s => s.SchemaDB()).Returns(conf.GetSection("SchemaDB").Get<SchemaDBModel>());
            schemaDB = mock.Object.SchemaDB();
        }

        [Fact]
        //[Theory]
        //[InlineData("1111111111111")]
        public async Task GetWorkingDate_Success()
        {
            RequestWorkingDateModel request = new RequestWorkingDateModel() { workingDate = "00/00/0000" };

            string condition;
            string CurrentDate = dateTime.ToString("dd/MM/yyyy", m_DThai);
            if (request.workingDate == "00/00/0000")
            {
                condition = "";
            }
            else if (!string.IsNullOrEmpty(request.workingDate))
            {
                string date = (request.workingDate.Length == 10) ?
                    $"{request.workingDate.Substring(6, 4)}{request.workingDate.Substring(3, 2)}{request.workingDate.Substring(0, 2)}" : "";

                condition = $" AND T4HDAT = '{date}' ";
            }
            else
            {
                condition = $" AND T4HDAT >= {CurrentDate} ";
            }

            var strCommand = $@"SELECT
                                T4HDAT,
                                T4STIM,
                                T4ETIM
                             FROM
                                {schemaDB?.CS}.CSMCB04
                             WHERE 
                                T4DEL = '' 
                                {condition}
                             ORDER BY
                                T4HDAT";
            mock.Setup(s => s.Get<List<ResultWorkingDateModel>>(strCommand, System.Data.CommandType.Text, null)).ReturnsAsync((true, "Success", new List<ResultWorkingDateModel>()));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.GetWorkingDate(request);
            Assert.True(result.success);
            Assert.Equal("Success", result.message);
        }

        [Fact]
        //[Theory]
        //[InlineData("0000000000000")]
        public async Task GetWorkingDate_Fail_DataNotFound()
        {
            RequestWorkingDateModel request = new RequestWorkingDateModel() { workingDate = "00/00/0000" };

            mock.Setup(s => s.Get<List<ResultWorkingDateModel>>(It.IsAny<string>(), System.Data.CommandType.Text, null)).ReturnsAsync((false, "Data not found.", new List<ResultWorkingDateModel>()));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.GetWorkingDate(request);
            //Assert.True(!result.success);
            Assert.Contains("Data not found", result.message);
        }
    }
}
