﻿using CALLSCREEN_MSSQL_API.DataAccess.Interfaces;
using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Models.SystemCode;
using Microsoft.Extensions.Configuration;
using Moq;
using System;
using System.Collections.Generic;
using System.Net.NetworkInformation;
using System.Threading.Tasks;
using Xunit;

namespace CALLSCREEN_MSSQL_API.UnitTest.SystemCode
{
    public class GetDataRankingCode
    {
        protected readonly IConfiguration conf;
        protected readonly Mock<IDataCenter> mock;
        protected readonly SchemaDBModel schemaDB;
        public GetDataRankingCode()
        {
            string env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")?.ToString() ?? "Development";
            conf = new ConfigurationBuilder()
                    .AddJsonFile($"appsettings.{env}.json", optional: true, reloadOnChange: true)
                    .AddEnvironmentVariables().Build();
            mock = new Mock<IDataCenter>();
            mock.Setup(s => s.SchemaDB()).Returns(conf.GetSection("SchemaDB").Get<SchemaDBModel>());
            schemaDB = mock.Object.SchemaDB();
        }

        [Fact]
        //[Theory]
        //[InlineData("1111111111111")]
        public async Task GetDataRankingCode_Success()
        {
            RequestDataRankingModel request = new RequestDataRankingModel() { biz = "", due = "1", odStatus = "", odTerm = "2", rankCode = "" };

            mock.Setup(s => s.Get<List<ResultGetListRankingModel>>(It.IsAny<string>(), System.Data.CommandType.Text, null)).ReturnsAsync((true, "Success", new List<ResultGetListRankingModel>()));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.GetDataRankingCode(request);
            Assert.True(result.success);
            Assert.Equal("Success", result.message);
        }

        [Fact]
        //[Theory]
        //[InlineData("0000000000000")]
        public async Task GetDataRankingCode_Fail_DataNotFound()
        {
            RequestDataRankingModel request = new RequestDataRankingModel() { biz ="", due ="1", odStatus ="",odTerm ="2", rankCode =""};

            mock.Setup(s => s.Get<List<ResultGetListRankingModel>>(It.IsAny<string>(), System.Data.CommandType.Text, null)).ReturnsAsync((false, "Data not found.", null));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.GetDataRankingCode(request);
            //Assert.True(!result.success);
            Assert.Contains("Data not found", result.message);
        }
    }
}
