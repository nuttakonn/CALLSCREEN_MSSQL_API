﻿using CALLSCREEN_MSSQL_API.DataAccess.Interfaces;
using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Models.SystemCode;
using Microsoft.Extensions.Configuration;
using Moq;
using System;
using System.Globalization;
using System.Threading.Tasks;
using Xunit;

namespace CALLSCREEN_MSSQL_API.UnitTest.SystemCode
{
    public class CreateRankingCode
    {
        protected readonly IConfiguration conf;
        protected readonly Mock<IDataCenter> mock;
        protected readonly SchemaDBModel schemaDB;

        private DateTime dateTime = DateTime.Now;
        private DateTimeFormatInfo m_DThai = new CultureInfo("th-TH", false).DateTimeFormat;

        public CreateRankingCode()
        {
            string env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")?.ToString() ?? "Development";
            conf = new ConfigurationBuilder()
                    .AddJsonFile($"appsettings.{env}.json", optional: true, reloadOnChange: true)
                    .AddEnvironmentVariables().Build();
            mock = new Mock<IDataCenter>();
            mock.Setup(s => s.SchemaDB()).Returns(conf.GetSection("SchemaDB").Get<SchemaDBModel>());
            schemaDB = mock.Object.SchemaDB();
        }

        [Fact]
        //[Theory]
        //[InlineData("1111111111111")]
        public async Task CreateRankingCode_Success()
        {
            RequestSaveRankingModel request = new RequestSaveRankingModel() { description= "",rankUsePercentage = "",username = "", rankCode = "" };
            mock.Setup(s => s.Get<ResultGetListRankingModel>(It.IsAny<string>(), System.Data.CommandType.Text, null)).ReturnsAsync((true, "Success", new ResultGetListRankingModel() { T9BALA = 0 ,T9CASE = 0 ,T9CASH = 0 ,T9CODE = null ,T9DESC = null ,T9PERC = null }));
            mock.Setup(s => s.Get<ResultGetListRankingModel>(It.IsAny<string>(), System.Data.CommandType.Text, null)).ReturnsAsync((true, "Success", new ResultGetListRankingModel() { T9BALA = 0, T9CASE = 0, T9CASH = 0, T9CODE = null, T9DESC = null, T9PERC = null }));
            mock.Setup(dc => dc.Execute(It.IsAny<string>(), System.Data.CommandType.Text, null))
            .ReturnsAsync((true, "Success"));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.CreateRankingCode(request);
            Assert.True(result.success);
            Assert.Equal("Success", result.message);
        }

        [Fact]
        //[Theory]
        //[InlineData("0000000000000")]
        public async Task CreateRankingCode_Fail_DataNotFound()
        {
            RequestSaveRankingModel request = new RequestSaveRankingModel() { description = "", rankUsePercentage = "", username = "",rankCode = "" };
            mock.Setup(s => s.Get<ResultGetListRankingModel>(It.IsAny<string>(), System.Data.CommandType.Text, null)).ReturnsAsync((true, "Success", new ResultGetListRankingModel() { T9BALA = 1, T9CASE = 0, T9CASH = 0, T9CODE = null, T9DESC = null, T9PERC = null }));
            mock.Setup(s => s.Get<ResultGetListRankingModel>(It.IsAny<string>(), System.Data.CommandType.Text, null)).ReturnsAsync((true, "Success", new ResultGetListRankingModel() { T9BALA = 1, T9CASE = 0, T9CASH = 0, T9CODE = null, T9DESC = null, T9PERC = null }));
            mock.Setup(dc => dc.Execute(It.IsAny<string>(), System.Data.CommandType.Text, null))
            .ReturnsAsync((true, "Success"));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.CreateRankingCode(request);
            //Assert.True(!result.success);
            Assert.Contains("Success", result.message);
        }
    }
}
