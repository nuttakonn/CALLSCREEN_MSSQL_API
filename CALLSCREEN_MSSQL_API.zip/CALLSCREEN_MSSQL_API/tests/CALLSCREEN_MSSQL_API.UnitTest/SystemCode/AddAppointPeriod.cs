﻿using CALLSCREEN_MSSQL_API.DataAccess.Interfaces;
using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Models.SystemCode;
using Microsoft.Extensions.Configuration;
using Moq;
using Org.BouncyCastle.Ocsp;
using System;
using System.Globalization;
using System.Threading.Tasks;
using System.Xml;
using Xunit;

namespace CALLSCREEN_MSSQL_API.UnitTest.SystemCode
{
    public class AddAppointPeriod
    {
        protected readonly IConfiguration conf;
        protected readonly Mock<IDataCenter> mock;
        protected readonly SchemaDBModel schemaDB;

        private DateTime dateTime = DateTime.Now;
        private DateTimeFormatInfo m_DThai = new CultureInfo("th-TH", false).DateTimeFormat;

        public AddAppointPeriod()
        {
            string env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")?.ToString() ?? "Development";
            conf = new ConfigurationBuilder()
                    .AddJsonFile($"appsettings.{env}.json", optional: true, reloadOnChange: true)
                    .AddEnvironmentVariables().Build();
            mock = new Mock<IDataCenter>();
            mock.Setup(s => s.SchemaDB()).Returns(conf.GetSection("SchemaDB").Get<SchemaDBModel>());
            schemaDB = mock.Object.SchemaDB();
        }

        [Fact]
        //[Theory]
        //[InlineData("1111111111111")]
        public async Task AddAppointPeriod_Success()
        {
            InputAppointPeriodForCRUD request = new InputAppointPeriodForCRUD() { type = "ss" ,startTime = "000000",endTime = "000000"};
            
            var cmdText = $@"SELECT * FROM {schemaDB?.CS}.CSMCB05 WHERE T5TYPE = '{request.type?.Trim().ToUpper()}' AND T5DEL  = ''";
            mock.Setup(s => s.Get<ResultAppointPeriodModel>(cmdText, System.Data.CommandType.Text, null)).ReturnsAsync((true, "Success", new ResultAppointPeriodModel() {T5TYPE = null }));
            var cmdText2 = $@"SELECT * FROM {schemaDB?.CS}.CSMCB05 WHERE T5TYPE = '{request.type?.Trim().ToUpper()}' AND T5DEL  = 'X'";
            mock.Setup(s => s.Get<ResultAppointPeriodModel>(cmdText2, System.Data.CommandType.Text, null)).ReturnsAsync((true, "Success", new ResultAppointPeriodModel() { T5TYPE = null }));
            mock.Setup(dc => dc.Execute(It.IsAny<string>(), System.Data.CommandType.Text, null))
            .ReturnsAsync((true, ""));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.AddAppointPeriod(request);
            Assert.True(result.success);
            Assert.Equal("Insert Data Success, ", result.message);
        }

        [Fact]
        //[Theory]
        //[InlineData("0000000000000")]
        public async Task AddAppointPeriod_Fail_DataNotFound()
        {
            InputAppointPeriodForCRUD request = new InputAppointPeriodForCRUD() { type = "ss" };

            int updateDate;
            int updateTime;
            updateDate = (int.TryParse(dateTime.ToString("yyMMdd", m_DThai), out updateDate) == true ? updateDate : 0);
            updateTime = (int.TryParse(dateTime.ToString("HHmmss", m_DThai), out updateTime) == true ? updateTime : 0);
            var strCommand = $@"INSERT INTO {schemaDB?.CS}.CSMCB05 (T5TYPE,T5STIM,T5ETIM,T5UDAT,T5UTIM,T5UUSR,T5UPGM,T5UJOB,T5DEL)
                                            VALUES ({request.type?.Trim().ToUpper()},
                                                    {request.startTime},
                                                    {request.endTime},
                                                    {updateDate},
                                                    {updateTime},
                                                    {request.username},
                                                    '',
                                                    '',
                                                    '')";
            var cmdText = $@"SELECT * FROM {schemaDB?.CS}.CSMCB05 WHERE T5TYPE = '{request.type?.Trim().ToUpper()}' AND T5DEL  = ''";
            mock.Setup(s => s.Get<ResultAppointPeriodModel>(cmdText, System.Data.CommandType.Text, null)).ReturnsAsync((true, "Success", new ResultAppointPeriodModel() { T5TYPE = "" }));
            var cmdText2 = $@"SELECT * FROM {schemaDB?.CS}.CSMCB05 WHERE T5TYPE = '{request.type?.Trim().ToUpper()}' AND T5DEL  = 'X'";
            mock.Setup(s => s.Get<ResultAppointPeriodModel>(cmdText2, System.Data.CommandType.Text, null)).ReturnsAsync((true, "Success", new ResultAppointPeriodModel() { T5TYPE = "" }));
            mock.Setup(s => s.Execute(strCommand, System.Data.CommandType.Text, null)).ReturnsAsync((false, "Data not found."));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.AddAppointPeriod(request);
            //Assert.True(!result.success);
            Assert.Contains(", this Code already exists.", result.message);
        }
    }
}
