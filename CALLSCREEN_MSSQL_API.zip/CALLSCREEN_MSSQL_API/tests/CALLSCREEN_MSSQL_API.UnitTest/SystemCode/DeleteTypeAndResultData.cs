﻿using CALLSCREEN_MSSQL_API.DataAccess.Interfaces;
using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Models.SystemCode;
using Microsoft.Extensions.Configuration;
using Moq;
using System;
using System.Globalization;
using System.Threading.Tasks;
using Xunit;

namespace CALLSCREEN_MSSQL_API.UnitTest.SystemCode
{
    public class DeleteTypeAndResultData
    {
        protected readonly IConfiguration conf;
        protected readonly Mock<IDataCenter> mock;
        protected readonly SchemaDBModel schemaDB;

        private DateTime dateTime = DateTime.Now;
        private DateTimeFormatInfo m_DThai = new CultureInfo("th-TH", false).DateTimeFormat;

        public DeleteTypeAndResultData()
        {
            string env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")?.ToString() ?? "Development";
            conf = new ConfigurationBuilder()
                    .AddJsonFile($"appsettings.{env}.json", optional: true, reloadOnChange: true)
                    .AddEnvironmentVariables().Build();
            mock = new Mock<IDataCenter>();
            mock.Setup(s => s.SchemaDB()).Returns(conf.GetSection("SchemaDB").Get<SchemaDBModel>());
            schemaDB = mock.Object.SchemaDB();
        }

        [Fact]
        //[Theory]
        //[InlineData("1111111111111")]
        public async Task DeleteTypeAndResultData_Success()
        {
            RequestSaveTypeAndResultModel request = new RequestSaveTypeAndResultModel();
            int updateDate = (int.TryParse(dateTime.ToString("yyMMdd", m_DThai), out updateDate) == true ? updateDate : 0);
            int updateTime = (int.TryParse(dateTime.ToString("HHmmss", m_DThai), out updateTime) == true ? updateTime : 0);

            request.recordStatus = "X";

            var strCommand = $@"UPDATE {schemaDB?.CS}.CSMCB18 
                                SET T8DEL = '{request.recordStatus?.Trim()}' 
                                WHERE T8TYCD = '{request.typeCode?.Trim().ToUpper()}' 
                                    AND T8RSCD = '{request.resultCode?.Trim().ToUpper()}'";

            mock.Setup(s => s.Execute(strCommand, System.Data.CommandType.Text, null)).ReturnsAsync((true, "Success"));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.DeleteTypeAndResultData(request);
            Assert.True(result.success);
            Assert.Equal("Success", result.message);
        }

        [Fact]
        //[Theory]
        //[InlineData("0000000000000")]
        public async Task DeleteTypeAndResultData_Fail_DataNotFound()
        {
            RequestSaveTypeAndResultModel request = new RequestSaveTypeAndResultModel();
            int updateDate = (int.TryParse(dateTime.ToString("yyMMdd", m_DThai), out updateDate) == true ? updateDate : 0);
            int updateTime = (int.TryParse(dateTime.ToString("HHmmss", m_DThai), out updateTime) == true ? updateTime : 0);

            request.recordStatus = "X";

            var strCommand = $@"UPDATE {schemaDB?.CS}.CSMCB18 
                                SET T8DEL = '{request.recordStatus?.Trim()}' 
                                WHERE T8TYCD = '{request.typeCode?.Trim().ToUpper()}' 
                                    AND T8RSCD = '{request.resultCode?.Trim().ToUpper()}'";

            mock.Setup(s => s.Execute(strCommand, System.Data.CommandType.Text, null)).ReturnsAsync((false, "Data Not Update."));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.DeleteTypeAndResultData(request);
            //Assert.True(!result.success);
            Assert.Contains("Data Not Update", result.message);
        }
    }
}
