﻿using CALLSCREEN_MSSQL_API.DataAccess.Interfaces;
using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Models.SystemCode;
using Microsoft.Extensions.Configuration;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace CALLSCREEN_MSSQL_API.UnitTest.SystemCode
{
    public class GetDataCampaign
    {
        protected readonly IConfiguration conf;
        protected readonly Mock<IDataCenter> mock;
        protected readonly SchemaDBModel schemaDB;
        public GetDataCampaign()
        {
            string env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")?.ToString() ?? "Development";
            conf = new ConfigurationBuilder()
                    .AddJsonFile($"appsettings.{env}.json", optional: true, reloadOnChange: true)
                    .AddEnvironmentVariables().Build();
            mock = new Mock<IDataCenter>();
            mock.Setup(s => s.SchemaDB()).Returns(conf.GetSection("SchemaDB").Get<SchemaDBModel>());
            schemaDB = mock.Object.SchemaDB();
        }

        [Fact]
        //[Theory]
        //[InlineData("1111111111111")]
        public async Task GetDataCampaign_Success()
        {
            RequestGetListCampaignModel request = new RequestGetListCampaignModel() { callUser = "" };

            string strWhere = "";
            var cmdText = $@"SELECT T2NUSR,T2CAMP FROM {schemaDB?.CS}.CSMCB12";
            strWhere = " where T2DEL ='' ";
            if (!string.IsNullOrEmpty(request.callUser.Trim().ToUpper()))
            {
                strWhere += " and T2NUSR = '" + request.callUser.ToString().Trim() + "' ";
            }
            cmdText += " " + strWhere + " order by T2NUSR";

            mock.Setup(s => s.Get<List<ResultGetListCampaignModel>>(cmdText, System.Data.CommandType.Text, null)).ReturnsAsync((true, "Success", new List<ResultGetListCampaignModel>()));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.GetDataCampaign(request);
            Assert.True(result.success);
            Assert.Equal("Success", result.message);
        }

        [Fact]
        //[Theory]
        //[InlineData("0000000000000")]
        public async Task GetDataCampaign_Fail_DataNotFound()
        {
            RequestGetListCampaignModel request = new RequestGetListCampaignModel() { callUser =""};

            string strWhere = "";
            var cmdText = $@"SELECT T2NUSR,T2CAMP FROM {schemaDB.CS}.CSMCB12";
            strWhere = " where T2DEL ='' ";
            if (!string.IsNullOrEmpty(request.callUser.Trim().ToUpper()))
            {
                strWhere += " and T2NUSR = '" + request.callUser.ToString().Trim() + "' ";
            }
            cmdText += " " + strWhere + " order by T2NUSR";

            mock.Setup(s => s.Get<List<ResultGetListCampaignModel>>(cmdText, System.Data.CommandType.Text, null)).ReturnsAsync((false, "Data not found.", null));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.GetDataCampaign(request);
            //Assert.True(!result.success);
            Assert.Contains("Data not found", result.message);
        }
    }
}
