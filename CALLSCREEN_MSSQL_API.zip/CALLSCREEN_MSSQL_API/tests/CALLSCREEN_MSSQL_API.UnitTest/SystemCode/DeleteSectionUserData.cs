﻿using CALLSCREEN_MSSQL_API.DataAccess.Interfaces;
using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Models.SystemCode;
using Microsoft.Extensions.Configuration;
using Moq;
using System;
using System.Globalization;
using System.Threading.Tasks;
using Xunit;

namespace CALLSCREEN_MSSQL_API.UnitTest.SystemCode
{
    public class DeleteSectionUserData
    {
        protected readonly IConfiguration conf;
        protected readonly Mock<IDataCenter> mock;
        protected readonly SchemaDBModel schemaDB;

        private DateTime dateTime = DateTime.Now;
        private DateTimeFormatInfo m_DThai = new CultureInfo("th-TH", false).DateTimeFormat;

        public DeleteSectionUserData()
        {
            string env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")?.ToString() ?? "Development";
            conf = new ConfigurationBuilder()
                    .AddJsonFile($"appsettings.{env}.json", optional: true, reloadOnChange: true)
                    .AddEnvironmentVariables().Build();
            mock = new Mock<IDataCenter>();
            mock.Setup(s => s.SchemaDB()).Returns(conf.GetSection("SchemaDB").Get<SchemaDBModel>());
            schemaDB = mock.Object.SchemaDB();
        }

        [Fact]
        //[Theory]
        //[InlineData("1111111111111")]
        public async Task DeleteSectionUserData_Success()
        {
            RequestSaveSectionUserModel request = new RequestSaveSectionUserModel();
            int updateDate = (int.TryParse(dateTime.ToString("yyMMdd", m_DThai), out updateDate) == true ? updateDate : 0);
            int updateTime = (int.TryParse(dateTime.ToString("HHmmss", m_DThai), out updateTime) == true ? updateTime : 0);

            request.recordStatus = "X";

            var strCommand = $@"UPDATE {schemaDB?.CS}.CSMCB19 SET T9DEL = '{request.recordStatus?.Trim()}' 
                                WHERE T9DPUS = '{request.departmentUser?.Trim().ToUpper()}' 
                                AND T9SECT = '{request.sectionUser?.Trim().ToUpper()}' 
                                AND T9DPCD = '{request.calType?.Trim().ToUpper()}'";

            mock.Setup(s => s.Execute(strCommand, System.Data.CommandType.Text, null)).ReturnsAsync((true, "Success"));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.DeleteSectionUserData(request);
            Assert.True(result.success);
            Assert.Equal("Delete Data Success", result.message);
        }

        [Fact]
        //[Theory]
        //[InlineData("0000000000000")]
        public async Task DeleteSectionUserData_Fail_DataNotFound()
        {
            RequestSaveSectionUserModel request = new RequestSaveSectionUserModel();
            int updateDate = (int.TryParse(dateTime.ToString("yyMMdd", m_DThai), out updateDate) == true ? updateDate : 0);
            int updateTime = (int.TryParse(dateTime.ToString("HHmmss", m_DThai), out updateTime) == true ? updateTime : 0);

            request.recordStatus = "X";

            var strCommand = $@"UPDATE {schemaDB?.CS}.CSMCB19 SET T9DEL = '{request.recordStatus?.Trim()}' 
                                WHERE T9DPUS = '{request.departmentUser?.Trim().ToUpper()}' 
                                AND T9SECT = '{request.sectionUser?.Trim().ToUpper()}' 
                                AND T9DPCD = '{request.calType?.Trim().ToUpper()}'";

            mock.Setup(s => s.Execute(strCommand, System.Data.CommandType.Text, null)).ReturnsAsync((false, "Data not found."));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.DeleteSectionUserData(request);
            //Assert.True(!result.success);
            Assert.Contains("Data not found", result.message);
        }
    }
}
