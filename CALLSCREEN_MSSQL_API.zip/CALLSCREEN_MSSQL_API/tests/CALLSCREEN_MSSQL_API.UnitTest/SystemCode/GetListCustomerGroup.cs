﻿using CALLSCREEN_MSSQL_API.DataAccess.Interfaces;
using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Models.SystemCode;
using Microsoft.Extensions.Configuration;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace CALLSCREEN_MSSQL_API.UnitTest.SystemCode
{
    public class GetListCustomerGroup
    {
        protected readonly IConfiguration conf;
        protected readonly Mock<IDataCenter> mock;
        protected readonly SchemaDBModel schemaDB;
        public GetListCustomerGroup()
        {
            string env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")?.ToString() ?? "Development";
            conf = new ConfigurationBuilder()
                    .AddJsonFile($"appsettings.{env}.json", optional: true, reloadOnChange: true)
                    .AddEnvironmentVariables().Build();
            mock = new Mock<IDataCenter>();
            mock.Setup(s => s.SchemaDB()).Returns(conf.GetSection("SchemaDB").Get<SchemaDBModel>());
            schemaDB = mock.Object.SchemaDB();
        }

        [Fact]
        //[Theory]
        //[InlineData("1111111111111")]
        public async Task GetListCustomerGroup_Success()
        {
            RequestGetDataCustomerGroupModel request = new RequestGetDataCustomerGroupModel();

            string strWhere = "";
            int intmonth = 0;
            int fromLastMonth, toLastMonth;

            var cmdText = $@"SELECT A.T7STAS, A.T7TYSQ, A.T7TYCD, A.T7TYDS, A.T7MONF, A.T7MONT, A.T7ARRY, A.T7UDAT, A.T7UTIM, A.T7UUSR, A.T7UPGM, A.T7UJOB, A.T7DEL
                            FROM {schemaDB?.CS}.CSMCB17 A";

            strWhere = $"WHERE A.T7DEL = ''";

            if (string.IsNullOrWhiteSpace(request.custGrpStatus) == false)
            {
                strWhere += $" and A.T7STAS = '{request.custGrpStatus?.Trim().ToUpper()}'";
            }

            if (string.IsNullOrWhiteSpace(request.typeSequence) == false)
            {
                strWhere += $" and A.T7TYSQ = '{request.typeSequence?.Trim().ToUpper()}'";
            }

            if (string.IsNullOrWhiteSpace(request.typeCode) == false)
            {
                strWhere += $" and A.T7TYCD = '{request.typeCode?.Trim()}'";
            }

            if (string.IsNullOrWhiteSpace(request.typeDescription) == false)
            {
                strWhere += $" and A.T7TYDS LIKE '%{request.typeDescription?.Trim()}%'";
            }

            if (string.IsNullOrWhiteSpace(request.fromLastMonth) == false)
            {
                fromLastMonth = (int.TryParse(request.fromLastMonth, out intmonth) == true ? intmonth : 0);

                strWhere += $" and A.T7MONF = '{fromLastMonth}'";
            }

            if (string.IsNullOrWhiteSpace(request.toLastMonth) == false)
            {
                toLastMonth = (int.TryParse(request.toLastMonth, out intmonth) == true ? intmonth : 0);
                strWhere += $" and A.T7MONT = '{toLastMonth}'";
            }

            cmdText += $" {strWhere} ORDER BY A.T7STAS, A.T7TYSQ ";

            mock.Setup(s => s.Get<List<GetDataCustomerGroupModel>>(cmdText, System.Data.CommandType.Text, null)).ReturnsAsync((true, "Success", new List<GetDataCustomerGroupModel>()));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.GetListCustomerGroup(request);
            Assert.True(result.success);
            Assert.Equal("Success", result.message);
        }

        [Fact]
        //[Theory]
        //[InlineData("0000000000000")]
        public async Task GetListCustomerGroup_Fail_DataNotFound()
        {
            RequestGetDataCustomerGroupModel request = new RequestGetDataCustomerGroupModel();

            string strWhere = "";
            int intmonth = 0;
            int fromLastMonth, toLastMonth;

            var cmdText = $@"SELECT A.T7STAS, A.T7TYSQ, A.T7TYCD, A.T7TYDS, A.T7MONF, A.T7MONT, A.T7ARRY, A.T7UDAT, A.T7UTIM, A.T7UUSR, A.T7UPGM, A.T7UJOB, A.T7DEL
                            FROM {schemaDB?.CS}.CSMCB17 A";

            strWhere = $"WHERE A.T7DEL = ''";

            if (string.IsNullOrWhiteSpace(request.custGrpStatus) == false)
            {
                strWhere += $" and A.T7STAS = '{request.custGrpStatus?.Trim().ToUpper()}'";
            }

            if (string.IsNullOrWhiteSpace(request.typeSequence) == false)
            {
                strWhere += $" and A.T7TYSQ = '{request.typeSequence?.Trim().ToUpper()}'";
            }

            if (string.IsNullOrWhiteSpace(request.typeCode) == false)
            {
                strWhere += $" and A.T7TYCD = '{request.typeCode?.Trim()}'";
            }

            if (string.IsNullOrWhiteSpace(request.typeDescription) == false)
            {
                strWhere += $" and A.T7TYDS LIKE '%{request.typeDescription?.Trim()}%'";
            }

            if (string.IsNullOrWhiteSpace(request.fromLastMonth) == false)
            {
                fromLastMonth = (int.TryParse(request.fromLastMonth, out intmonth) == true ? intmonth : 0);

                strWhere += $" and A.T7MONF = '{fromLastMonth}'";
            }

            if (string.IsNullOrWhiteSpace(request.toLastMonth) == false)
            {
                toLastMonth = (int.TryParse(request.toLastMonth, out intmonth) == true ? intmonth : 0);
                strWhere += $" and A.T7MONT = '{toLastMonth}'";
            }

            cmdText += $" {strWhere} ORDER BY A.T7STAS, A.T7TYSQ ";

            mock.Setup(s => s.Get<List<GetDataCustomerGroupModel>>(cmdText, System.Data.CommandType.Text, null)).ReturnsAsync((false, "Data not found.", null));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.GetListCustomerGroup(request);
            //Assert.True(!result.success);
            Assert.Contains("Data not found", result.message);
        }
    }
}
