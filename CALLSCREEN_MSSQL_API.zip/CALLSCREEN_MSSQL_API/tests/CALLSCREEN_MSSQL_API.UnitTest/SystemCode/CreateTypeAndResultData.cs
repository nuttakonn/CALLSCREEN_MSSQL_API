﻿using CALLSCREEN_MSSQL_API.DataAccess.Interfaces;
using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Models.SystemCode;
using Microsoft.Extensions.Configuration;
using Moq;
using System;
using System.Globalization;
using System.Threading.Tasks;
using Xunit;

namespace CALLSCREEN_MSSQL_API.UnitTest.SystemCode
{
    public class CreateTypeAndResultData
    {
        protected readonly IConfiguration conf;
        protected readonly Mock<IDataCenter> mock;
        protected readonly SchemaDBModel schemaDB;

        private DateTime dateTime = DateTime.Now;
        private DateTimeFormatInfo m_DThai = new CultureInfo("th-TH", false).DateTimeFormat;

        public CreateTypeAndResultData()
        {
            string env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")?.ToString() ?? "Development";
            conf = new ConfigurationBuilder()
                    .AddJsonFile($"appsettings.{env}.json", optional: true, reloadOnChange: true)
                    .AddEnvironmentVariables().Build();
            mock = new Mock<IDataCenter>();
            mock.Setup(s => s.SchemaDB()).Returns(conf.GetSection("SchemaDB").Get<SchemaDBModel>());
            schemaDB = mock.Object.SchemaDB();
        }

        [Fact]
        //[Theory]
        //[InlineData("1111111111111")]
        public async Task CreateTypeAndResultData_Success()
        {
            RequestSaveTypeAndResultModel request = new RequestSaveTypeAndResultModel();
            mock.Setup(s => s.Get<GetDataTypeCodeAndResultCodeModel>(It.IsAny<string>(), System.Data.CommandType.Text, null)).ReturnsAsync((false, "", new GetDataTypeCodeAndResultCodeModel()));
            mock.Setup(s => s.Get<GetDataTypeCodeAndResultCodeModel>(It.IsAny<string>(), System.Data.CommandType.Text, null)).ReturnsAsync((false, "", new GetDataTypeCodeAndResultCodeModel()));
            mock.Setup(dc => dc.Execute(It.IsAny<string>(), System.Data.CommandType.Text, null))
            .ReturnsAsync((true, ""));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.CreateTypeAndResultData(request);
            Assert.True(result.success);
            Assert.Equal("Insert Data Success, ", result.message);
        }

        [Fact]
        //[Theory]
        //[InlineData("0000000000000")]
        public async Task CreateTypeAndResultData_Fail_DataNotFound()
        {
            RequestSaveTypeAndResultModel request = new RequestSaveTypeAndResultModel();
            int updateDate = (int.TryParse(dateTime.ToString("yyMMdd", m_DThai), out updateDate) == true ? updateDate : 0);
            int updateTime = (int.TryParse(dateTime.ToString("HHmmss", m_DThai), out updateTime) == true ? updateTime : 0);

            var strCommand = $@"INSERT INTO {schemaDB?.CS}.CSMCB18 (T8TYCD,T8RSCD,T8UDAT,T8UTIM,T8UUSR,T8UPGM,T8UJOB,T8DEL)
                                 VALUES ('{request.typeCode?.Trim().ToUpper()}'
                                        , '{request.resultCode?.Trim().ToUpper()}'
                                        , '{updateDate}'
                                        , '{updateTime}'
                                        , '{request.userName?.Trim()}'
                                        , '{request.updByProgram?.Trim()}'
                                        , '{request.updWorkStation?.Trim()}'
                                        , '{request.recordStatus?.Trim()}')";

            mock.Setup(s => s.Execute(strCommand, System.Data.CommandType.Text, null)).ReturnsAsync((false, "Data not found."));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.CreateTypeAndResultData(request);
            //Assert.True(!result.success);
            Assert.Contains("Data not found", result.message);
        }
    }
}
