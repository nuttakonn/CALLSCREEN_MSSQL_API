﻿using CALLSCREEN_MSSQL_API.DataAccess.Interfaces;
using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Models.SystemCode;
using Microsoft.Extensions.Configuration;
using Moq;
using System;
using System.Globalization;
using System.Threading.Tasks;
using Xunit;

namespace CALLSCREEN_MSSQL_API.UnitTest.SystemCode
{
    public class CreateCustomerGroupData
    {
        protected readonly IConfiguration conf;
        protected readonly Mock<IDataCenter> mock;
        protected readonly SchemaDBModel schemaDB;

        private DateTime dateTime = DateTime.Now;
        private DateTimeFormatInfo m_DThai = new CultureInfo("th-TH", false).DateTimeFormat;

        public CreateCustomerGroupData()
        {
            string env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")?.ToString() ?? "Development";
            conf = new ConfigurationBuilder()
                    .AddJsonFile($"appsettings.{env}.json", optional: true, reloadOnChange: true)
                    .AddEnvironmentVariables().Build();
            mock = new Mock<IDataCenter>();
            mock.Setup(s => s.SchemaDB()).Returns(conf.GetSection("SchemaDB").Get<SchemaDBModel>());
            schemaDB = mock.Object.SchemaDB();
        }

        [Fact]
        //[Theory]
        //[InlineData("1111111111111")]
        public async Task CreateCustomerGroupData_Success()
        {
            RequestSaveCustomerGroupModel request = new RequestSaveCustomerGroupModel();
            int updateDate = (int.TryParse(dateTime.ToString("yyMMdd", m_DThai), out updateDate) == true ? updateDate : 0);
            int updateTime = (int.TryParse(dateTime.ToString("HHmmss", m_DThai), out updateTime) == true ? updateTime : 0);
            int intmonth = 0;
            int fromLastMonth = (int.TryParse(request.fromLastMonth, out intmonth) == true ? intmonth : 0);
            int toLastMonth = (int.TryParse(request.toLastMonth, out intmonth) == true ? intmonth : 0);

            mock.Setup(s => s.Get<GetDataCustomerGroupModel>(It.IsAny<string>(), System.Data.CommandType.Text, null)).ReturnsAsync((false, "", new GetDataCustomerGroupModel()));
            mock.Setup(s => s.Get<GetDataCustomerGroupModel>(It.IsAny<string>(), System.Data.CommandType.Text, null)).ReturnsAsync((false, "", new GetDataCustomerGroupModel()));
            mock.Setup(dc => dc.Execute(It.IsAny<string>(), System.Data.CommandType.Text, null))
            .ReturnsAsync((true, ""));
            var service = new Services.SystemCodeService(mock.Object);
    
            var result = await service.CreateCustomerGroupData(request);
            Assert.True(result.success);
            Assert.Equal("Insert Data Success, ", result.message);
        }

        [Fact]
        //[Theory]
        //[InlineData("0000000000000")]
        public async Task CreateCustomerGroupData_Fail_DataNotFound()
        {
            RequestSaveCustomerGroupModel request = new RequestSaveCustomerGroupModel();
            int updateDate = (int.TryParse(dateTime.ToString("yyMMdd", m_DThai), out updateDate) == true ? updateDate : 0);
            int updateTime = (int.TryParse(dateTime.ToString("HHmmss", m_DThai), out updateTime) == true ? updateTime : 0);
            int intmonth = 0;
            int fromLastMonth = (int.TryParse(request.fromLastMonth, out intmonth) == true ? intmonth : 0);
            int toLastMonth = (int.TryParse(request.toLastMonth, out intmonth) == true ? intmonth : 0);

            var strCommand = $@"INSERT INTO {schemaDB?.CS}.CSMCB17 (T7STAS,T7TYSQ,T7TYCD,T7TYDS,T7MONF,T7MONT,T7ARRY,T7UDAT,T7UTIM,T7UUSR,T7UPGM,T7UJOB,T7DEL) 
                                 VALUES ('{request.custGrpStatus?.Trim().ToUpper()}'
                                        , '{request.typeSequence?.Trim().ToUpper()}'
                                        , '{request.typeCode?.Trim()}'
                                        , '{request.typeDescription?.Trim()}'
                                        , '{fromLastMonth}' 
                                        , '{toLastMonth}'
                                        , '{request.array6?.Trim().ToUpper()}'
                                        , '{updateDate}'
                                        , '{updateTime}'
                                        , '{request.userName?.Trim()}'
                                        , '{request.updByProgram?.Trim()}'
                                        , '{request.updWorkStation?.Trim()}'
                                        , '{request.recordStatus?.Trim()}')";

            mock.Setup(s => s.Execute(strCommand, System.Data.CommandType.Text, null)).ReturnsAsync((false, "Data not found."));
            var service = new Services.SystemCodeService(mock.Object);

            #region Create HS
            string actionCode = "I";
            var cmdText = $@"INSERT INTO {schemaDB?.CS}.CSMCB17HS (T7ACTN,T7STAS,T7TYSQ,T7TYCD,T7TYDS,T7MONF,T7MONT,T7ARRY,T7UDAT,T7UTIM,T7UUSR,T7UPGM,T7UJOB,T7DEL) 
                                 VALUES ('{actionCode}'
                                        , '{request.custGrpStatus?.Trim().ToUpper()}'
                                        , '{request.typeSequence?.Trim().ToUpper()}'
                                        , '{request.typeCode?.Trim()}'
                                        , '{request.typeDescription?.Trim()}'
                                        , '{fromLastMonth}' 
                                        , '{toLastMonth}'
                                        , '{request.array6?.Trim().ToUpper()}'
                                        , '{updateDate}'
                                        , '{updateTime}'
                                        , '{request.userName?.Trim()}'
                                        , '{request.updByProgram?.Trim()}'
                                        , '{request.updWorkStation?.Trim()}'
                                        , '{request.recordStatus?.Trim()}')";

            mock.Setup(s => s.Execute(cmdText, System.Data.CommandType.Text, null)).ReturnsAsync((false, "Data not found."));
            service = new Services.SystemCodeService(mock.Object);
            #endregion Create HS

            var result = await service.CreateCustomerGroupData(request);
            //Assert.True(!result.success);
            Assert.Contains("Data not found", result.message);
        }
    }
}
