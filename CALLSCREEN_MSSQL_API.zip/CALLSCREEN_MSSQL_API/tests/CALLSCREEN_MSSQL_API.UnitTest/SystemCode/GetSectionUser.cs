﻿using CALLSCREEN_MSSQL_API.DataAccess.Interfaces;
using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Models.SystemCode;
using Microsoft.Extensions.Configuration;
using Moq;
using System;
using System.Threading.Tasks;
using Xunit;

namespace CALLSCREEN_MSSQL_API.UnitTest.SystemCode
{
    public class GetSectionUser
    {
        protected readonly IConfiguration conf;
        protected readonly Mock<IDataCenter> mock;
        protected readonly SchemaDBModel schemaDB;
        public GetSectionUser()
        {
            string env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")?.ToString() ?? "Development";
            conf = new ConfigurationBuilder()
                    .AddJsonFile($"appsettings.{env}.json", optional: true, reloadOnChange: true)
                    .AddEnvironmentVariables().Build();
            mock = new Mock<IDataCenter>();
            mock.Setup(s => s.SchemaDB()).Returns(conf.GetSection("SchemaDB").Get<SchemaDBModel>());
            schemaDB = mock.Object.SchemaDB();
        }

        [Fact]
        //[Theory]
        //[InlineData("1111111111111")]
        public async Task GetSectionUser_Success()
        {
            RequestSectionUserModel request = new RequestSectionUserModel();

            var strCommand = $@"SELECT A.T9SECT, A.T9DPCD, A.T9DPUS, A.T9UDAT, A.T9UTIM, A.T9UUSR, A.T9UPGM, A.T9UJOB, A.T9DEL 
                            FROM {schemaDB?.CS}.CSMCB19 A 
                            WHERE A.T9DPUS = '{request.departmentUser?.Trim().ToUpper()}' 
                            AND A.T9SECT = '{request.sectionUser?.Trim().ToUpper()}' 
                            AND A.T9DPCD = '{request.calType?.Trim().ToUpper()}'";

            mock.Setup(s => s.Get<GetSectionUserModel>(strCommand, System.Data.CommandType.Text, null)).ReturnsAsync((true, "Success", new GetSectionUserModel()));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.GetSectionUser(request);
            Assert.True(result.success);
            Assert.Equal("Success", result.message);
        }

        [Fact]
        //[Theory]
        //[InlineData("0000000000000")]
        public async Task GetSectionUser_Fail_DataNotFound()
        {
            RequestSectionUserModel request = new RequestSectionUserModel();

            var strCommand = $@"SELECT A.T9SECT, A.T9DPCD, A.T9DPUS, A.T9UDAT, A.T9UTIM, A.T9UUSR, A.T9UPGM, A.T9UJOB, A.T9DEL 
                            FROM {schemaDB?.CS}.CSMCB19 A 
                            WHERE A.T9DPUS = '{request.departmentUser?.Trim().ToUpper()}' 
                            AND A.T9SECT = '{request.sectionUser?.Trim().ToUpper()}' 
                            AND A.T9DPCD = '{request.calType?.Trim().ToUpper()}'";

            mock.Setup(s => s.Get<GetSectionUserModel>(strCommand, System.Data.CommandType.Text, null)).ReturnsAsync((false, "Data not found.", null));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.GetSectionUser(request);
            //Assert.True(!result.success);
            Assert.Contains("Data not found", result.message);
        }
    }
}
