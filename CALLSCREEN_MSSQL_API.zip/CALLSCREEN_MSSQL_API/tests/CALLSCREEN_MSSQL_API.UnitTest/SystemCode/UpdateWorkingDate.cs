﻿using CALLSCREEN_MSSQL_API.DataAccess.Interfaces;
using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Models.SystemCode;
using Microsoft.Extensions.Configuration;
using Moq;
using System;
using System.Globalization;
using System.Threading.Tasks;
using Xunit;

namespace CALLSCREEN_MSSQL_API.UnitTest.SystemCode
{
    public class UpdateWorkingDate
    {
        protected readonly IConfiguration conf;
        protected readonly Mock<IDataCenter> mock;
        protected readonly SchemaDBModel schemaDB;

        private DateTime dateTime = DateTime.Now;
        private DateTimeFormatInfo m_DThai = new CultureInfo("th-TH", false).DateTimeFormat;

        public UpdateWorkingDate()
        {
            string env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")?.ToString() ?? "Development";
            conf = new ConfigurationBuilder()
                    .AddJsonFile($"appsettings.{env}.json", optional: true, reloadOnChange: true)
                    .AddEnvironmentVariables().Build();
            mock = new Mock<IDataCenter>();
            mock.Setup(s => s.SchemaDB()).Returns(conf.GetSection("SchemaDB").Get<SchemaDBModel>());
            schemaDB = mock.Object.SchemaDB();
        }

        [Fact]
        //[Theory]
        //[InlineData("1111111111111")]
        public async Task UpdateWorkingDate_Success()
        {
            RequestWorkingDateModel request = new RequestWorkingDateModel();
           
            mock.Setup(s => s.Execute(It.IsAny<string>(), System.Data.CommandType.Text, null)).ReturnsAsync((true, "Success"));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.UpdateWorkingDate(request);
            Assert.True(result.success);
            Assert.Equal("Success", result.message);
        }

        [Fact]
        //[Theory]
        //[InlineData("0000000000000")]
        public async Task UpdateWorkingDate_Fail_DataNotFound()
        {
            RequestWorkingDateModel request = new RequestWorkingDateModel();
          
            mock.Setup(s => s.Execute(It.IsAny<string>(), System.Data.CommandType.Text, null)).ReturnsAsync((false, "Data Not Update"));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.UpdateWorkingDate(request);
            //Assert.True(!result.success);
            Assert.Contains("Data Not Update", result.message);
        }
    }
}
