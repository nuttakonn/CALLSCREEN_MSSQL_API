﻿using CALLSCREEN_MSSQL_API.DataAccess.Interfaces;
using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Models.SystemCode;
using Microsoft.Extensions.Configuration;
using Moq;
using System;
using System.Threading.Tasks;
using Xunit;

namespace CALLSCREEN_MSSQL_API.UnitTest.SystemCode
{
    public class GetCustomerGroup
    {
        protected readonly IConfiguration conf;
        protected readonly Mock<IDataCenter> mock;
        protected readonly SchemaDBModel schemaDB;
        public GetCustomerGroup()
        {
            string env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")?.ToString() ?? "Development";
            conf = new ConfigurationBuilder()
                    .AddJsonFile($"appsettings.{env}.json", optional: true, reloadOnChange: true)
                    .AddEnvironmentVariables().Build();
            mock = new Mock<IDataCenter>();
            mock.Setup(s => s.SchemaDB()).Returns(conf.GetSection("SchemaDB").Get<SchemaDBModel>());
            schemaDB = mock.Object.SchemaDB();
        }

        [Fact]
        //[Theory]
        //[InlineData("1111111111111")]
        public async Task GetCustomerGroup_Success()
        {
            RequestGetDataCustomerGroupModel request = new RequestGetDataCustomerGroupModel();

            var strCommand = $@"SELECT A.T7STAS, A.T7TYSQ, A.T7TYCD, A.T7TYDS, A.T7MONF, A.T7MONT, A.T7ARRY, A.T7UDAT, A.T7UTIM, A.T7UUSR, A.T7UPGM, A.T7UJOB, A.T7DEL
                                FROM {schemaDB?.CS}.CSMCB17 A 
                                WHERE A.T7TYSQ = '{request.typeSequence?.Trim().ToUpper()}' 
                                    AND A.T7STAS = '{request.custGrpStatus?.Trim().ToUpper()}'";

            mock.Setup(s => s.Get<GetDataCustomerGroupModel>(strCommand, System.Data.CommandType.Text, null)).ReturnsAsync((true, "Success", new GetDataCustomerGroupModel()));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.GetCustomerGroup(request);
            Assert.True(result.success);
            Assert.Equal("Success", result.message);
        }

        [Fact]
        //[Theory]
        //[InlineData("0000000000000")]
        public async Task GetCustomerGroup_Fail_DataNotFound()
        {
            RequestGetDataCustomerGroupModel request = new RequestGetDataCustomerGroupModel();

            var strCommand = $@"SELECT A.T7STAS, A.T7TYSQ, A.T7TYCD, A.T7TYDS, A.T7MONF, A.T7MONT, A.T7ARRY, A.T7UDAT, A.T7UTIM, A.T7UUSR, A.T7UPGM, A.T7UJOB, A.T7DEL
                                FROM {schemaDB?.CS}.CSMCB17 A 
                                WHERE A.T7TYSQ = '{request.typeSequence?.Trim().ToUpper()}' 
                                    AND A.T7STAS = '{request.custGrpStatus?.Trim().ToUpper()}'";

            mock.Setup(s => s.Get<GetDataCustomerGroupModel>(strCommand, System.Data.CommandType.Text, null)).ReturnsAsync((false, "Data not found.", null));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.GetCustomerGroup(request);
            //Assert.True(!result.success);
            Assert.Contains("Data not found", result.message);
        }
    }
}
