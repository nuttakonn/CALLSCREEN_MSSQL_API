﻿using CALLSCREEN_MSSQL_API.DataAccess.Interfaces;
using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Models.SystemCode;
using Microsoft.Extensions.Configuration;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace CALLSCREEN_MSSQL_API.UnitTest.SystemCode
{
    public class GetAppointPeriod
    {
        protected readonly IConfiguration conf;
        protected readonly Mock<IDataCenter> mock;
        protected readonly SchemaDBModel schemaDB;
        public GetAppointPeriod()
        {
            string env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")?.ToString() ?? "Development";
            conf = new ConfigurationBuilder()
                    .AddJsonFile($"appsettings.{env}.json", optional: true, reloadOnChange: true)
                    .AddEnvironmentVariables().Build();
            mock = new Mock<IDataCenter>();
            mock.Setup(s => s.SchemaDB()).Returns(conf.GetSection("SchemaDB").Get<SchemaDBModel>());
            schemaDB = mock.Object.SchemaDB();
        }

        [Fact]
        //[Theory]
        //[InlineData("1111111111111")]
        public async Task GetAppointPeriod_Success()
        {
            RequestAppointPeriodModel request = new RequestAppointPeriodModel() { type = "ss" };

            string condition = (!string.IsNullOrEmpty(request.type)) ? $" AND T5TYPE = '{request.type.Trim().ToUpper()}' " : "";
            var strCommand = $@"SELECT
                                T5TYPE,
                                T5STIM,
                                T5ETIM
                             FROM
                                {schemaDB?.CS}.CSMCB05
                             WHERE 
                                T5DEL = '' 
                                {condition}
                             ORDER BY
                                T5TYPE";
            mock.Setup(s => s.Get<List<ResultAppointPeriodModel>>(strCommand, System.Data.CommandType.Text, null)).ReturnsAsync((true, "Success", new List<ResultAppointPeriodModel>()));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.GetAppointPeriod(request);
            Assert.True(result.success);
            Assert.Equal("Success", result.message);
        }

        [Fact]
        //[Theory]
        //[InlineData("0000000000000")]
        public async Task GetAppointPeriod_Fail_DataNotFound()
        {
            RequestAppointPeriodModel request = new RequestAppointPeriodModel() { type = "ss" };

            mock.Setup(s => s.Get<List<ResultAppointPeriodModel>>(It.IsAny<string>(), System.Data.CommandType.Text, null)).ReturnsAsync((false, "Data not found.", new List<ResultAppointPeriodModel>()));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.GetAppointPeriod(request);
            //Assert.True(!result.success);
            Assert.Contains("Data not found", result.message);
        }
    }
}
