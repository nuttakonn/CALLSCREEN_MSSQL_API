﻿using CALLSCREEN_MSSQL_API.DataAccess.Interfaces;
using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Models.SystemCode;
using Microsoft.Extensions.Configuration;
using Moq;
using System;
using System.Globalization;
using System.Threading.Tasks;
using Xunit;

namespace CALLSCREEN_MSSQL_API.UnitTest.SystemCode
{
    public class EditCampaignNewStaff
    {
        protected readonly IConfiguration conf;
        protected readonly Mock<IDataCenter> mock;
        protected readonly SchemaDBModel schemaDB;

        private DateTime dateTime = DateTime.Now;
        private DateTimeFormatInfo m_DThai = new CultureInfo("th-TH", false).DateTimeFormat;

        public EditCampaignNewStaff()
        {
            string env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")?.ToString() ?? "Development";
            conf = new ConfigurationBuilder()
                    .AddJsonFile($"appsettings.{env}.json", optional: true, reloadOnChange: true)
                    .AddEnvironmentVariables().Build();
            mock = new Mock<IDataCenter>();
            mock.Setup(s => s.SchemaDB()).Returns(conf.GetSection("SchemaDB").Get<SchemaDBModel>());
            schemaDB = mock.Object.SchemaDB();
        }

        [Fact]
        //[Theory]
        //[InlineData("1111111111111")]
        public async Task EditCampaignNewStaff_Success()
        {
            InputCampaignNewStaffForCRUD request = new InputCampaignNewStaffForCRUD() { updateby = "", campaign = "", callUser = "" };
            mock.Setup(dc => dc.Execute(It.IsAny<string>(), System.Data.CommandType.Text, null))
                            .ReturnsAsync((true, "Success"));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.EditCampaignNewStaff(request);
            Assert.True(result.success);
            Assert.Equal("Success", result.message);
        }

        [Fact]
        //[Theory]
        //[InlineData("0000000000000")]
        public async Task EditCampaignNewStaff_Fail_DataNotFound()
        {
            InputCampaignNewStaffForCRUD request = new InputCampaignNewStaffForCRUD() { updateby  ="", campaign ="", callUser =""};

            var strCommand = $@"UPDATE {schemaDB?.CS}.CSMCB12 SET T2UDAT={Convert.ToUInt32(dateTime.ToString("yyMMdd", m_DThai))},
                                    T2UTIM={Convert.ToUInt32(dateTime.ToString("HHmmss", m_DThai))},
                                    T2UUSR='{request.updateby.ToUpper().Trim()}',
                                    T2CAMP='{request.campaign.ToUpper().Trim()}',
                                    T2UPGM='{""}',
                                    T2UJOB='{""}',
                                    T2DEL='{""}' 
                                    WHERE T2NUSR='{request.callUser.ToUpper().Trim()}'";

            mock.Setup(s => s.Execute(strCommand, System.Data.CommandType.Text, null)).ReturnsAsync((false, ""));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.EditCampaignNewStaff(request);
            //Assert.True(!result.success);
            Assert.Contains("Data Not Update ()", result.message);
        }
    }
}
