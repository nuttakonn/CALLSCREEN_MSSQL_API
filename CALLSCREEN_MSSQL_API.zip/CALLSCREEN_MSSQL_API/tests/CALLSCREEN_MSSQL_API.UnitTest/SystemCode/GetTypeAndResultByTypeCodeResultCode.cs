﻿using CALLSCREEN_MSSQL_API.DataAccess.Interfaces;
using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Models.SystemCode;
using Microsoft.Extensions.Configuration;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace CALLSCREEN_MSSQL_API.UnitTest.SystemCode
{
    public class GetTypeAndResultByTypeCodeResultCode
    {
        protected readonly IConfiguration conf;
        protected readonly Mock<IDataCenter> mock;
        protected readonly SchemaDBModel schemaDB;
        public GetTypeAndResultByTypeCodeResultCode()
        {
            string env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")?.ToString() ?? "Development";
            conf = new ConfigurationBuilder()
                    .AddJsonFile($"appsettings.{env}.json", optional: true, reloadOnChange: true)
                    .AddEnvironmentVariables().Build();
            mock = new Mock<IDataCenter>();
            mock.Setup(s => s.SchemaDB()).Returns(conf.GetSection("SchemaDB").Get<SchemaDBModel>());
            schemaDB = mock.Object.SchemaDB();
        }

        [Fact]
        //[Theory]
        //[InlineData("1111111111111")]
        public async Task GetTypeAndResultByTypeCodeResultCode_Success()
        {
            RequestGetDataTypeAndResultModel request = new RequestGetDataTypeAndResultModel() {typeCode = "", resultCode = ""};

            mock.Setup(s => s.Get<GetDataTypeCodeAndResultCodeModel>(It.IsAny<string>(), System.Data.CommandType.Text, null)).ReturnsAsync((true, "Success", new GetDataTypeCodeAndResultCodeModel()));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.GetTypeAndResultByTypeCodeResultCode(request);
            Assert.True(result.success);
            Assert.Equal("Success", result.message);
        }

        [Fact]
        //[Theory]
        //[InlineData("0000000000000")]
        public async Task GetTypeAndResultByTypeCodeResultCode_Fail_DataNotFound()
        {
            RequestGetDataTypeAndResultModel request = new RequestGetDataTypeAndResultModel() { typeCode  ="", resultCode =""};

            mock.Setup(s => s.Get<GetDataTypeCodeAndResultCodeModel>(It.IsAny<string>(), System.Data.CommandType.Text, null)).ReturnsAsync((false, "Data not found.", null));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.GetTypeAndResultByTypeCodeResultCode(request);
            //Assert.True(!result.success);
            Assert.Contains("Data not found", result.message);
        }
    }
}
