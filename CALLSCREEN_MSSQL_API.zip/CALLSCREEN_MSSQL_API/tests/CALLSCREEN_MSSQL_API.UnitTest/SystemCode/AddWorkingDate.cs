﻿using CALLSCREEN_MSSQL_API.DataAccess.Interfaces;
using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Models.SystemCode;
using Microsoft.Extensions.Configuration;
using Moq;
using System;
using System.Globalization;
using System.Threading.Tasks;
using Xunit;

namespace CALLSCREEN_MSSQL_API.UnitTest.SystemCode
{
    public class AddWorkingDate
    {
        protected readonly IConfiguration conf;
        protected readonly Mock<IDataCenter> mock;
        protected readonly SchemaDBModel schemaDB;

        private DateTime dateTime = DateTime.Now;
        private DateTimeFormatInfo m_DThai = new CultureInfo("th-TH", false).DateTimeFormat;

        public AddWorkingDate()
        {
            string env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")?.ToString() ?? "Development";
            conf = new ConfigurationBuilder()
                    .AddJsonFile($"appsettings.{env}.json", optional: true, reloadOnChange: true)
                    .AddEnvironmentVariables().Build();
            mock = new Mock<IDataCenter>();
            mock.Setup(s => s.SchemaDB()).Returns(conf.GetSection("SchemaDB").Get<SchemaDBModel>());
            schemaDB = mock.Object.SchemaDB();
        }

        [Fact]
        //[Theory]
        //[InlineData("1111111111111")]
        public async Task AddWorkingDate_Success()
        {
            RequestWorkingDateModel request = new RequestWorkingDateModel() { workingDate = "00/00/0000" };
            mock.Setup(s => s.Get<ResultWorkingDateModel>(It.IsAny<string>(), System.Data.CommandType.Text, null)).ReturnsAsync((true, "Success", new ResultWorkingDateModel() { T4HDAT = 0, T4STIM = 0, T4ETIM = 0 }));
            mock.Setup(s => s.Get<ResultWorkingDateModel>(It.IsAny<string>(), System.Data.CommandType.Text, null)).ReturnsAsync((true, "Success", new ResultWorkingDateModel() { T4HDAT = 0, T4STIM = 0, T4ETIM = 0 }));
            mock.Setup(dc => dc.Execute(It.IsAny<string>(), System.Data.CommandType.Text, null))
            .ReturnsAsync((true, ""));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.AddWorkingDate(request);
            Assert.True(result.success);
            Assert.Equal("Insert Data Success, ", result.message);
        }

        [Fact]
        //[Theory]
        //[InlineData("0000000000000")]
        public async Task AddWorkingDate_Fail_DataNotFound()
        {
            RequestWorkingDateModel request = new RequestWorkingDateModel() { workingDate = "00/00/0000" };
            mock.Setup(s => s.Get<ResultWorkingDateModel>(It.IsAny<string>(), System.Data.CommandType.Text, null)).ReturnsAsync((true, "Success", new ResultWorkingDateModel() { T4HDAT = 1, T4STIM = 0, T4ETIM = 0 }));
            mock.Setup(s => s.Get<ResultWorkingDateModel>(It.IsAny<string>(), System.Data.CommandType.Text, null)).ReturnsAsync((true, "Success", new ResultWorkingDateModel() { T4HDAT = 1, T4STIM = 0, T4ETIM = 0 }));
            mock.Setup(dc => dc.Execute(It.IsAny<string>(), System.Data.CommandType.Text, null))
            .ReturnsAsync((true, "Success"));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.AddWorkingDate(request);
            //Assert.True(!result.success);
            Assert.Contains(", this Code already exists.", result.message);
        }
    }
}
