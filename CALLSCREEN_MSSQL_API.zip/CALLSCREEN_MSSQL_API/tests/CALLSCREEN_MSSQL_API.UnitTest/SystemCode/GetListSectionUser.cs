﻿using CALLSCREEN_MSSQL_API.DataAccess.Interfaces;
using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Models.SystemCode;
using Microsoft.Extensions.Configuration;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace CALLSCREEN_MSSQL_API.UnitTest.SystemCode
{
    public class GetListSectionUser
    {
        protected readonly IConfiguration conf;
        protected readonly Mock<IDataCenter> mock;
        protected readonly SchemaDBModel schemaDB;
        public GetListSectionUser()
        {
            string env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")?.ToString() ?? "Development";
            conf = new ConfigurationBuilder()
                    .AddJsonFile($"appsettings.{env}.json", optional: true, reloadOnChange: true)
                    .AddEnvironmentVariables().Build();
            mock = new Mock<IDataCenter>();
            mock.Setup(s => s.SchemaDB()).Returns(conf.GetSection("SchemaDB").Get<SchemaDBModel>());
            schemaDB = mock.Object.SchemaDB();
        }

        [Fact]
        //[Theory]
        //[InlineData("1111111111111")]
        public async Task GetListSectionUser_Success()
        {
            RequestSectionUserModel request = new RequestSectionUserModel() { calType = "", sectionUser = "", departmentUser = "" };

            mock.Setup(s => s.Get<List<GetSectionUserModel>>(It.IsAny<string>(), System.Data.CommandType.Text, null)).ReturnsAsync((true, "Success", new List<GetSectionUserModel>()));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.GetListSectionUser(request);
            Assert.True(result.success);
            Assert.Equal("Success", result.message);
        }

        [Fact]
        //[Theory]
        //[InlineData("0000000000000")]
        public async Task GetListSectionUser_Fail_DataNotFound()
        {
            RequestSectionUserModel request = new RequestSectionUserModel() { calType ="", sectionUser ="", departmentUser =""};

            mock.Setup(s => s.Get<List<GetSectionUserModel>>(It.IsAny<string>(), System.Data.CommandType.Text, null)).ReturnsAsync((false, "Data not found.", null));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.GetListSectionUser(request);
            //Assert.True(!result.success);
            Assert.Contains("Data not found", result.message);
        }
    }
}
