﻿using CALLSCREEN_MSSQL_API.DataAccess.Interfaces;
using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Models.SystemCode;
using Microsoft.Extensions.Configuration;
using Moq;
using System;
using System.Globalization;
using System.Threading.Tasks;
using Xunit;

namespace CALLSCREEN_MSSQL_API.UnitTest.SystemCode
{
    public class UpdateCustomerGroupData
    {
        protected readonly IConfiguration conf;
        protected readonly Mock<IDataCenter> mock;
        protected readonly SchemaDBModel schemaDB;

        private DateTime dateTime = DateTime.Now;
        private DateTimeFormatInfo m_DThai = new CultureInfo("th-TH", false).DateTimeFormat;

        public UpdateCustomerGroupData()
        {
            string env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")?.ToString() ?? "Development";
            conf = new ConfigurationBuilder()
                    .AddJsonFile($"appsettings.{env}.json", optional: true, reloadOnChange: true)
                    .AddEnvironmentVariables().Build();
            mock = new Mock<IDataCenter>();
            mock.Setup(s => s.SchemaDB()).Returns(conf.GetSection("SchemaDB").Get<SchemaDBModel>());
            schemaDB = mock.Object.SchemaDB();
        }

        [Fact]
        //[Theory]
        //[InlineData("1111111111111")]
        public async Task UpdateCustomerGroupData_Success()
        {
            RequestSaveCustomerGroupModel request = new RequestSaveCustomerGroupModel();
            int updateDate = (int.TryParse(dateTime.ToString("yyMMdd", m_DThai), out updateDate) == true ? updateDate : 0);
            int updateTime = (int.TryParse(dateTime.ToString("HHmmss", m_DThai), out updateTime) == true ? updateTime : 0);
            int intmonth = 0;
            int fromLastMonth = (int.TryParse(request.fromLastMonth, out intmonth) == true ? intmonth : 0);
            int toLastMonth = (int.TryParse(request.toLastMonth, out intmonth) == true ? intmonth : 0);

            var strCommand = $@"UPDATE {schemaDB?.CS}.CSMCB17  
                                 SET T7TYCD = '{request.typeCode?.Trim()}' 
                                    , T7TYDS = '{request.typeDescription?.Trim()}' 
                                    , T7MONF = '{fromLastMonth}' 
                                    , T7MONT = '{toLastMonth}' 
                                    , T7ARRY = '{request.array6?.Trim().ToUpper()}' 
                                    , T7UDAT = '{updateDate}' 
                                    , T7UTIM = '{updateTime}' 
                                    , T7UUSR = '{request.userName?.Trim()}' 
                                    , T7UPGM = '{request.updByProgram?.Trim()}' 
                                    , T7UJOB = '{request.updWorkStation?.Trim()}' 
                                    , T7DEL = '{request.recordStatus?.Trim()}' 
                                WHERE T7TYSQ = '{request.typeSequence?.Trim().ToUpper()}' 
                                    AND T7STAS = '{request.custGrpStatus?.Trim().ToUpper()}'";

            mock.Setup(s => s.Execute(strCommand, System.Data.CommandType.Text, null)).ReturnsAsync((true, ""));
            var service = new Services.SystemCodeService(mock.Object);

            #region Update HS
            string actionCode = "U";
            strCommand = $@"INSERT INTO {schemaDB?.CS}.CSMCB17HS (T7ACTN,T7STAS,T7TYSQ,T7TYCD,T7TYDS,T7MONF,T7MONT,T7ARRY,T7UDAT,T7UTIM,T7UUSR,T7UPGM,T7UJOB,T7DEL) 
                                 VALUES ('{actionCode}'
                                        , '{request.custGrpStatus?.Trim().ToUpper()}'
                                        , '{request.typeSequence?.Trim().ToUpper()}'
                                        , '{request.typeCode?.Trim()}'
                                        , '{request.typeDescription?.Trim()}'
                                        , '{fromLastMonth}' 
                                        , '{toLastMonth}'
                                        , '{request.array6?.Trim().ToUpper()}'
                                        , '{updateDate}'
                                        , '{updateTime}'
                                        , '{request.userName?.Trim()}'
                                        , '{request.updByProgram?.Trim()}'
                                        , '{request.updWorkStation?.Trim()}'
                                        , '{request.recordStatus?.Trim()}')";


            mock.Setup(s => s.Execute(strCommand, System.Data.CommandType.Text, null)).ReturnsAsync((true, ""));
            service = new Services.SystemCodeService(mock.Object);
            #endregion
            var result = await service.UpdateCustomerGroupData(request);
            Assert.True(result.success);
            Assert.Equal("Insert Data Success, ", result.message);
        }

        [Fact]
        //[Theory]
        //[InlineData("0000000000000")]
        public async Task UpdateCustomerGroupData_Fail_DataNotFound()
        {
            RequestSaveCustomerGroupModel request = new RequestSaveCustomerGroupModel();
            int updateDate = (int.TryParse(dateTime.ToString("yyMMdd", m_DThai), out updateDate) == true ? updateDate : 0);
            int updateTime = (int.TryParse(dateTime.ToString("HHmmss", m_DThai), out updateTime) == true ? updateTime : 0);
            int intmonth = 0;
            int fromLastMonth = (int.TryParse(request.fromLastMonth, out intmonth) == true ? intmonth : 0);
            int toLastMonth = (int.TryParse(request.toLastMonth, out intmonth) == true ? intmonth : 0);

            var strCommand = $@"UPDATE {schemaDB?.CS}.CSMCB17  
                                 SET T7TYCD = '{request.typeCode?.Trim()}' 
                                    , T7TYDS = '{request.typeDescription?.Trim()}' 
                                    , T7MONF = '{fromLastMonth}' 
                                    , T7MONT = '{toLastMonth}' 
                                    , T7ARRY = '{request.array6?.Trim().ToUpper()}' 
                                    , T7UDAT = '{updateDate}' 
                                    , T7UTIM = '{updateTime}' 
                                    , T7UUSR = '{request.userName?.Trim()}' 
                                    , T7UPGM = '{request.updByProgram?.Trim()}' 
                                    , T7UJOB = '{request.updWorkStation?.Trim()}' 
                                    , T7DEL = '{request.recordStatus?.Trim()}' 
                                WHERE T7TYSQ = '{request.typeSequence?.Trim().ToUpper()}' 
                                    AND T7STAS = '{request.custGrpStatus?.Trim().ToUpper()}'";

            mock.Setup(s => s.Execute(strCommand, System.Data.CommandType.Text, null)).ReturnsAsync((false, "Data not found."));
            var service = new Services.SystemCodeService(mock.Object);

            #region Update HS
            string actionCode = "U";
            strCommand = $@"INSERT INTO {schemaDB?.CS}.CSMCB17HS (T7ACTN,T7STAS,T7TYSQ,T7TYCD,T7TYDS,T7MONF,T7MONT,T7ARRY,T7UDAT,T7UTIM,T7UUSR,T7UPGM,T7UJOB,T7DEL) 
                                 VALUES ('{actionCode}'
                                        , '{request.custGrpStatus?.Trim().ToUpper()}'
                                        , '{request.typeSequence?.Trim().ToUpper()}'
                                        , '{request.typeCode?.Trim()}'
                                        , '{request.typeDescription?.Trim()}'
                                        , '{fromLastMonth}' 
                                        , '{toLastMonth}'
                                        , '{request.array6?.Trim().ToUpper()}'
                                        , '{updateDate}'
                                        , '{updateTime}'
                                        , '{request.userName?.Trim()}'
                                        , '{request.updByProgram?.Trim()}'
                                        , '{request.updWorkStation?.Trim()}'
                                        , '{request.recordStatus?.Trim()}')";


            mock.Setup(s => s.Execute(strCommand, System.Data.CommandType.Text, null)).ReturnsAsync((false, "Data not found."));
            service = new Services.SystemCodeService(mock.Object);
            #endregion
            var result = await service.UpdateCustomerGroupData(request);
            //Assert.True(!result.success);
            Assert.Contains("Data not found", result.message);
        }
    }
}
