﻿using CALLSCREEN_MSSQL_API.DataAccess.Interfaces;
using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Models.SystemCode;
using Microsoft.Extensions.Configuration;
using Moq;
using System;
using System.Globalization;
using System.Threading.Tasks;
using Xunit;

namespace CALLSCREEN_MSSQL_API.UnitTest.SystemCode
{
    public class UpdateRankingCode
    {
        protected readonly IConfiguration conf;
        protected readonly Mock<IDataCenter> mock;
        protected readonly SchemaDBModel schemaDB;

        private DateTime dateTime = DateTime.Now;
        private DateTimeFormatInfo m_DThai = new CultureInfo("th-TH", false).DateTimeFormat;

        public UpdateRankingCode()
        {
            string env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")?.ToString() ?? "Development";
            conf = new ConfigurationBuilder()
                    .AddJsonFile($"appsettings.{env}.json", optional: true, reloadOnChange: true)
                    .AddEnvironmentVariables().Build();
            mock = new Mock<IDataCenter>();
            mock.Setup(s => s.SchemaDB()).Returns(conf.GetSection("SchemaDB").Get<SchemaDBModel>());
            schemaDB = mock.Object.SchemaDB();
        }

        [Fact]
        //[Theory]
        //[InlineData("1111111111111")]
        public async Task UpdateRankingCode_Success()
        {
            ResultGetListRankingDetailModel request = new ResultGetListRankingDetailModel() { T1CODE ="", T1BIZ ="", T1ODST ="", T1UUSR =""};
            int updateDate = (int.TryParse(dateTime.ToString("yyMMdd", m_DThai), out updateDate) == true ? updateDate : 0);
            int updateTime = (int.TryParse(dateTime.ToString("HHmmss", m_DThai), out updateTime) == true ? updateTime : 0);

            var strCommand = $@"INSERT INTO {schemaDB?.CS}.CSMCB10 (T1CODE,T1BIZ,T1DUE,T1ODST,T1ODT,T1UDAT,T1UTIM,T1UUSR,T1UPGM,T1UJOB,T1DEL)
                                            VALUES ('{request.T1CODE.Trim()}',
                                                    '{request.T1BIZ.Trim()}',
                                                    '{request.T1DUE}',
                                                    '{request.T1ODST.Trim()}',
                                                    '{request.T1ODT}',
                                                    '{updateDate}',
                                                    '{updateTime}',
                                                    '{request.T1UUSR.Trim()}',
                                                    '',
                                                    '',
                                                    '')";

            mock.Setup(s => s.Execute(strCommand, System.Data.CommandType.Text, null)).ReturnsAsync((true, "Success"));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.UpdateRankingCode(request);
            Assert.True(result.success);
            Assert.Equal("Success", result.message);
        }

        [Fact]
        //[Theory]
        //[InlineData("0000000000000")]
        public async Task UpdateRankingCode_Fail_DataNotFound()
        {
            ResultGetListRankingDetailModel request = new ResultGetListRankingDetailModel() { T1CODE = "", T1BIZ = "", T1ODST = "", T1UUSR = "" };
           
            mock.Setup(s => s.Execute(It.IsAny<string>(), System.Data.CommandType.Text, null)).ReturnsAsync((false, "Data not found."));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.UpdateRankingCode(request);
            //Assert.True(!result.success);
            Assert.Contains("Data not found", result.message);
        }
    }
}
