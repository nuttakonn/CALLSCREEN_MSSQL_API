﻿using CALLSCREEN_MSSQL_API.DataAccess.Interfaces;
using CALLSCREEN_MSSQL_API.Models;
using CALLSCREEN_MSSQL_API.Models.SystemCode;
using Microsoft.Extensions.Configuration;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace CALLSCREEN_MSSQL_API.UnitTest.SystemCode
{
    public class GetListResultCodeByTypeCode
    {
        protected readonly IConfiguration conf;
        protected readonly Mock<IDataCenter> mock;
        protected readonly SchemaDBModel schemaDB;
        public GetListResultCodeByTypeCode()
        {
            string env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")?.ToString() ?? "Development";
            conf = new ConfigurationBuilder()
                    .AddJsonFile($"appsettings.{env}.json", optional: true, reloadOnChange: true)
                    .AddEnvironmentVariables().Build();
            mock = new Mock<IDataCenter>();
            mock.Setup(s => s.SchemaDB()).Returns(conf.GetSection("SchemaDB").Get<SchemaDBModel>());
            schemaDB = mock.Object.SchemaDB();
        }

        [Fact]
        //[Theory]
        //[InlineData("1111111111111")]
        public async Task GetListResultCodeByTypeCode_Success()
        {
            RequestGetDataTypeAndResultModel request = new RequestGetDataTypeAndResultModel();

            string strWhere = "";

            var cmdText = $@"SELECT DISTINCT(A.T8RSCD) FROM {schemaDB?.CS}.CSMCB18 A";

            strWhere = $"WHERE A.T8DEL = ''";

            if (string.IsNullOrWhiteSpace(request.typeCode) == false)
            {
                strWhere += $" and A.T8TYCD = '{request.typeCode?.Trim().ToUpper()}'";
            }

            cmdText += $" {strWhere} order by A.T8RSCD ";

            mock.Setup(s => s.Get<List<GetDataResultCodeModel>>(cmdText, System.Data.CommandType.Text, null)).ReturnsAsync((true, "Success", new List<GetDataResultCodeModel>()));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.GetListResultCodeByTypeCode(request);
            Assert.True(result.success);
            Assert.Equal("Success", result.message);
        }

        [Fact]
        //[Theory]
        //[InlineData("0000000000000")]
        public async Task GetListResultCodeByTypeCode_Fail_DataNotFound()
        {
            RequestGetDataTypeAndResultModel request = new RequestGetDataTypeAndResultModel() { typeCode =""};

            mock.Setup(s => s.Get<List<GetDataResultCodeModel>>(It.IsAny<string>(), System.Data.CommandType.Text, null)).ReturnsAsync((false, "Data not found.",new List<GetDataResultCodeModel>()));
            var service = new Services.SystemCodeService(mock.Object);
            var result = await service.GetListResultCodeByTypeCode(request);
            //Assert.True(!result.success);
            Assert.Contains("Data not found", result.message);
        }
    }
}
