﻿using CALLSCREEN_MSSQL_API.DataAccess.Interfaces;
using CALLSCREEN_MSSQL_API.Models;
using Microsoft.Extensions.Configuration;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace CALLSCREEN_MSSQL_API.UnitTest.Contract
{
    public class GetListCallFree
    {
        protected readonly IConfiguration conf;
        protected readonly Mock<IDataCenter> mock;
        protected readonly SchemaDBModel schemaDB;
        public GetListCallFree()
        {
            string env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")?.ToString() ?? "Development";
            conf = new ConfigurationBuilder()
                    .AddJsonFile($"appsettings.{env}.json", optional: true, reloadOnChange: true)
                    .AddEnvironmentVariables().Build();
            mock = new Mock<IDataCenter>();
            mock.Setup(s => s.SchemaDB()).Returns(conf.GetSection("SchemaDB").Get<SchemaDBModel>());
            schemaDB = mock.Object.SchemaDB();
        }

        [Fact]
        //[Theory]
        //[InlineData("1111111111111")]
        public async Task GetListCallFree_Success()
        {
            var strCommand = @$"SELECT T8TELN, T8DESC, T8UDAT, T8UTIM, T8UUSR, T8UPGM, T8UJOB, T8DEL
                                  FROM {schemaDB?.CS}.CSMCB08 WITH (NOLOCK)
                                  WHERE T8DEL = ''";
            mock.Setup(s => s.Get<List<ResultCallFreeModel>>(strCommand, System.Data.CommandType.Text, null)).ReturnsAsync((true, "Success", new List<ResultCallFreeModel>()));
            var service = new Services.ContractService(mock.Object);
            var result = await service.GetListCallFree();
            Assert.True(result.success);
            Assert.Equal("Success", result.message);
        }

        [Fact]
        //[Theory]
        //[InlineData("0000000000000")]
        public async Task GetListCallFree_Fail_DataNotFound()
        {
            var strCommand = @$"SELECT T8TELN, T8DESC, T8UDAT, T8UTIM, T8UUSR, T8UPGM, T8UJOB, T8DEL
                                  FROM {schemaDB?.CS}.CSMCB08 WITH (NOLOCK)
                                  WHERE T8DEL = ''";
            mock.Setup(s => s.Get<List<ResultCallFreeModel>>(strCommand, System.Data.CommandType.Text, null)).ReturnsAsync((false, "Data not found.", null));
            var service = new Services.ContractService(mock.Object);
            var result = await service.GetListCallFree();
            //Assert.True(!result.success);
            Assert.Contains("Data not found", result.message);
        }
    }
}
