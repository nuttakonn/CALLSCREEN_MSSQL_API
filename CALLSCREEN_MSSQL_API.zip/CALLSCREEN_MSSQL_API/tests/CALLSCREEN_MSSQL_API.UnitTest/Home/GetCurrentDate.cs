﻿using CALLSCREEN_MSSQL_API.DataAccess.Interfaces;
using CALLSCREEN_MSSQL_API.Models;
using Microsoft.Extensions.Configuration;
using Moq;
using System;
using System.Threading.Tasks;
using Xunit;

namespace CALLSCREEN_MSSQL_API.UnitTest.Home
{
    public class GetCurrentDate
    {
        protected readonly IConfiguration conf;
        protected readonly Mock<IDataCenter> mock;
        protected readonly SchemaDBModel schemaDB;
        public GetCurrentDate()
        {
            string env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")?.ToString() ?? "Development";
            conf = new ConfigurationBuilder()
                    .AddJsonFile($"appsettings.{env}.json", optional: true, reloadOnChange: true)
                    .AddEnvironmentVariables().Build();
            mock = new Mock<IDataCenter>();
            mock.Setup(s => s.SchemaDB()).Returns(conf.GetSection("SchemaDB").Get<SchemaDBModel>());
            schemaDB = mock.Object.SchemaDB();
        }

        [Fact]
        public async Task GetCurrentDate_Success()
        {
            var strCommand = @$"SELECT CAST(M97DTE + 25000000 AS INTEGER) AS CurrentDate FROM {mock.Object.SchemaDB()?.CS}.CSMS97 WITH (NOLOCK) WHERE M97CDE = '01'";
            mock.Setup(s => s.Get<HomeModel>(strCommand, System.Data.CommandType.Text, null)).ReturnsAsync((true, "Success", new HomeModel()));
            var service = new Services.HomeService(mock.Object);
            var result = await service.GetCurrentDate();
            Assert.True(result.success);
            Assert.Equal("Success", result.message);
        }

        [Fact]
        public async Task GetCurrentDate_Fail_DataNotFound()
        {
            var strCommand = @$"SELECT CAST(M97DTE + 25000000 AS INTEGER) AS CurrentDate FROM {mock.Object.SchemaDB()?.CS}.CSMS97 WITH (NOLOCK) WHERE M97CDE = '01'";
            mock.Setup(s => s.Get<HomeModel>(strCommand, System.Data.CommandType.Text, null)).ReturnsAsync((false, "Data not found.", null));
            var service = new Services.HomeService(mock.Object);
            var result = await service.GetCurrentDate();
            Assert.True(result.success && result.message.Contains("Data not found"));
            Assert.False(result.data != null);
        }

        [Fact]
        public async Task GetCurrentDate_Fail_Exception()
        {
            var strCommand = @$"SELECT CAST(M97DTE + 25000000 AS INTEGER) AS CurrentDate FROM {mock.Object.SchemaDB()?.CS}.CSMS97 WITH (NOLOCK) WHERE M97CDE = '01'";
            mock.Setup(s => s.Get<HomeModel>(strCommand, System.Data.CommandType.Text, null)).Throws<ArgumentException>();
            var service = new Services.HomeService(mock.Object);
            var result = await service.GetCurrentDate();
            Assert.False(result.success);
            Assert.False(result.data != null);
            Assert.False(result.message == null);
        }
    }
}
